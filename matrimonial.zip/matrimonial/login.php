<?php
// File: login.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) { header('Location: ' . BASE_URL . '/matches.php'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken()) { $error = 'Invalid request.'; }
    else {
        $auth = new Auth();
        $result = $auth->login(
            $_POST['email'] ?? '',
            $_POST['password'] ?? '',
            !empty($_POST['remember'])
        );

        if ($result['success']) {
            $redirectTo = $_SESSION['redirect_after_login'] ?? BASE_URL . '/matches.php';
            unset($_SESSION['redirect_after_login']);
            setFlash('success', $result['message']);
            header('Location: ' . $redirectTo);
            exit;
        } else {
            $error = $result['message'];
        }
    }
}

$pageTitle = 'Login';
include __DIR__ . '/includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-icon">&#9825;</div>
            <h1>Welcome Back</h1>
            <p>Login to continue your journey</p>
        </div>

        <?php if ($error): ?>
            <div class="flash flash-error" style="position:static;margin-bottom:20px;"><span><?php echo sanitize($error); ?></span></div>
        <?php endif; ?>

        <form method="POST" action="" novalidate>
            <?php echo csrfField(); ?>

            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" required placeholder="your@email.com" value="<?php echo sanitize($_POST['email'] ?? ''); ?>">
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required placeholder="Enter your password">
            </div>

            <div class="form-group" style="display:flex;justify-content:space-between;align-items:center;">
                <label class="form-check">
                    <input type="checkbox" name="remember">
                    <span>Remember me</span>
                </label>
                <a href="<?php echo BASE_URL; ?>/forgot-password.php" style="font-size:0.85rem;">Forgot password?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="<?php echo BASE_URL; ?>/register.php">Register free</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
