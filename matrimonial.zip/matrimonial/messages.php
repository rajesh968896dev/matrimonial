<?php
// File: messages.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$chatWith = intval($_GET['user'] ?? 0);

// Get conversations list
$stmt = $db->prepare("
    SELECT DISTINCT
        CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END as other_user_id,
        (SELECT message FROM messages WHERE
            (sender_id = ? AND receiver_id = other_user_id) OR
            (sender_id = other_user_id AND receiver_id = ?)
            ORDER BY created_at DESC LIMIT 1
        ) as last_message,
        (SELECT created_at FROM messages WHERE
            (sender_id = ? AND receiver_id = other_user_id) OR
            (sender_id = other_user_id AND receiver_id = ?)
            ORDER BY created_at DESC LIMIT 1
        ) as last_message_time,
        (SELECT COUNT(*) FROM messages WHERE sender_id = other_user_id AND receiver_id = ? AND is_read = 0) as unread_count
    FROM messages m
    WHERE m.sender_id = ? OR m.receiver_id = ?
    ORDER BY last_message_time DESC
");
$stmt->execute([$userId, $userId, $userId, $userId, $userId, $userId, $userId, $userId]);
$conversations = $stmt->fetchAll();

// Get chat messages
$chatMessages = [];
$chatPartner = null;
if ($chatWith > 0) {
    // Verify mutual interest exists
    $stmt = $db->prepare("SELECT id FROM interests WHERE status = 'accepted' AND ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))");
    $stmt->execute([$userId, $chatWith, $chatWith, $userId]);
    $canChat = $stmt->fetch() ? true : false;

    if ($canChat || true) { // Allow chat for now; remove "|| true" to enforce mutual match
        $stmt = $db->prepare("
            SELECT m.*, p.first_name, p.last_name, p.photo_primary, p.gender
            FROM messages m
            JOIN profiles p ON p.user_id = m.sender_id
            WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$userId, $chatWith, $chatWith, $userId]);
        $chatMessages = $stmt->fetchAll();

        // Mark messages as read
        $stmt = $db->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?");
        $stmt->execute([$chatWith, $userId]);

        // Get partner info
        $stmt = $db->prepare("SELECT p.*, u.email FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.user_id = ?");
        $stmt->execute([$chatWith]);
        $chatPartner = $stmt->fetch();
    }
}

$pageTitle = 'Messages';
include __DIR__ . '/includes/header.php';
?>

<div class="messages-layout">
    <!-- Conversations Sidebar -->
    <div class="conversations-list <?php echo $chatWith ? '' : 'show'; ?>">
        <div style="padding:20px;border-bottom:1px solid var(--border);">
            <h2 style="font-size:1.3rem;">Messages</h2>
        </div>

        <?php if (empty($conversations)): ?>
            <div style="padding:40px 20px;text-align:center;color:var(--text-muted);">
                <p>No conversations yet.</p>
                <p style="font-size:0.85rem;">Start by sending interests to profiles you like!</p>
            </div>
        <?php else: ?>
            <?php foreach ($conversations as $conv): ?>
                <?php
                $stmt2 = $db->prepare("SELECT first_name, last_name, photo_primary, gender FROM profiles WHERE user_id = ?");
                $stmt2->execute([$conv['other_user_id']]);
                $partner = $stmt2->fetch();
                if (!$partner) continue;
                ?>
                <a href="<?php echo BASE_URL; ?>/messages.php?user=<?php echo $conv['other_user_id']; ?>" class="conversation-item <?php echo $chatWith == $conv['other_user_id'] ? 'active' : ''; ?>">
                    <img src="<?php echo getProfilePhoto($partner['photo_primary'], $partner['gender']); ?>" alt="" class="conv-avatar">
                    <div class="conv-info">
                        <div class="conv-name"><?php echo sanitize($partner['first_name'] . ' ' . $partner['last_name']); ?></div>
                        <div class="conv-preview"><?php echo sanitize(substr($conv['last_message'] ?? '', 0, 50)); ?></div>
                    </div>
                    <div class="conv-meta">
                        <div class="conv-time"><?php echo $conv['last_message_time'] ? timeAgo($conv['last_message_time']) : ''; ?></div>
                        <?php if ($conv['unread_count'] > 0): ?>
                            <div class="unread-dot"></div>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Chat Area -->
    <div class="chat-area">
        <?php if ($chatPartner): ?>
            <div class="chat-header">
                <a href="<?php echo BASE_URL; ?>/messages.php" class="btn btn-ghost btn-sm" style="display:none;" id="backToList">&larr; Back</a>
                <img src="<?php echo getProfilePhoto($chatPartner['photo_primary'], $chatPartner['gender']); ?>" alt="" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">
                <div>
                    <strong><?php echo sanitize($chatPartner['first_name'] . ' ' . $chatPartner['last_name']); ?></strong>
                    <div style="font-size:0.8rem;color:var(--text-muted);">
                        <?php echo sanitize($chatPartner['city'] ?? ''); ?>, <?php echo sanitize($chatPartner['occupation'] ?? ''); ?>
                    </div>
                </div>
                <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $chatWith; ?>" class="btn btn-ghost btn-sm" style="margin-left:auto;">View Profile</a>
            </div>

            <div class="chat-messages" id="chatMessages">
                <?php if (empty($chatMessages)): ?>
                    <div style="text-align:center;color:var(--text-light);padding:40px;">
                        Start your conversation with <?php echo sanitize($chatPartner['first_name']); ?>!
                    </div>
                <?php else: ?>
                    <?php foreach ($chatMessages as $msg): ?>
                        <div class="message-bubble <?php echo $msg['sender_id'] === $userId ? 'message-sent' : 'message-received'; ?>">
                            <div><?php echo sanitize($msg['message']); ?></div>
                            <div class="message-time"><?php echo date('g:i A', strtotime($msg['created_at'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <form class="chat-input-area" id="chatForm">
                <input type="hidden" name="receiver_id" value="<?php echo $chatWith; ?>">
                <input type="text" name="message" placeholder="Type your message..." autocomplete="off" required>
                <button type="submit" class="btn btn-primary">Send</button>
            </form>
        <?php else: ?>
            <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--text-muted);">
                <div style="text-align:center;">
                    <div style="font-size:3rem;margin-bottom:16px;opacity:0.3;">&#128172;</div>
                    <h3 style="color:var(--text-secondary);">Select a conversation</h3>
                    <p>Choose from your conversations to start messaging</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Auto-scroll chat to bottom
const chatMessages = document.getElementById('chatMessages');
if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
