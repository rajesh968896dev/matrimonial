<?php
// File: api/interest-action.php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login first.']);
    exit;
}

if (!verifyCsrfToken()) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';
$targetUserId = intval($_POST['user_id'] ?? 0);

if (!$targetUserId || $targetUserId === $userId) {
    echo json_encode(['success' => false, 'message' => 'Invalid target user.']);
    exit;
}

try {
    switch ($action) {
        case 'interest':
            // Check if already sent
            $stmt = $db->prepare("SELECT id FROM interests WHERE sender_id = ? AND receiver_id = ?");
            $stmt->execute([$userId, $targetUserId]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Interest already sent.']);
                break;
            }

            // Check daily limit
            $stmt = $db->prepare("SELECT COUNT(*) FROM interests WHERE sender_id = ? AND DATE(created_at) = CURDATE()");
            $stmt->execute([$userId]);
            if ($stmt->fetchColumn() >= 50) {
                echo json_encode(['success' => false, 'message' => 'Daily interest limit reached.']);
                break;
            }

            $stmt = $db->prepare("INSERT INTO interests (sender_id, receiver_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $targetUserId, sanitize($_POST['message'] ?? '')]);

            logActivity('send_interest', $userId, "To: $targetUserId");
            echo json_encode(['success' => true, 'message' => 'Interest sent successfully!', 'button_text' => 'Interest Sent']);
            break;

        case 'accept-interest':
            $stmt = $db->prepare("UPDATE interests SET status = 'accepted' WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'");
            $stmt->execute([$targetUserId, $userId]);

            if ($stmt->rowCount() > 0) {
                logActivity('accept_interest', $userId, "From: $targetUserId");
                echo json_encode(['success' => true, 'message' => 'Interest accepted! You can now message each other.', 'remove_card' => false]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Interest not found or already processed.']);
            }
            break;

        case 'decline-interest':
            $stmt = $db->prepare("UPDATE interests SET status = 'declined' WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'");
            $stmt->execute([$targetUserId, $userId]);

            echo json_encode(['success' => true, 'message' => 'Interest declined.', 'remove_card' => true]);
            break;

        case 'shortlist':
            $stmt = $db->prepare("INSERT IGNORE INTO shortlists (user_id, shortlisted_user_id) VALUES (?, ?)");
            $stmt->execute([$userId, $targetUserId]);
            echo json_encode(['success' => true, 'message' => 'Added to shortlist.']);
            break;

        case 'unshortlist':
            $stmt = $db->prepare("DELETE FROM shortlists WHERE user_id = ? AND shortlisted_user_id = ?");
            $stmt->execute([$userId, $targetUserId]);
            echo json_encode(['success' => true, 'message' => 'Removed from shortlist.', 'remove_card' => true]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Unknown action.']);
    }
} catch (Exception $e) {
    error_log("Interest action error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}
