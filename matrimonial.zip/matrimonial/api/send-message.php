<?php
// File: api/send-message.php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login.']);
    exit;
}

if (!verifyCsrfToken()) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$db = Database::getInstance();
$senderId = $_SESSION['user_id'];
$receiverId = intval($_POST['receiver_id'] ?? 0);
$message = trim($_POST['message'] ?? '');

if (!$receiverId || empty($message) || $receiverId === $senderId) {
    echo json_encode(['success' => false, 'message' => 'Invalid message data.']);
    exit;
}

if (strlen($message) > 2000) {
    echo json_encode(['success' => false, 'message' => 'Message too long (max 2000 characters).']);
    exit;
}

// Rate limit messages
$stmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE sender_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
$stmt->execute([$senderId]);
if ($stmt->fetchColumn() > 10) {
    echo json_encode(['success' => false, 'message' => 'Too many messages. Please wait.']);
    exit;
}

try {
    $stmt = $db->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
    $stmt->execute([$senderId, $receiverId, sanitize($message)]);

    echo json_encode([
        'success' => true,
        'message' => 'Sent',
        'time' => date('g:i A'),
        'id' => $db->lastInsertId()
    ]);
} catch (Exception $e) {
    error_log("Send message error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to send message.']);
}
