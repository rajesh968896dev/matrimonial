<?php
// File: profile.php — VIEW OWN OR OTHER PROFILE
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();

$viewUserId = intval($_GET['id'] ?? $_SESSION['user_id']);
$isOwnProfile = ($viewUserId === $_SESSION['user_id']);

$stmt = $db->prepare("SELECT p.*, u.email, u.role, u.last_login FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.user_id = ? AND u.status = 'active'");
$stmt->execute([$viewUserId]);
$profile = $stmt->fetch();

if (!$profile) { setFlash('error', 'Profile not found.'); header('Location: ' . BASE_URL . '/matches.php'); exit; }

// Log profile view
if (!$isOwnProfile) {
    try {
        $stmt = $db->prepare("INSERT INTO profile_views (viewer_id, viewed_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE viewed_at = NOW()");
        $stmt->execute([$_SESSION['user_id'], $viewUserId]);
        $stmt = $db->prepare("UPDATE profiles SET profile_views = profile_views + 1 WHERE user_id = ?");
        $stmt->execute([$viewUserId]);
    } catch (Exception $e) {}
}

// Check interest status
$interestStatus = null;
if (!$isOwnProfile) {
    $stmt = $db->prepare("SELECT status FROM interests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
    $stmt->execute([$_SESSION['user_id'], $viewUserId, $viewUserId, $_SESSION['user_id']]);
    $interestRow = $stmt->fetch();
    $interestStatus = $interestRow['status'] ?? null;
}

// Check shortlist
$isShortlisted = false;
if (!$isOwnProfile) {
    $stmt = $db->prepare("SELECT id FROM shortlists WHERE user_id = ? AND shortlisted_user_id = ?");
    $stmt->execute([$_SESSION['user_id'], $viewUserId]);
    $isShortlisted = $stmt->fetch() ? true : false;
}

$pageTitle = sanitize($profile['first_name'] . ' ' . $profile['last_name']);
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;">
    <div class="profile-view-grid">
        <!-- Photo Section -->
        <div class="profile-photo-section">
            <div class="profile-photo-main">
                <img src="<?php echo getProfilePhoto($profile['photo_primary'], $profile['gender']); ?>" alt="<?php echo sanitize($profile['first_name']); ?>">
            </div>

            <?php if (!$isOwnProfile): ?>
            <div style="display:flex;gap:8px;margin-bottom:16px;">
                <?php if ($interestStatus === null): ?>
                    <button class="btn btn-primary btn-block" data-action="interest" data-user-id="<?php echo $viewUserId; ?>">Send Interest</button>
                <?php elseif ($interestStatus === 'pending'): ?>
                    <button class="btn btn-ghost btn-block" disabled>Interest Sent</button>
                <?php elseif ($interestStatus === 'accepted'): ?>
                    <a href="<?php echo BASE_URL; ?>/messages.php?user=<?php echo $viewUserId; ?>" class="btn btn-primary btn-block">Send Message</a>
                <?php endif; ?>

                <button class="btn btn-ghost btn-icon" data-action="<?php echo $isShortlisted ? 'unshortlist' : 'shortlist'; ?>" data-user-id="<?php echo $viewUserId; ?>" title="<?php echo $isShortlisted ? 'Remove from shortlist' : 'Shortlist'; ?>">
                    <?php echo $isShortlisted ? '&#9829;' : '&#9825;'; ?>
                </button>
            </div>
            <?php endif; ?>

            <?php if ($isOwnProfile): ?>
            <a href="<?php echo BASE_URL; ?>/edit-profile.php" class="btn btn-secondary btn-block" style="margin-bottom:12px;">Edit Profile</a>
            <div style="background:var(--surface);border:1px solid var(--border-light);border-radius:var(--radius-lg);padding:20px;text-align:center;">
                <div style="font-size:2rem;font-family:var(--font-display);font-weight:700;color:var(--accent);"><?php echo number_format($profile['profile_views']); ?></div>
                <div style="font-size:0.85rem;color:var(--text-muted);">Profile Views</div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Info Section -->
        <div class="profile-info-section">
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:4px;">
                <h1><?php echo sanitize($profile['first_name'] . ' ' . $profile['last_name']); ?></h1>
                <?php if ($profile['profile_verified']): ?>
                    <span style="background:var(--success-bg);color:var(--success);padding:4px 12px;border-radius:var(--radius-full);font-size:0.75rem;font-weight:600;">&#10003; Verified</span>
                <?php endif; ?>
            </div>
            <p style="color:var(--text-muted);font-size:1.05rem;margin-bottom:4px;">
                <?php echo calculateAge($profile['date_of_birth']); ?> years,
                <?php echo $profile['height_cm'] ? formatHeight($profile['height_cm']) : 'N/A'; ?>,
                <?php echo sanitize($profile['marital_status'] ? ucwords(str_replace('_', ' ', $profile['marital_status'])) : ''); ?>
            </p>
            <p style="color:var(--text-secondary);margin-bottom:24px;">
                <?php echo sanitize($profile['city'] ?? ''); ?><?php echo ($profile['city'] && $profile['state']) ? ', ' : ''; ?><?php echo sanitize($profile['state'] ?? ''); ?>, <?php echo sanitize($profile['country'] ?? ''); ?>
            </p>

            <?php if ($profile['about_me']): ?>
            <h3 class="profile-section-title" style="margin-top:0;">About Me</h3>
            <p style="color:var(--text-secondary);line-height:1.8;margin-bottom:12px;"><?php echo nl2br(sanitize($profile['about_me'])); ?></p>
            <?php endif; ?>

            <h3 class="profile-section-title">Basic Details</h3>
            <div class="detail-grid">
                <div class="detail-item"><div class="detail-label">Age</div><div class="detail-value"><?php echo calculateAge($profile['date_of_birth']); ?> years</div></div>
                <div class="detail-item"><div class="detail-label">Height</div><div class="detail-value"><?php echo $profile['height_cm'] ? formatHeight($profile['height_cm']) : 'Not specified'; ?></div></div>
                <div class="detail-item"><div class="detail-label">Weight</div><div class="detail-value"><?php echo $profile['weight_kg'] ? $profile['weight_kg'] . ' kg' : 'Not specified'; ?></div></div>
                <div class="detail-item"><div class="detail-label">Body Type</div><div class="detail-value"><?php echo $profile['body_type'] ? ucfirst($profile['body_type']) : 'Not specified'; ?></div></div>
                <div class="detail-item"><div class="detail-label">Blood Group</div><div class="detail-value"><?php echo $profile['blood_group'] ?? 'Not specified'; ?></div></div>
                <div class="detail-item"><div class="detail-label">Marital Status</div><div class="detail-value"><?php echo ucwords(str_replace('_', ' ', $profile['marital_status'] ?? 'N/A')); ?></div></div>
                <div class="detail-item"><div class="detail-label">Mother Tongue</div><div class="detail-value"><?php echo sanitize($profile['mother_tongue'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Physical Status</div><div class="detail-value"><?php echo $profile['physical_status'] === 'normal' ? 'Normal' : 'Physically Challenged'; ?></div></div>
            </div>

            <h3 class="profile-section-title">Religion & Community</h3>
            <div class="detail-grid">
                <div class="detail-item"><div class="detail-label">Religion</div><div class="detail-value"><?php echo sanitize($profile['religion'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Caste</div><div class="detail-value"><?php echo sanitize($profile['caste'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Sub Caste</div><div class="detail-value"><?php echo sanitize($profile['sub_caste'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Gothra</div><div class="detail-value"><?php echo sanitize($profile['gothra'] ?? 'Not specified'); ?></div></div>
            </div>

            <h3 class="profile-section-title">Education & Career</h3>
            <div class="detail-grid">
                <div class="detail-item"><div class="detail-label">Education</div><div class="detail-value"><?php echo sanitize($profile['education'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Education Detail</div><div class="detail-value"><?php echo sanitize($profile['education_detail'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Occupation</div><div class="detail-value"><?php echo sanitize($profile['occupation'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Company</div><div class="detail-value"><?php echo sanitize($profile['occupation_detail'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Annual Income</div><div class="detail-value"><?php echo sanitize($profile['annual_income_range'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Work Location</div><div class="detail-value"><?php echo sanitize($profile['work_location'] ?? 'Not specified'); ?></div></div>
            </div>

            <h3 class="profile-section-title">Family Details</h3>
            <div class="detail-grid">
                <div class="detail-item"><div class="detail-label">Family Type</div><div class="detail-value"><?php echo $profile['family_type'] ? ucfirst($profile['family_type']) : 'Not specified'; ?></div></div>
                <div class="detail-item"><div class="detail-label">Family Status</div><div class="detail-value"><?php echo $profile['family_status'] ? ucwords(str_replace('_', ' ', $profile['family_status'])) : 'Not specified'; ?></div></div>
                <div class="detail-item"><div class="detail-label">Father</div><div class="detail-value"><?php echo sanitize($profile['father_occupation'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Mother</div><div class="detail-value"><?php echo sanitize($profile['mother_occupation'] ?? 'Not specified'); ?></div></div>
                <div class="detail-item"><div class="detail-label">Brothers</div><div class="detail-value"><?php echo $profile['brothers'] ?? 0; ?></div></div>
                <div class="detail-item"><div class="detail-label">Sisters</div><div class="detail-value"><?php echo $profile['sisters'] ?? 0; ?></div></div>
            </div>

            <?php if ($profile['about_family']): ?>
            <h3 class="profile-section-title">About Family</h3>
            <p style="color:var(--text-secondary);line-height:1.8;"><?php echo nl2br(sanitize($profile['about_family'])); ?></p>
            <?php endif; ?>

            <?php if ($profile['hobbies']): ?>
            <h3 class="profile-section-title">Hobbies & Interests</h3>
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
                <?php foreach (explode(',', $profile['hobbies']) as $hobby): ?>
                    <span style="padding:6px 16px;background:var(--bg-tertiary);border:1px solid var(--border);border-radius:var(--radius-full);font-size:0.85rem;color:var(--text-secondary);"><?php echo sanitize(trim($hobby)); ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($profile['partner_description']): ?>
            <h3 class="profile-section-title">Partner Expectations</h3>
            <p style="color:var(--text-secondary);line-height:1.8;"><?php echo nl2br(sanitize($profile['partner_description'])); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
