// File: assets/js/app.js

document.addEventListener('DOMContentLoaded', function() {

    // ========================
    // NAVIGATION
    // ========================
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const mainNav = document.getElementById('mainNav');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('open');
            this.classList.toggle('active');
        });

        // Close menu on outside click
        document.addEventListener('click', function(e) {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('open');
                navToggle.classList.remove('active');
            }
        });
    }

    // Scroll shadow
    if (mainNav) {
        window.addEventListener('scroll', function() {
            mainNav.classList.toggle('scrolled', window.scrollY > 10);
        });
    }

    // ========================
    // DROPDOWN MENUS
    // ========================
    document.querySelectorAll('.nav-dropdown').forEach(function(dropdown) {
        const trigger = dropdown.querySelector('.nav-dropdown-trigger');
        if (trigger) {
            trigger.addEventListener('click', function(e) {
                e.stopPropagation();
                // Close other dropdowns
                document.querySelectorAll('.nav-dropdown.open').forEach(function(d) {
                    if (d !== dropdown) d.classList.remove('open');
                });
                dropdown.classList.toggle('open');
            });
        }
    });

    document.addEventListener('click', function() {
        document.querySelectorAll('.nav-dropdown.open').forEach(function(d) {
            d.classList.remove('open');
        });
    });

    // ========================
    // AUTO-DISMISS FLASH MESSAGES
    // ========================
    document.querySelectorAll('.flash').forEach(function(flash) {
        setTimeout(function() {
            flash.style.opacity = '0';
            flash.style.transform = 'translateX(100%)';
            setTimeout(function() { flash.remove(); }, 300);
        }, 5000);
    });

    // ========================
    // SEARCH FILTERS TOGGLE (Mobile)
    // ========================
    const filterToggle = document.getElementById('filterToggle');
    const filterPanel = document.querySelector('.search-filters');
    if (filterToggle && filterPanel) {
        filterToggle.addEventListener('click', function() {
            filterPanel.classList.toggle('show');
        });
    }

    // ========================
    // INTEREST TABS
    // ========================
    document.querySelectorAll('.interests-tab').forEach(function(tab) {
        tab.addEventListener('click', function() {
            const target = this.dataset.tab;

            // Update tab state
            document.querySelectorAll('.interests-tab').forEach(function(t) {
                t.classList.remove('active');
            });
            this.classList.add('active');

            // Show target panel
            document.querySelectorAll('.tab-panel').forEach(function(panel) {
                panel.style.display = panel.id === target ? 'block' : 'none';
            });
        });
    });

    // ========================
    // INTEREST ACTIONS (AJAX)
    // ========================
    document.querySelectorAll('[data-action]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const action = this.dataset.action;
            const userId = this.dataset.userId;

            if (!action || !userId) return;

            const formData = new FormData();
            formData.append('action', action);
            formData.append('user_id', userId);
            formData.append('csrf_token', getCsrfToken());

            this.disabled = true;
            const originalText = this.innerHTML;
            this.innerHTML = '<span class="spinner" style="width:16px;height:16px;border-width:2px;"></span>';

            fetch(BASE_URL + '/api/interest-action.php', {
                method: 'POST',
                body: formData
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.success) {
                    showToast('success', data.message || 'Action completed!');
                    if (data.remove_card) {
                        const card = btn.closest('.interest-card') || btn.closest('.profile-card');
                        if (card) {
                            card.style.opacity = '0';
                            card.style.transform = 'scale(0.95)';
                            setTimeout(function() { card.remove(); }, 300);
                        }
                    } else {
                        btn.innerHTML = data.button_text || 'Done';
                        btn.classList.remove('btn-primary');
                        btn.classList.add('btn-ghost');
                    }
                } else {
                    showToast('error', data.message || 'Action failed.');
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                }
            })
            .catch(function() {
                showToast('error', 'Network error. Please try again.');
                btn.innerHTML = originalText;
                btn.disabled = false;
            });
        });
    });

    // ========================
    // LIVE SEARCH (Debounced)
    // ========================
    const searchInput = document.getElementById('liveSearch');
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function() {
                // Trigger search form submit or AJAX
                document.getElementById('searchForm')?.dispatchEvent(new Event('submit'));
            }, 500);
        });
    }

    // ========================
    // IMAGE PREVIEW ON UPLOAD
    // ========================
    document.querySelectorAll('input[type="file"]').forEach(function(input) {
        input.addEventListener('change', function() {
            const file = this.files[0];
            if (!file) return;

            // Validate size
            if (file.size > 5 * 1024 * 1024) {
                showToast('error', 'File size must be under 5MB.');
                this.value = '';
                return;
            }

            // Preview
            const previewId = this.dataset.preview;
            const preview = document.getElementById(previewId);
            if (preview) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    });

    // ========================
    // FORM VALIDATION
    // ========================
    document.querySelectorAll('form[data-validate]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            let valid = true;

            this.querySelectorAll('[required]').forEach(function(field) {
                if (!field.value.trim()) {
                    field.style.borderColor = 'var(--error)';
                    valid = false;
                } else {
                    field.style.borderColor = '';
                }
            });

            // Password match
            const pwd = this.querySelector('[name="password"]');
            const confirm = this.querySelector('[name="confirm_password"]');
            if (pwd && confirm && pwd.value !== confirm.value) {
                confirm.style.borderColor = 'var(--error)';
                showToast('error', 'Passwords do not match.');
                valid = false;
            }

            if (!valid) {
                e.preventDefault();
                showToast('error', 'Please fill in all required fields.');
            }
        });
    });

    // ========================
    // CHAT SEND
    // ========================
    const chatForm = document.getElementById('chatForm');
    if (chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const input = this.querySelector('input[name="message"]');
            const message = input.value.trim();
            if (!message) return;

            const formData = new FormData(this);
            formData.append('csrf_token', getCsrfToken());

            fetch(BASE_URL + '/api/send-message.php', {
                method: 'POST',
                body: formData
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.success) {
                    appendMessage(message, 'sent', data.time);
                    input.value = '';
                } else {
                    showToast('error', data.message || 'Failed to send message.');
                }
            })
            .catch(function() {
                showToast('error', 'Network error.');
            });
        });
    }

    function appendMessage(text, type, time) {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble message-' + type;
        bubble.innerHTML = '<div>' + escapeHtml(text) + '</div><div class="message-time">' + (time || 'Just now') + '</div>';
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});

// ========================
// UTILITIES
// ========================
function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) return meta.content;
    const input = document.querySelector('input[name="csrf_token"]');
    return input ? input.value : '';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(type, message) {
    let container = document.querySelector('.flash-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'flash-container';
        document.body.appendChild(container);
    }

    const flash = document.createElement('div');
    flash.className = 'flash flash-' + type;
    flash.innerHTML = '<span>' + escapeHtml(message) + '</span><button class="flash-close" onclick="this.parentElement.remove()">&times;</button>';
    container.appendChild(flash);

    setTimeout(function() {
        flash.style.opacity = '0';
        flash.style.transform = 'translateX(100%)';
        setTimeout(function() { flash.remove(); }, 300);
    }, 4000);
}

// Placeholder avatar generator
const BASE_URL = window.BASE_URL || '/matrimonial';
