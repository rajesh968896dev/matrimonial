<?php
// File: register.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) { header('Location: ' . BASE_URL . '/matches.php'); exit; }

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken()) { $error = 'Invalid request. Please try again.'; }
    else {
        $auth = new Auth();
        $result = $auth->register([
            'email' => $_POST['email'] ?? '',
            'password' => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'profile_for' => $_POST['profile_for'] ?? 'self',
            'first_name' => $_POST['first_name'] ?? '',
            'last_name' => $_POST['last_name'] ?? '',
            'gender' => $_POST['gender'] ?? '',
            'dob' => $_POST['dob'] ?? '',
        ]);

        if ($result['success']) {
            setFlash('success', $result['message']);
            header('Location: ' . BASE_URL . '/login.php');
            exit;
        } else {
            $error = $result['message'];
        }
    }
}

$pageTitle = 'Register';
include __DIR__ . '/includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card wide">
        <div class="auth-header">
            <div class="auth-icon">&#9825;</div>
            <h1>Create Account</h1>
            <p>Begin your journey to find the perfect match</p>
        </div>

        <?php if ($error): ?>
            <div class="flash flash-error" style="position:static;margin-bottom:20px;"><span><?php echo sanitize($error); ?></span></div>
        <?php endif; ?>

        <form method="POST" action="" data-validate novalidate>
            <?php echo csrfField(); ?>

            <div class="form-group">
                <label class="form-label">This profile is for <span class="required">*</span></label>
                <select name="profile_for" class="form-control">
                    <option value="self">Myself</option>
                    <option value="son">Son</option>
                    <option value="daughter">Daughter</option>
                    <option value="brother">Brother</option>
                    <option value="sister">Sister</option>
                    <option value="friend">Friend</option>
                    <option value="relative">Relative</option>
                </select>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">First Name <span class="required">*</span></label>
                    <input type="text" name="first_name" class="form-control" required placeholder="Enter first name" value="<?php echo sanitize($_POST['first_name'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Last Name <span class="required">*</span></label>
                    <input type="text" name="last_name" class="form-control" required placeholder="Enter last name" value="<?php echo sanitize($_POST['last_name'] ?? ''); ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Gender <span class="required">*</span></label>
                    <select name="gender" class="form-control" required>
                        <option value="">Select Gender</option>
                        <option value="male" <?php echo ($_POST['gender'] ?? '') === 'male' ? 'selected' : ''; ?>>Male</option>
                        <option value="female" <?php echo ($_POST['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Date of Birth <span class="required">*</span></label>
                    <input type="date" name="dob" class="form-control" required value="<?php echo sanitize($_POST['dob'] ?? ''); ?>" max="<?php echo date('Y-m-d', strtotime('-18 years')); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Email Address <span class="required">*</span></label>
                <input type="email" name="email" class="form-control" required placeholder="your@email.com" value="<?php echo sanitize($_POST['email'] ?? ''); ?>">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Password <span class="required">*</span></label>
                    <input type="password" name="password" class="form-control" required placeholder="Min 8 characters" minlength="8">
                    <div class="form-hint">Must contain uppercase, lowercase, and a number</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password <span class="required">*</span></label>
                    <input type="password" name="confirm_password" class="form-control" required placeholder="Re-enter password">
                </div>
            </div>

            <div class="form-group">
                <label class="form-check">
                    <input type="checkbox" required>
                    <span>I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-lg btn-block">Create Account</button>
        </form>

        <div class="auth-footer">
            Already have an account? <a href="<?php echo BASE_URL; ?>/login.php">Login here</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
