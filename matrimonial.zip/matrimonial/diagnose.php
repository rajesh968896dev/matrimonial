<?php
// File: diagnose.php
// Open: http://localhost/matrimonial/diagnose.php

define('APP_RUNNING', true);

// ============================================================
// CONNECT TO MYSQL
// ============================================================
try {
    $pdo = new PDO('mysql:host=127.0.0.1', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    $connOk = true;
    $connMsg = 'Connected to MySQL server';
} catch (PDOException $e) {
    $connOk = false;
    $connMsg = $e->getMessage();
}

$dbCreated = false;
$sqlImported = false;
$adminExists = false;
$tableResults = [];
$columnFixes = [];
$dirResults = [];
$testQueryOk = false;
$testQueryMsg = '';

// ============================================================
// STEP 1: CHECK / CREATE DATABASE
// ============================================================
if ($connOk) {
    try {
        $check = $pdo->query("SHOW DATABASES LIKE 'matrimonial_db'")->fetch();
        if (!$check) {
            $pdo->exec("CREATE DATABASE matrimonial_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $dbCreated = true;
        } else {
            $dbCreated = true;
        }
    } catch (PDOException $e) {
        $dbCreated = false;
    }
}

// ============================================================
// STEP 2: CREATE TABLES (individual CREATE TABLE statements)
// ============================================================
if ($dbCreated) {
    $pdo->exec("USE matrimonial_db");

    // Check existing tables
    $existingTables = [];
    $stmt = $pdo->query("SHOW TABLES");
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        $existingTables[] = $row[0];
    }

    // USERS
    if (!in_array('users', $existingTables)) {
        $pdo->exec("CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role ENUM('user','admin') DEFAULT 'user',
            status ENUM('active','inactive','suspended','pending') DEFAULT 'pending',
            email_verified TINYINT(1) DEFAULT 0,
            verification_token VARCHAR(64) DEFAULT NULL,
            remember_token VARCHAR(64) DEFAULT NULL,
            token_expires DATETIME DEFAULT NULL,
            last_login DATETIME DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_email (email),
            INDEX idx_status (status),
            INDEX idx_role (role)
        ) ENGINE=InnoDB");
        $tableResults['users'] = 'created';
    } else {
        $tableResults['users'] = 'exists';
    }

    // PROFILES
    if (!in_array('profiles', $existingTables)) {
        $pdo->exec("CREATE TABLE profiles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL UNIQUE,
            profile_for ENUM('self','son','daughter','brother','sister','friend','relative') DEFAULT 'self',
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            gender ENUM('male','female') NOT NULL,
            date_of_birth DATE NOT NULL,
            height_cm INT DEFAULT NULL,
            weight_kg INT DEFAULT NULL,
            body_type ENUM('slim','average','athletic','heavy') DEFAULT NULL,
            complexion ENUM('very_fair','fair','wheatish','dark') DEFAULT NULL,
            blood_group ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') DEFAULT NULL,
            physical_status ENUM('normal','physically_challenged') DEFAULT 'normal',
            religion VARCHAR(100) DEFAULT NULL,
            caste VARCHAR(100) DEFAULT NULL,
            sub_caste VARCHAR(100) DEFAULT NULL,
            gothra VARCHAR(100) DEFAULT NULL,
            star VARCHAR(100) DEFAULT NULL,
            rashi VARCHAR(100) DEFAULT NULL,
            mother_tongue VARCHAR(100) DEFAULT NULL,
            country VARCHAR(100) DEFAULT 'India',
            state VARCHAR(100) DEFAULT NULL,
            city VARCHAR(100) DEFAULT NULL,
            citizenship VARCHAR(100) DEFAULT NULL,
            education VARCHAR(200) DEFAULT NULL,
            education_detail VARCHAR(300) DEFAULT NULL,
            occupation VARCHAR(200) DEFAULT NULL,
            occupation_detail VARCHAR(300) DEFAULT NULL,
            annual_income_range VARCHAR(100) DEFAULT NULL,
            work_location VARCHAR(200) DEFAULT NULL,
            marital_status ENUM('never_married','divorced','widowed','awaiting_divorce','annulled') DEFAULT 'never_married',
            children TINYINT DEFAULT 0,
            family_type ENUM('joint','nuclear') DEFAULT NULL,
            family_status ENUM('middle_class','upper_middle_class','rich','affluent') DEFAULT NULL,
            father_occupation VARCHAR(200) DEFAULT NULL,
            mother_occupation VARCHAR(200) DEFAULT NULL,
            brothers TINYINT DEFAULT 0,
            brothers_married TINYINT DEFAULT 0,
            sisters TINYINT DEFAULT 0,
            sisters_married TINYINT DEFAULT 0,
            about_me TEXT DEFAULT NULL,
            about_family TEXT DEFAULT NULL,
            hobbies TEXT DEFAULT NULL,
            partner_age_min INT DEFAULT NULL,
            partner_age_max INT DEFAULT NULL,
            partner_height_min INT DEFAULT NULL,
            partner_height_max INT DEFAULT NULL,
            partner_religion VARCHAR(100) DEFAULT NULL,
            partner_caste VARCHAR(100) DEFAULT NULL,
            partner_education VARCHAR(200) DEFAULT NULL,
            partner_occupation VARCHAR(200) DEFAULT NULL,
            partner_location VARCHAR(200) DEFAULT NULL,
            partner_marital_status VARCHAR(200) DEFAULT NULL,
            partner_annual_income VARCHAR(100) DEFAULT NULL,
            partner_description TEXT DEFAULT NULL,
            photo_primary VARCHAR(255) DEFAULT NULL,
            photo_gallery TEXT DEFAULT NULL,
            profile_verified TINYINT(1) DEFAULT 0,
            profile_boosted_until DATETIME DEFAULT NULL,
            profile_views INT DEFAULT 0,
            last_active DATETIME DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_gender (gender),
            INDEX idx_religion (religion),
            INDEX idx_country (country),
            INDEX idx_state (state),
            INDEX idx_city (city),
            INDEX idx_education (education),
            INDEX idx_marital_status (marital_status),
            INDEX idx_dob (date_of_birth),
            INDEX idx_last_active (last_active)
        ) ENGINE=InnoDB");
        $tableResults['profiles'] = 'created';
    } else {
        $tableResults['profiles'] = 'exists';
    }

    // INTERESTS
    if (!in_array('interests', $existingTables)) {
        $pdo->exec("CREATE TABLE interests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            status ENUM('pending','accepted','declined','cancelled') DEFAULT 'pending',
            message TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_interest (sender_id, receiver_id),
            INDEX idx_receiver_status (receiver_id, status),
            INDEX idx_sender_status (sender_id, status)
        ) ENGINE=InnoDB");
        $tableResults['interests'] = 'created';
    } else {
        $tableResults['interests'] = 'exists';
    }

    // SHORTLISTS
    if (!in_array('shortlists', $existingTables)) {
        $pdo->exec("CREATE TABLE shortlists (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            shortlisted_user_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (shortlisted_user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_shortlist (user_id, shortlisted_user_id)
        ) ENGINE=InnoDB");
        $tableResults['shortlists'] = 'created';
    } else {
        $tableResults['shortlists'] = 'exists';
    }

    // MESSAGES
    if (!in_array('messages', $existingTables)) {
        $pdo->exec("CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            message TEXT NOT NULL,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_conversation (sender_id, receiver_id),
            INDEX idx_receiver_read (receiver_id, is_read)
        ) ENGINE=InnoDB");
        $tableResults['messages'] = 'created';
    } else {
        $tableResults['messages'] = 'exists';
    }

    // PROFILE VIEWS
    if (!in_array('profile_views', $existingTables)) {
        $pdo->exec("CREATE TABLE profile_views (
            id INT AUTO_INCREMENT PRIMARY KEY,
            viewer_id INT NOT NULL,
            viewed_id INT NOT NULL,
            viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (viewer_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (viewed_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_viewed (viewed_id, viewed_at)
        ) ENGINE=InnoDB");
        $tableResults['profile_views'] = 'created';
    } else {
        $tableResults['profile_views'] = 'exists';
    }

    // ACTIVITY LOG
    if (!in_array('activity_log', $existingTables)) {
        $pdo->exec("CREATE TABLE activity_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT DEFAULT NULL,
            action VARCHAR(100) NOT NULL,
            ip_address VARCHAR(45) DEFAULT NULL,
            user_agent TEXT DEFAULT NULL,
            details TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_action (user_id, action),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB");
        $tableResults['activity_log'] = 'created';
    } else {
        $tableResults['activity_log'] = 'exists';
    }

    // SETTINGS
    if (!in_array('settings', $existingTables)) {
        $pdo->exec("CREATE TABLE settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL UNIQUE,
            setting_value TEXT DEFAULT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB");
        $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES
            ('site_name', 'VivahaBandhan'),
            ('site_tagline', 'Where Hearts Unite Forever'),
            ('maintenance_mode', '0'),
            ('max_photos', '6'),
            ('max_interests_per_day', '50'),
            ('require_email_verification', '1')");
        $tableResults['settings'] = 'created';
    } else {
        $tableResults['settings'] = 'exists';
    }

    $sqlImported = true;

    // ============================================================
    // STEP 3: VERIFY COLUMNS ON EXISTING TABLES
    // ============================================================

    // Check users columns
    $requiredUserCols = [
        'id', 'email', 'password_hash', 'role', 'status',
        'email_verified', 'verification_token', 'remember_token',
        'token_expires', 'last_login', 'created_at', 'updated_at'
    ];
    $existingUserCols = [];
    $stmt = $pdo->query("DESCRIBE users");
    while ($row = $stmt->fetch()) {
        $existingUserCols[] = $row['Field'];
    }
    $missingUserCols = array_diff($requiredUserCols, $existingUserCols);

    foreach ($missingUserCols as $col) {
        $def = match($col) {
            'status' => "ENUM('active','inactive','suspended','pending') DEFAULT 'pending'",
            'role' => "ENUM('user','admin') DEFAULT 'user'",
            'email_verified' => "TINYINT(1) DEFAULT 0",
            'verification_token' => "VARCHAR(64) DEFAULT NULL",
            'remember_token' => "VARCHAR(64) DEFAULT NULL",
            'token_expires' => "DATETIME DEFAULT NULL",
            'last_login' => "DATETIME DEFAULT NULL",
            default => "VARCHAR(255) DEFAULT NULL"
        };
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN `$col` $def");
            $columnFixes[] = "Added users.$col";
        } catch (PDOException $e) {
            $columnFixes[] = "FAILED users.$col: " . $e->getMessage();
        }
    }

    // Check profiles columns
    $requiredProfileCols = [
        'id', 'user_id', 'profile_for', 'first_name', 'last_name', 'gender',
        'date_of_birth', 'height_cm', 'weight_kg', 'body_type', 'blood_group',
        'religion', 'caste', 'mother_tongue', 'country', 'state', 'city',
        'education', 'education_detail', 'occupation', 'occupation_detail',
        'annual_income_range', 'work_location', 'marital_status',
        'family_type', 'family_status', 'father_occupation', 'mother_occupation',
        'brothers', 'sisters', 'about_me', 'about_family', 'hobbies',
        'partner_age_min', 'partner_age_max', 'partner_height_min', 'partner_height_max',
        'partner_religion', 'partner_education', 'partner_description',
        'photo_primary', 'profile_verified', 'profile_views', 'last_active'
    ];
    $existingProfileCols = [];
    $stmt = $pdo->query("DESCRIBE profiles");
    while ($row = $stmt->fetch()) {
        $existingProfileCols[] = $row['Field'];
    }
    $missingProfileCols = array_diff($requiredProfileCols, $existingProfileCols);

    foreach ($missingProfileCols as $col) {
        $def = match($col) {
            'profile_for' => "ENUM('self','son','daughter','brother','sister','friend','relative') DEFAULT 'self'",
            'gender' => "ENUM('male','female') DEFAULT 'male'",
            'marital_status' => "ENUM('never_married','divorced','widowed','awaiting_divorce','annulled') DEFAULT 'never_married'",
            'physical_status' => "ENUM('normal','physically_challenged') DEFAULT 'normal'",
            'body_type' => "ENUM('slim','average','athletic','heavy') DEFAULT NULL",
            'blood_group' => "ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') DEFAULT NULL",
            'family_type' => "ENUM('joint','nuclear') DEFAULT NULL",
            'family_status' => "ENUM('middle_class','upper_middle_class','rich','affluent') DEFAULT NULL",
            'date_of_birth' => "DATE DEFAULT NULL",
            'height_cm' => "INT DEFAULT NULL",
            'weight_kg' => "INT DEFAULT NULL",
            'children' => "TINYINT DEFAULT 0",
            'brothers' => "TINYINT DEFAULT 0",
            'sisters' => "TINYINT DEFAULT 0",
            'partner_age_min' => "INT DEFAULT NULL",
            'partner_age_max' => "INT DEFAULT NULL",
            'partner_height_min' => "INT DEFAULT NULL",
            'partner_height_max' => "INT DEFAULT NULL",
            'profile_verified' => "TINYINT(1) DEFAULT 0",
            'profile_views' => "INT DEFAULT 0",
            'last_active' => "DATETIME DEFAULT NULL",
            'about_me' => "TEXT DEFAULT NULL",
            'about_family' => "TEXT DEFAULT NULL",
            'hobbies' => "TEXT DEFAULT NULL",
            'partner_description' => "TEXT DEFAULT NULL",
            'photo_primary' => "VARCHAR(255) DEFAULT NULL",
            default => "VARCHAR(255) DEFAULT NULL"
        };
        try {
            $pdo->exec("ALTER TABLE profiles ADD COLUMN `$col` $def");
            $columnFixes[] = "Added profiles.$col";
        } catch (PDOException $e) {
            $columnFixes[] = "FAILED profiles.$col: " . $e->getMessage();
        }
    }

    // ============================================================
    // STEP 4: ADMIN ACCOUNT
    // ============================================================
    $stmt = $pdo->query("SELECT id, email, role, status FROM users WHERE email = 'admin@vivahabandhan.com'");
    $admin = $stmt->fetch();

    if ($admin) {
        $adminExists = true;
        if ($admin['status'] !== 'active') {
            $pdo->exec("UPDATE users SET status = 'active' WHERE id = " . intval($admin['id']));
        }
        if ($admin['role'] !== 'admin') {
            $pdo->exec("UPDATE users SET role = 'admin' WHERE id = " . intval($admin['id']));
        }
    } else {
        $hash = password_hash('Admin@123456', PASSWORD_BCRYPT, ['cost' => 12]);
        $pdo->exec("INSERT INTO users (email, password_hash, role, status, email_verified) VALUES ('admin@vivahabandhan.com', '" . $hash . "', 'admin', 'active', 1)");
        $adminId = $pdo->lastInsertId();
        $pdo->exec("INSERT INTO profiles (user_id, first_name, last_name, gender, date_of_birth) VALUES ($adminId, 'Admin', 'User', 'male', '1990-01-01')");
        $adminExists = true;
    }

    // ============================================================
    // STEP 5: TEST QUERY
    // ============================================================
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM profiles p JOIN users u ON u.id = p.user_id WHERE u.status = 'active' AND u.role = 'user'");
        $testQueryOk = true;
        $testQueryMsg = 'Found ' . $stmt->fetchColumn() . ' profiles';
    } catch (PDOException $e) {
        $testQueryOk = false;
        $testQueryMsg = $e->getMessage();
    }
}

// ============================================================
// STEP 6: DIRECTORIES
// ============================================================
$dirs = [__DIR__ . '/uploads', __DIR__ . '/uploads/photos'];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        if (mkdir($dir, 0755, true)) {
            $dirResults[] = 'Created ' . $dir;
        } else {
            $dirResults[] = 'FAILED ' . $dir;
        }
    } else {
        $dirResults[] = 'Exists ' . $dir;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Diagnostic - VivahaBandhan</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DM Sans', sans-serif;
            background: #FDF8F4;
            color: #1A0A0E;
            padding: 40px 20px;
        }
        .wrap { max-width: 720px; margin: 0 auto; }
        h1 { color: #8B1A2B; font-size: 1.8rem; margin-bottom: 4px; }
        .sub { color: #8A7580; margin-bottom: 28px; }
        .section {
            background: white;
            border: 1px solid #E8DDD5;
            border-radius: 12px;
            padding: 20px 24px;
            margin-bottom: 16px;
        }
        .section h2 {
            font-size: 1.05rem;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid #F0E8E0;
            color: #4A3540;
        }
        .row {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 7px 0;
            font-size: 0.92rem;
            border-bottom: 1px solid #F8F4F0;
        }
        .row:last-child { border-bottom: none; }
        .icon-pass {
            width: 22px; height: 22px;
            background: #E8F5E9;
            color: #2D7D46;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: 700;
            flex-shrink: 0;
        }
        .icon-fail {
            width: 22px; height: 22px;
            background: #FFEBEE;
            color: #C62828;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: 700;
            flex-shrink: 0;
        }
        .icon-fix {
            width: 22px; height: 22px;
            background: #FFF8E1;
            color: #D4A843;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: 700;
            flex-shrink: 0;
        }
        .label { font-weight: 500; min-width: 140px; }
        .detail { color: #8A7580; flex: 1; }
        code {
            background: #F0E8E0;
            padding: 1px 6px;
            border-radius: 4px;
            font-size: 0.82rem;
        }
        .final-box {
            text-align: center;
            padding: 28px;
        }
        .final-box h2 { border: none; padding: 0; margin-bottom: 8px; }
        .btn {
            display: inline-block;
            background: #8B1A2B;
            color: white;
            padding: 14px 36px;
            border-radius: 99px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            margin-top: 16px;
            transition: all 0.2s;
        }
        .btn:hover { background: #6D1020; transform: translateY(-2px); }
        .btn-ghost {
            background: transparent;
            color: #8B1A2B;
            border: 2px solid #8B1A2B;
            margin-left: 8px;
        }
        .btn-ghost:hover { background: #8B1A2B; color: white; }
        .warn-box {
            background: #FFEBEE;
            border: 1px solid #C62828;
            padding: 14px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 0.9rem;
            text-align: center;
        }
        .warn-box strong { color: #C62828; }
        .creds {
            background: #1A0A0E;
            color: #FDF8F4;
            padding: 16px 24px;
            border-radius: 8px;
            display: inline-block;
            margin-top: 14px;
            font-family: 'Courier New', monospace;
            font-size: 0.92rem;
            text-align: left;
            line-height: 1.8;
        }
        .creds span { color: #D4A843; }
    </style>
</head>
<body>
<div class="wrap">

    <h1>&#9825; Database Diagnostic &amp; Auto-Fix</h1>
    <p class="sub">Checks your matrimonial database and repairs any issues automatically.</p>

    <!-- MYSQL CONNECTION -->
    <div class="section">
        <h2>&#9889; MySQL Connection</h2>
        <div class="row">
            <?php if ($connOk): ?>
                <span class="icon-pass">&#10003;</span>
                <span class="label">MySQL</span>
                <span class="detail"><?php echo htmlspecialchars($connMsg); ?></span>
            <?php else: ?>
                <span class="icon-fail">&#10007;</span>
                <span class="label">MySQL</span>
                <span class="detail"><?php echo htmlspecialchars($connMsg); ?></span>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!$connOk): ?>
    <div class="section">
        <h2>&#9888; Cannot Continue</h2>
        <p>MySQL connection failed. Please check:</p>
        <ul style="margin-top:10px;padding-left:20px;line-height:2;">
            <li>Is <strong>MySQL running</strong> in XAMPP Control Panel?</li>
            <li>Open <a href="http://localhost/phpmyadmin" target="_blank">phpMyAdmin</a> to verify</li>
            <li>Check <code>config/database.php</code> for correct host/port/password</li>
        </ul>
    </div>
    <?php else: ?>

    <!-- DATABASE -->
    <div class="section">
        <h2>&#128451; Database</h2>
        <div class="row">
            <span class="icon-pass">&#10003;</span>
            <span class="label">matrimonial_db</span>
            <span class="detail"><?php echo $dbCreated ? 'Ready' : 'Error creating'; ?></span>
        </div>
    </div>

    <!-- TABLES -->
    <div class="section">
        <h2>&#128202; Tables</h2>
        <?php foreach ($tableResults as $name => $status): ?>
        <div class="row">
            <?php if ($status === 'exists'): ?>
                <span class="icon-pass">&#10003;</span>
            <?php else: ?>
                <span class="icon-fix">&#9881;</span>
            <?php endif; ?>
            <span class="label"><code><?php echo htmlspecialchars($name); ?></code></span>
            <span class="detail"><?php echo $status === 'exists' ? 'Already existed' : 'Created now'; ?></span>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- COLUMN FIXES -->
    <div class="section">
        <h2>&#128269; Column Verification</h2>
        <?php if (empty($columnFixes)): ?>
            <div class="row">
                <span class="icon-pass">&#10003;</span>
                <span class="detail">All columns verified - no fixes needed</span>
            </div>
        <?php else: ?>
            <?php foreach ($columnFixes as $fix): ?>
            <div class="row">
                <?php if (strpos($fix, 'FAILED') === 0): ?>
                    <span class="icon-fail">&#10007;</span>
                <?php else: ?>
                    <span class="icon-fix">&#9881;</span>
                <?php endif; ?>
                <span class="detail"><?php echo htmlspecialchars($fix); ?></span>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- ADMIN ACCOUNT -->
    <div class="section">
        <h2>&#128100; Admin Account</h2>
        <div class="row">
            <?php if ($adminExists): ?>
                <span class="icon-pass">&#10003;</span>
                <span class="label">admin@vivahabandhan.com</span>
                <span class="detail">Exists and active</span>
            <?php else: ?>
                <span class="icon-fail">&#10007;</span>
                <span class="detail">Could not create admin account</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- UPLOADS -->
    <div class="section">
        <h2>&#128193; Upload Directories</h2>
        <?php foreach ($dirResults as $dr): ?>
        <div class="row">
            <?php if (strpos($dr, 'FAILED') === 0): ?>
                <span class="icon-fail">&#10007;</span>
            <?php elseif (strpos($dr, 'Created') === 0): ?>
                <span class="icon-fix">&#9881;</span>
            <?php else: ?>
                <span class="icon-pass">&#10003;</span>
            <?php endif; ?>
            <span class="detail"><?php echo htmlspecialchars($dr); ?></span>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- TEST QUERY -->
    <div class="section">
        <h2>&#128270; Test Query (search.php)</h2>
        <div class="row">
            <?php if ($testQueryOk): ?>
                <span class="icon-pass">&#10003;</span>
                <span class="detail"><?php echo htmlspecialchars($testQueryMsg); ?></span>
            <?php else: ?>
                <span class="icon-fail">&#10007;</span>
                <span class="detail"><?php echo htmlspecialchars($testQueryMsg); ?></span>
            <?php endif; ?>
        </div>
    </div>

    <!-- FINAL RESULT -->
    <div class="section final-box">
        <h2>&#10003; Diagnostic Complete</h2>
        <p>All checks and repairs have been applied.</p>
        <div class="creds">
            <span>Admin Email:</span> admin@vivahabandhan.com<br>
            <span>Password:</span> Admin@123456
        </div>
        <br>
        <a href="http://localhost/matrimonial/" class="btn">Visit Website &#8594;</a>
        <a href="http://localhost/matrimonial/search.php" class="btn btn-ghost">Test Search</a>
        <div class="warn-box">
            <strong>&#9888; Security:</strong> Delete <code>diagnose.php</code> and <code>setup.php</code> after this works!
        </div>
    </div>

    <?php endif; ?>

</div>
</body>
</html>
