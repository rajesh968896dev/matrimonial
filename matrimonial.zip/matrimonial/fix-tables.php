<?php
// File: fix-tables.php
// Open: http://localhost/matrimonial/fix-tables.php
// This DROPS everything and rebuilds the entire database correctly.

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance();
$logs = [];

function logMsg($msg, $ok = true) {
    global $logs;
    $logs[] = ['msg' => $msg, 'ok' => $ok];
}

// ============================================================
// STEP 1: DROP all tables (clean slate)
// ============================================================
logMsg("Dropping all existing tables...");

try {
    $db->exec("SET FOREIGN_KEY_CHECKS = 0");

    $tables = ['profile_views', 'activity_log', 'settings', 'messages',
               'shortlists', 'interests', 'profiles', 'users'];

    foreach ($tables as $table) {
        try {
            $db->exec("DROP TABLE IF EXISTS `$table`");
            logMsg("Dropped `$table`");
        } catch (Exception $e) {
            logMsg("Drop `$table`: " . $e->getMessage(), false);
        }
    }

    $db->exec("SET FOREIGN_KEY_CHECKS = 1");
    logMsg("All tables dropped.");
} catch (Exception $e) {
    logMsg("Drop error: " . $e->getMessage(), false);
}

// ============================================================
// STEP 2: CREATE users table
// ============================================================
logMsg("Creating `users` table...");
try {
    $db->exec("CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(10) NOT NULL DEFAULT 'user',
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        email_verified TINYINT(1) NOT NULL DEFAULT 0,
        verification_token VARCHAR(64) DEFAULT NULL,
        remember_token VARCHAR(64) DEFAULT NULL,
        token_expires DATETIME DEFAULT NULL,
        last_login DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY idx_email (email),
        KEY idx_status (status),
        KEY idx_role (role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`users` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE users FAILED: " . $e->getMessage(), false);
    // Show table structure for debugging
    try {
        $cols = $db->query("DESCRIBE users")->fetchAll();
        logMsg("Current users columns: " . implode(', ', array_column($cols, 'Field')));
    } catch (Exception $e2) {}
}

// ============================================================
// STEP 3: CREATE profiles table
// ============================================================
logMsg("Creating `profiles` table...");
try {
    $db->exec("CREATE TABLE profiles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        profile_for VARCHAR(20) DEFAULT 'self',
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        gender VARCHAR(10) NOT NULL,
        date_of_birth DATE NOT NULL,
        height_cm INT DEFAULT NULL,
        weight_kg INT DEFAULT NULL,
        body_type VARCHAR(20) DEFAULT NULL,
        complexion VARCHAR(20) DEFAULT NULL,
        blood_group VARCHAR(5) DEFAULT NULL,
        physical_status VARCHAR(30) DEFAULT 'normal',
        religion VARCHAR(100) DEFAULT NULL,
        caste VARCHAR(100) DEFAULT NULL,
        sub_caste VARCHAR(100) DEFAULT NULL,
        gothra VARCHAR(100) DEFAULT NULL,
        star VARCHAR(100) DEFAULT NULL,
        rashi VARCHAR(100) DEFAULT NULL,
        mother_tongue VARCHAR(100) DEFAULT NULL,
        country VARCHAR(100) DEFAULT 'India',
        state VARCHAR(100) DEFAULT NULL,
        city VARCHAR(100) DEFAULT NULL,
        citizenship VARCHAR(100) DEFAULT NULL,
        education VARCHAR(200) DEFAULT NULL,
        education_detail VARCHAR(300) DEFAULT NULL,
        occupation VARCHAR(200) DEFAULT NULL,
        occupation_detail VARCHAR(300) DEFAULT NULL,
        annual_income_range VARCHAR(100) DEFAULT NULL,
        work_location VARCHAR(200) DEFAULT NULL,
        marital_status VARCHAR(30) DEFAULT 'never_married',
        children TINYINT DEFAULT 0,
        family_type VARCHAR(20) DEFAULT NULL,
        family_status VARCHAR(30) DEFAULT NULL,
        father_occupation VARCHAR(200) DEFAULT NULL,
        mother_occupation VARCHAR(200) DEFAULT NULL,
        brothers TINYINT DEFAULT 0,
        brothers_married TINYINT DEFAULT 0,
        sisters TINYINT DEFAULT 0,
        sisters_married TINYINT DEFAULT 0,
        about_me TEXT DEFAULT NULL,
        about_family TEXT DEFAULT NULL,
        hobbies TEXT DEFAULT NULL,
        partner_age_min INT DEFAULT NULL,
        partner_age_max INT DEFAULT NULL,
        partner_height_min INT DEFAULT NULL,
        partner_height_max INT DEFAULT NULL,
        partner_religion VARCHAR(100) DEFAULT NULL,
        partner_caste VARCHAR(100) DEFAULT NULL,
        partner_education VARCHAR(200) DEFAULT NULL,
        partner_occupation VARCHAR(200) DEFAULT NULL,
        partner_location VARCHAR(200) DEFAULT NULL,
        partner_marital_status VARCHAR(200) DEFAULT NULL,
        partner_annual_income VARCHAR(100) DEFAULT NULL,
        partner_description TEXT DEFAULT NULL,
        photo_primary VARCHAR(255) DEFAULT NULL,
        photo_gallery TEXT DEFAULT NULL,
        profile_verified TINYINT(1) NOT NULL DEFAULT 0,
        profile_boosted_until DATETIME DEFAULT NULL,
        profile_views INT NOT NULL DEFAULT 0,
        last_active DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY idx_user_id (user_id),
        KEY idx_gender (gender),
        KEY idx_religion (religion),
        KEY idx_country (country),
        KEY idx_state (state),
        KEY idx_city (city),
        KEY idx_education (education),
        KEY idx_marital_status (marital_status),
        KEY idx_dob (date_of_birth),
        KEY idx_last_active (last_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`profiles` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE profiles FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 4: CREATE interests table
// ============================================================
logMsg("Creating `interests` table...");
try {
    $db->exec("CREATE TABLE interests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        message TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_interest (sender_id, receiver_id),
        KEY idx_receiver_status (receiver_id, status),
        KEY idx_sender_status (sender_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`interests` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE interests FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 5: CREATE shortlists table
// ============================================================
logMsg("Creating `shortlists` table...");
try {
    $db->exec("CREATE TABLE shortlists (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        shortlisted_user_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_shortlist (user_id, shortlisted_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`shortlists` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE shortlists FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 6: CREATE messages table
// ============================================================
logMsg("Creating `messages` table...");
try {
    $db->exec("CREATE TABLE messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_sender (sender_id),
        KEY idx_receiver_read (receiver_id, is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`messages` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE messages FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 7: CREATE profile_views table
// ============================================================
logMsg("Creating `profile_views` table...");
try {
    $db->exec("CREATE TABLE profile_views (
        id INT AUTO_INCREMENT PRIMARY KEY,
        viewer_id INT NOT NULL,
        viewed_id INT NOT NULL,
        viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_viewed (viewed_id, viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`profile_views` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE profile_views FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 8: CREATE activity_log table
// ============================================================
logMsg("Creating `activity_log` table...");
try {
    $db->exec("CREATE TABLE activity_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT DEFAULT NULL,
        action VARCHAR(100) NOT NULL,
        ip_address VARCHAR(45) DEFAULT NULL,
        user_agent TEXT DEFAULT NULL,
        details TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_user_action (user_id, action),
        KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`activity_log` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE activity_log FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 9: CREATE settings table
// ============================================================
logMsg("Creating `settings` table...");
try {
    $db->exec("CREATE TABLE settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(100) NOT NULL,
        setting_value TEXT DEFAULT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY idx_key (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("`settings` table created successfully.");
} catch (PDOException $e) {
    logMsg("CREATE settings FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 10: INSERT admin account
// ============================================================
logMsg("Creating admin account...");
try {
    $hash = password_hash('Admin@123456', PASSWORD_BCRYPT, ['cost' => 12]);
    $db->exec("INSERT INTO users (email, password_hash, role, status, email_verified) VALUES ('admin@vivahabandhan.com', '$hash', 'admin', 'active', 1)");
    $adminId = $db->lastInsertId();
    $db->exec("INSERT INTO profiles (user_id, first_name, last_name, gender, date_of_birth) VALUES ($adminId, 'Admin', 'User', 'male', '1990-01-01')");
    logMsg("Admin account created (ID: $adminId).");
} catch (PDOException $e) {
    logMsg("Admin creation: " . $e->getMessage(), false);
}

// ============================================================
// STEP 11: INSERT sample test users
// ============================================================
logMsg("Creating sample profiles...");
try {
    $samples = [
        ['Priya', 'Sharma', 'female', '1995-03-15', 'Hindu', 'Mumbai', 'Maharashtra', 'MBA', 'Software Engineer'],
        ['Rahul', 'Verma', 'male', '1992-07-22', 'Hindu', 'Delhi', 'Delhi', 'B.Tech', 'Data Analyst'],
        ['Sneha', 'Patel', 'female', '1997-11-08', 'Hindu', 'Ahmedabad', 'Gujarat', 'MBBS', 'Doctor'],
        ['Amit', 'Kumar', 'male', '1990-01-30', 'Hindu', 'Bangalore', 'Karnataka', 'M.Tech', 'Software Architect'],
        ['Anjali', 'Singh', 'female', '1994-06-12', 'Sikh', 'Chandigarh', 'Punjab', 'CA', 'Chartered Accountant'],
        ['Vikram', 'Rao', 'male', '1993-09-05', 'Hindu', 'Hyderabad', 'Telangana', 'MBA', 'Product Manager'],
        ['Meera', 'Nair', 'female', '1996-04-18', 'Hindu', 'Kochi', 'Kerala', 'B.Tech', 'UI Designer'],
        ['Arjun', 'Reddy', 'male', '1991-12-01', 'Hindu', 'Chennai', 'Tamil Nadu', 'MS', 'Research Scientist'],
        ['Kavya', 'Iyer', 'female', '1998-02-25', 'Hindu', 'Pune', 'Maharashtra', 'B.Tech', 'Marketing Manager'],
        ['Rohan', 'Gupta', 'male', '1989-08-14', 'Hindu', 'Kolkata', 'West Bengal', 'PhD', 'Professor'],
        ['Fatima', 'Khan', 'female', '1995-10-20', 'Muslim', 'Lucknow', 'Uttar Pradesh', 'M.Tech', 'Software Engineer'],
        ['David', 'Thomas', 'male', '1993-05-03', 'Christian', 'Goa', 'Goa', 'MBA', 'Business Analyst'],
    ];

    foreach ($samples as $s) {
        $hash = password_hash('Test@12345', PASSWORD_BCRYPT, ['cost' => 10]);
        $db->exec("INSERT INTO users (email, password_hash, role, status, email_verified) VALUES ('" . strtolower($s[0]) . "." . strtolower($s[1]) . "@test.com', '$hash', 'user', 'active', 1)");
        $uid = $db->lastInsertId();
        $db->exec("INSERT INTO profiles (user_id, first_name, last_name, gender, date_of_birth, religion, city, state, education, occupation, marital_status, about_me, last_active)
            VALUES ($uid, '$s[0]', '$s[1]', '$s[2]', '$s[3]', '$s[4]', '$s[5]', '$s[6]', '$s[7]', '$s[8]', 'never_married', 'Looking for a life partner.', NOW())");
    }
    logMsg(count($samples) . " sample profiles created.");
} catch (PDOException $e) {
    logMsg("Sample data: " . $e->getMessage(), false);
}

// ============================================================
// STEP 12: VERIFY - run the exact query that was failing
// ============================================================
logMsg("Running verification query...");
try {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM profiles p JOIN users u ON u.id = p.user_id WHERE u.status = 'active' AND u.role = 'user'");
    $row = $stmt->fetch();
    logMsg("VERIFICATION PASSED - Found " . $row['cnt'] . " active profiles. The search page will now work!");
} catch (PDOException $e) {
    logMsg("VERIFICATION FAILED: " . $e->getMessage(), false);
}

// ============================================================
// STEP 13: Create uploads directory
// ============================================================
foreach ([__DIR__ . '/uploads', __DIR__ . '/uploads/photos'] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        logMsg("Created directory: $dir");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Tables - VivahaBandhan</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #FDF8F4; color: #1A0A0E; padding: 40px 20px; }
        .wrap { max-width: 680px; margin: 0 auto; }
        .card { background: white; border: 1px solid #E8DDD5; border-radius: 16px; overflow: hidden; box-shadow: 0 8px 30px rgba(0,0,0,0.06); }
        .card-header { background: linear-gradient(135deg, #1A0A0E, #2D0A15); color: #FDF8F4; padding: 28px; text-align: center; }
        .card-header h1 { font-size: 1.6rem; margin-bottom: 4px; }
        .card-header p { color: rgba(253,248,244,0.5); font-size: 0.9rem; }
        .card-body { padding: 28px; }
        .log { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #F8F4F0; font-size: 0.88rem; }
        .log:last-child { border-bottom: none; }
        .log-ok { color: #2D7D46; }
        .log-err { color: #C62828; }
        .dot { width: 20px; height: 20px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 0.65rem; font-weight: 700; flex-shrink: 0; }
        .dot-ok { background: #E8F5E9; color: #2D7D46; }
        .dot-err { background: #FFEBEE; color: #C62828; }
        .result { text-align: center; margin-top: 24px; padding: 24px; background: #E8F5E9; border: 2px solid #2D7D46; border-radius: 12px; }
        .result h2 { margin-bottom: 8px; }
        .result p { color: #4A3540; margin-bottom: 6px; }
        .btn { display: inline-block; background: #8B1A2B; color: white; padding: 14px 36px; border-radius: 99px; text-decoration: none; font-weight: 600; margin-top: 16px; transition: all 0.2s; }
        .btn:hover { background: #6D1020; transform: translateY(-2px); }
        .btn-ghost { background: transparent; color: #8B1A2B; border: 2px solid #8B1A2B; margin-left: 8px; }
        .btn-ghost:hover { background: #8B1A2B; color: white; }
        .warn { background: #FFEBEE; border: 1px solid #C62828; padding: 12px; border-radius: 8px; margin-top: 16px; font-size: 0.88rem; text-align: center; }
        .creds { background: #1A0A0E; color: #FDF8F4; padding: 16px 24px; border-radius: 8px; display: inline-block; margin-top: 14px; font-family: 'Courier New', monospace; font-size: 0.9rem; line-height: 1.8; text-align: left; }
        .creds span { color: #D4A843; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <div class="card-header">
            <h1>&#9825; Database Rebuild</h1>
            <p>Matrimonial Database - Complete Reset</p>
        </div>
        <div class="card-body">
            <?php foreach ($logs as $log): ?>
            <div class="log <?php echo $log['ok'] ? 'log-ok' : 'log-err'; ?>">
                <span class="dot <?php echo $log['ok'] ? 'dot-ok' : 'dot-err'; ?>">
                    <?php echo $log['ok'] ? '&#10003;' : '&#10007;'; ?>
                </span>
                <span><?php echo htmlspecialchars($log['msg']); ?></span>
            </div>
            <?php endforeach; ?>

            <?php
            $hasErrors = false;
            foreach ($logs as $log) {
                if (!$log['ok']) { $hasErrors = true; break; }
            }
            ?>

            <?php if (!$hasErrors): ?>
            <div class="result">
                <h2>&#10003; Database Rebuilt Successfully!</h2>
                <p>All tables created and verified. The search page will now work.</p>
                <p>12 sample profiles have been added for testing.</p>
                <div class="creds">
                    <span>Admin:</span> admin@vivahabandhan.com<br>
                    <span>Password:</span> Admin@123456<br><br>
                    <span>Test users:</span> (any sample profile)<br>
                    <span>Password:</span> Test@12345
                </div>
                <br>
                <a href="http://localhost/matrimonial/" class="btn">Visit Website &#8594;</a>
                <a href="http://localhost/matrimonial/search.php" class="btn btn-ghost">Test Search</a>
            </div>
            <?php else: ?>
            <div style="text-align:center;margin-top:20px;padding:20px;background:#FFEBEE;border:2px solid #C62828;border-radius:12px;">
                <h2>&#9888; Some Errors Occurred</h2>
                <p style="margin-top:8px;">Check the error messages above. The most common fix is:</p>
                <p style="margin-top:8px;">Make sure <strong>MySQL is running</strong> in XAMPP and your password in <code>config/database.php</code> is correct.</p>
            </div>
            <?php endif; ?>

            <div class="warn">
                <strong>&#9888; Delete <code>fix-tables.php</code> after everything works!</strong>
            </div>
        </div>
    </div>
</div>
</body>
</html>
