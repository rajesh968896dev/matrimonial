<?php
// File: logout.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$auth = new Auth();
$auth->logout();
setFlash('success', 'You have been logged out successfully.');
header('Location: ' . BASE_URL . '/index.php');
exit;
