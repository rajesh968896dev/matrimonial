<?php
// File: admin/users.php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();
$db = Database::getInstance();

// Handle status change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    if (verifyCsrfToken()) {
        $targetId = intval($_POST['user_id']);
        $newStatus = $_POST['new_status'];
        if (in_array($newStatus, ['active', 'inactive', 'suspended'])) {
            $stmt = $db->prepare("UPDATE users SET status = ? WHERE id = ? AND role != 'admin'");
            $stmt->execute([$newStatus, $targetId]);
            logActivity('admin_update_status', $_SESSION['user_id'], "User $targetId -> $newStatus");
            setFlash('success', 'User status updated.');
            header('Location: ' . BASE_URL . '/admin/users.php');
            exit;
        }
    }
}

$statusFilter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$where = ["u.role = 'user'"];
$params = [];
if ($statusFilter && in_array($statusFilter, ['active', 'inactive', 'suspended', 'pending'])) {
    $where[] = "u.status = ?";
    $params[] = $statusFilter;
}

$search = $_GET['q'] ?? '';
if ($search) {
    $where[] = "(p.first_name LIKE ? OR p.last_name LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$whereClause = implode(' AND ', $where);

$stmt = $db->prepare("SELECT COUNT(*) FROM users u LEFT JOIN profiles p ON p.user_id = u.id WHERE $whereClause");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $perPage);

$stmt = $db->prepare("SELECT u.*, p.first_name, p.last_name, p.gender, p.city, p.state FROM users u LEFT JOIN profiles p ON p.user_id = u.id WHERE $whereClause ORDER BY u.created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'Manage Users';
include __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div style="padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,0.1);margin-bottom:16px;">
            <h3 style="color:var(--text-on-dark);font-size:1.1rem;">Admin Panel</h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="<?php echo BASE_URL; ?>/admin/">&#127968; Dashboard</a></li>
            <li><a href="<?php echo BASE_URL; ?>/admin/users.php" class="active">&#128101; Users</a></li>
            <li><a href="<?php echo BASE_URL; ?>/admin/users.php?status=pending">&#9203; Pending</a></li>
            <li><a href="<?php echo BASE_URL; ?>/">&#8592; Back to Site</a></li>
        </ul>
    </aside>

    <div class="admin-content">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
            <h1>Manage Users (<?php echo number_format($total); ?>)</h1>
            <form method="GET" style="display:flex;gap:8px;">
                <input type="text" name="q" class="form-control" placeholder="Search name or email..." value="<?php echo sanitize($search); ?>" style="width:250px;">
                <button type="submit" class="btn btn-primary btn-sm">Search</button>
            </form>
        </div>

        <div style="display:flex;gap:8px;margin-bottom:20px;">
            <a href="<?php echo BASE_URL; ?>/admin/users.php" class="btn btn-sm <?php echo !$statusFilter ? 'btn-primary' : 'btn-ghost'; ?>">All</a>
            <a href="<?php echo BASE_URL; ?>/admin/users.php?status=active" class="btn btn-sm <?php echo $statusFilter === 'active' ? 'btn-primary' : 'btn-ghost'; ?>">Active</a>
            <a href="<?php echo BASE_URL; ?>/admin/users.php?status=pending" class="btn btn-sm <?php echo $statusFilter === 'pending' ? 'btn-primary' : 'btn-ghost'; ?>">Pending</a>
            <a href="<?php echo BASE_URL; ?>/admin/users.php?status=inactive" class="btn btn-sm <?php echo $statusFilter === 'inactive' ? 'btn-primary' : 'btn-ghost'; ?>">Inactive</a>
            <a href="<?php echo BASE_URL; ?>/admin/users.php?status=suspended" class="btn btn-sm <?php echo $statusFilter === 'suspended' ? 'btn-primary' : 'btn-ghost'; ?>">Suspended</a>
        </div>

        <div class="data-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td>#<?php echo $user['id']; ?></td>
                        <td><strong><?php echo sanitize(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?></strong></td>
                        <td><?php echo sanitize($user['email']); ?></td>
                        <td><?php echo ucfirst($user['gender'] ?? '-'); ?></td>
                        <td><?php echo sanitize(($user['city'] ?? '') . ($user['city'] && $user['state'] ? ', ' : '') . ($user['state'] ?? '')); ?></td>
                        <td><span class="status-badge status-<?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                        <td><?php echo timeAgo($user['created_at']); ?></td>
                        <td style="display:flex;gap:4px;">
                            <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $user['id']; ?>" class="btn btn-ghost btn-sm">View</a>
                            <form method="POST" style="display:flex;gap:4px;" onsubmit="return confirm('Update this user\'s status?');">
                                <?php echo csrfField(); ?>
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <select name="new_status" class="form-control" style="padding:4px 8px;font-size:0.8rem;width:auto;">
                                    <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo $user['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    <option value="suspended" <?php echo $user['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-primary btn-sm">Save</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php echo pagination($page, $totalPages, BASE_URL . '/admin/users.php?' . http_build_query(array_filter(['status' => $statusFilter, 'q' => $search])) . '&'); ?>
    </div>
</div>
