<?php
// File: admin/index.php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();
$db = Database::getInstance();

// Stats
$totalUsers = $db->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$activeUsers = $db->query("SELECT COUNT(*) FROM users WHERE role = 'user' AND status = 'active'")->fetchColumn();
$totalInterests = $db->query("SELECT COUNT(*) FROM interests")->fetchColumn();
$totalMessages = $db->query("SELECT COUNT(*) FROM messages")->fetchColumn();
$newToday = $db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();

// Recent users
$recentUsers = $db->query("SELECT u.*, p.first_name, p.last_name, p.gender, p.city FROM users u LEFT JOIN profiles p ON p.user_id = u.id WHERE u.role = 'user' ORDER BY u.created_at DESC LIMIT 10")->fetchAll();

$pageTitle = 'Admin Dashboard';
include __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div style="padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,0.1);margin-bottom:16px;">
            <h3 style="color:var(--text-on-dark);font-size:1.1rem;">Admin Panel</h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="<?php echo BASE_URL; ?>/admin/" class="active">&#127968; Dashboard</a></li>
            <li><a href="<?php echo BASE_URL; ?>/admin/users.php">&#128101; Users</a></li>
            <li><a href="<?php echo BASE_URL; ?>/admin/users.php?status=pending">&#9203; Pending Approval</a></li>
            <li><a href="<?php echo BASE_URL; ?>/search.php">&#128270; Search Profiles</a></li>
            <li><a href="<?php echo BASE_URL; ?>/">&#8592; Back to Site</a></li>
        </ul>
    </aside>

    <div class="admin-content">
        <h1 style="margin-bottom:24px;">Dashboard</h1>

        <div class="admin-stat-cards">
            <div class="admin-stat-card">
                <div class="stat-icon" style="background:var(--accent-glow);color:var(--accent);">&#128101;</div>
                <div class="stat-number"><?php echo number_format($totalUsers); ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="admin-stat-card">
                <div class="stat-icon" style="background:var(--success-bg);color:var(--success);">&#10003;</div>
                <div class="stat-number"><?php echo number_format($activeUsers); ?></div>
                <div class="stat-label">Active Users</div>
            </div>
            <div class="admin-stat-card">
                <div class="stat-icon" style="background:var(--warning-bg);color:var(--gold);">&#9825;</div>
                <div class="stat-number"><?php echo number_format($totalInterests); ?></div>
                <div class="stat-label">Total Interests</div>
            </div>
            <div class="admin-stat-card">
                <div class="stat-icon" style="background:var(--info-bg);color:var(--info);">&#128172;</div>
                <div class="stat-number"><?php echo number_format($totalMessages); ?></div>
                <div class="stat-label">Messages Sent</div>
            </div>
        </div>

        <div class="card" style="margin-bottom:16px;">
            <div class="card-body" style="display:flex;align-items:center;gap:12px;">
                <span style="font-size:1.5rem;">&#128640;</span>
                <div>
                    <strong><?php echo $newToday; ?> new registrations today</strong>
                </div>
            </div>
        </div>

        <h2 style="margin:32px 0 16px;">Recent Registrations</h2>
        <div class="data-table">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentUsers as $user): ?>
                    <tr>
                        <td><strong><?php echo sanitize(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?></strong></td>
                        <td><?php echo sanitize($user['email']); ?></td>
                        <td><?php echo ucfirst($user['gender'] ?? 'N/A'); ?></td>
                        <td><?php echo sanitize($user['city'] ?? 'N/A'); ?></td>
                        <td><span class="status-badge status-<?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                        <td><?php echo timeAgo($user['created_at']); ?></td>
                        <td>
                            <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $user['id']; ?>" class="btn btn-ghost btn-sm">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php // No footer for admin layout - add inline if needed ?>
