<?php
// File: settings.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$success = '';
$error = '';

// Password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!verifyCsrfToken()) { $error = 'Invalid request.'; }
    else {
        $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!verifyPassword($_POST['current_password'] ?? '', $user['password_hash'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($_POST['new_password'] ?? '') < PASSWORD_MIN_LENGTH) {
            $error = 'New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.';
        } elseif (($_POST['new_password'] ?? '') !== ($_POST['confirm_password'] ?? '')) {
            $error = 'New passwords do not match.';
        } else {
            $stmt = $db->prepare("UPDATE users SET password_hash = ?, remember_token = NULL WHERE id = ?");
            $stmt->execute([hashPassword($_POST['new_password']), $userId]);
            setFlash('success', 'Password changed successfully.');
            header('Location: ' . BASE_URL . '/settings.php');
            exit;
        }
    }
}

// Delete account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_account'])) {
    if (!verifyCsrfToken()) { $error = 'Invalid request.'; }
    else {
        $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!verifyPassword($_POST['confirm_password_del'] ?? '', $user['password_hash'])) {
            $error = 'Password incorrect. Account not deleted.';
        } else {
            $stmt = $db->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
            $stmt->execute([$userId]);
            $auth = new Auth();
            $auth->logout();
            setFlash('success', 'Your account has been deactivated.');
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        }
    }
}

$pageTitle = 'Account Settings';
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;max-width:600px;">
    <h1 style="margin-bottom:32px;">Account Settings</h1>

    <?php if ($error): ?>
        <div class="flash flash-error" style="position:static;margin-bottom:20px;"><span><?php echo sanitize($error); ?></span></div>
    <?php endif; ?>

    <!-- Change Password -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-body">
            <h3 class="profile-section-title" style="margin-top:0;">Change Password</h3>
            <form method="POST" action="">
                <?php echo csrfField(); ?>
                <div class="form-group">
                    <label class="form-label">Current Password</label>
                    <input type="password" name="current_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" class="form-control" required minlength="8">
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                <button type="submit" name="change_password" class="btn btn-primary">Update Password</button>
            </form>
        </div>
    </div>

    <!-- Account Info -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-body">
            <h3 class="profile-section-title" style="margin-top:0;">Account Information</h3>
            <div class="detail-item">
                <div class="detail-label">Email</div>
                <div class="detail-value"><?php echo sanitize($currentUser['email'] ?? ''); ?></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Member Since</div>
                <div class="detail-value"><?php echo date('F j, Y', strtotime($currentUser['created_at'] ?? 'now')); ?></div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Profile Status</div>
                <div class="detail-value"><span class="status-badge status-active">Active</span></div>
            </div>
        </div>
    </div>

    <!-- Danger Zone -->
    <div class="card" style="border-color:var(--error);">
        <div class="card-body">
            <h3 class="profile-section-title" style="margin-top:0;color:var(--error);">Danger Zone</h3>
            <p style="color:var(--text-muted);margin-bottom:16px;">Deactivating your account will hide your profile from all searches and matches.</p>
            <form method="POST" action="" onsubmit="return confirm('Are you sure you want to deactivate your account?');">
                <?php echo csrfField(); ?>
                <div class="form-group">
                    <label class="form-label">Enter password to confirm</label>
                    <input type="password" name="confirm_password_del" class="form-control" required>
                </div>
                <button type="submit" name="delete_account" class="btn" style="background:var(--error);color:white;">Deactivate Account</button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
