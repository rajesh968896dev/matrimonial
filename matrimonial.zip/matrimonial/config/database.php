<?php
// File: config/database.php

if (!defined('APP_RUNNING')) { die('Direct access not permitted'); }

class Database {
    private static ?PDO $instance = null;

    private const HOST = 'localhost';
    private const DB_NAME = 'matrimonial_db';
    private const USERNAME = 'root';
    private const PASSWORD = 'admin';
    private const CHARSET = 'utf8mb4';

    private function __construct() {}
    private function __clone() {}

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            try {
                $dsn = "mysql:host=" . self::HOST . ";dbname=" . self::DB_NAME . ";charset=" . self::CHARSET;
                self::$instance = new PDO($dsn, self::USERNAME, self::PASSWORD, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                ]);
            } catch (PDOException $e) {
                error_log("Database connection failed: " . $e->getMessage());
                die("Database connection error. Please check configuration.");
            }
        }
        return self::$instance;
    }
}
