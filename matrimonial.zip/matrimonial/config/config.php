<?php
// File: config/config.php

// Prevent direct access
if (!defined('APP_RUNNING')) { define('APP_RUNNING', true); }

// Base Configuration
define('BASE_URL', 'http://localhost/matrimonial');
define('BASE_PATH', dirname(__DIR__));
define('UPLOAD_PATH', BASE_PATH . '/uploads');
define('PROFILE_PHOTOS_PATH', UPLOAD_PATH . '/photos');

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // Set to 1 with HTTPS
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.gc_maxlifetime', 1800);

// Security
define('CSRF_TOKEN_NAME', 'csrf_token');
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes
define('PASSWORD_MIN_LENGTH', 8);

// Upload Limits
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);

// Pagination
define('PROFILES_PER_PAGE', 12);
define('MESSAGES_PER_PAGE', 20);

// Timezone
date_default_timezone_set('Asia/Kolkata');
