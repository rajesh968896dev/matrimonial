<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance();

echo "<h2>Admin Account Check</h2>";

// Check if admin exists
$stmt = $db->query("SELECT id, email, role, status, email_verified FROM users WHERE email = 'admin@vivahabandhan.com'");
$admin = $stmt->fetch();

if (!$admin) {
    echo "<p style='color:red;'>Admin account NOT found. Creating now...</p>";

    $hash = password_hash('Admin@123456', PASSWORD_BCRYPT, ['cost' => 12]);
    $db->exec("INSERT INTO users (email, password_hash, role, status, email_verified)
                VALUES ('admin@vivahabandhan.com', '$hash', 'admin', 'active', 1)");
    $adminId = $db->lastInsertId();
    $db->exec("INSERT INTO profiles (user_id, first_name, last_name, gender, date_of_birth)
                VALUES ($adminId, 'Admin', 'User', 'male', '1990-01-01')");

    echo "<p style='color:green;'>Admin created with ID: $adminId</p>";
    echo "<p>Login at: <a href='http://localhost/matrimonial/login.php'>Login Page</a></p>";

} else {
    echo "<p style='color:green;'>Admin account EXISTS</p>";
    echo "<table border='1' cellpadding='8' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Email</th><th>Role</th><th>Status</th><th>Verified</th></tr>";
    echo "<tr>";
    echo "<td>" . $admin['id'] . "</td>";
    echo "<td>" . $admin['email'] . "</td>";
    echo "<td>" . $admin['role'] . "</td>";
    echo "<td>" . $admin['status'] . "</td>";
    echo "<td>" . $admin['email_verified'] . "</td>";
    echo "</tr></table>";

    // Fix if needed
    $fixed = false;
    if ($admin['role'] !== 'admin') {
        $db->exec("UPDATE users SET role = 'admin' WHERE id = " . $admin['id']);
        echo "<p style='color:orange;'>Fixed: role set to 'admin'</p>";
        $fixed = true;
    }
    if ($admin['status'] !== 'active') {
        $db->exec("UPDATE users SET status = 'active' WHERE id = " . $admin['id']);
        echo "<p style='color:orange;'>Fixed: status set to 'active'</p>";
        $fixed = true;
    }
    if ($admin['email_verified'] != 1) {
        $db->exec("UPDATE users SET email_verified = 1 WHERE id = " . $admin['id']);
        echo "<p style='color:orange;'>Fixed: email_verified set to 1</p>";
        $fixed = true;
    }

    if ($fixed) {
        echo "<p style='color:green;'>Account fixed. Try logging in now.</p>";
    } else {
        echo "<p style='color:green;'>Account is correctly configured.</p>";
    }

    // Test password verification
    echo "<h3>Testing Password...</h3>";
    $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$admin['id']]);
    $hash = $stmt->fetchColumn();

    if (password_verify('Admin@123456', $hash)) {
        echo "<p style='color:green;'>Password verification: CORRECT</p>";
    } else {
        echo "<p style='color:red;'>Password verification: FAILED. Resetting password...</p>";
        $newHash = password_hash('Admin@123456', PASSWORD_BCRYPT, ['cost' => 12]);
        $db->exec("UPDATE users SET password_hash = '" . $newHash . "' WHERE id = " . $admin['id']);
        echo "<p style='color:green;'>Password reset to: Admin@123456</p>";
    }
}

echo "<hr>";
echo "<h3>Login Now</h3>";
echo "<p><a href='http://localhost/matrimonial/login.php' style='background:#8B1A2B;color:white;padding:12px 30px;border-radius:99px;text-decoration:none;font-weight:bold;'>Go to Login Page</a></p>";
echo "<p><a href='http://localhost/matrimonial/admin/index.php' style='background:#2D7D46;color:white;padding:12px 30px;border-radius:99px;text-decoration:none;font-weight:bold;'>Go to Admin Panel</a></p>";
