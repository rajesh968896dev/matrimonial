<?php
// File: includes/functions.php

if (!defined('APP_RUNNING')) { die('Direct access not permitted'); }

/**
 * CSRF Protection
 */
function generateCsrfToken(): string {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(generateCsrfToken()) . '">';
}

function verifyCsrfToken(): bool {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (empty($token) || empty($_SESSION['csrf_token'])) return false;
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Input Sanitization
 */
function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function validateEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validateDate(string $date, string $format = 'Y-m-d'): bool {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * Password Security
 */
function hashPassword(string $password): string {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

function verifyPassword(string $password, string $hash): bool {
    return password_verify($password, $hash);
}

/**
 * Flash Messages
 */
function setFlash(string $type, string $message): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function getFlash(): array {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

/**
 * Authentication Check
 */
function requireLogin(): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['user_id'])) {
        setFlash('error', 'Please login to continue.');
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
        session_unset();
        session_destroy();
        setFlash('error', 'Session expired. Please login again.');
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

function requireAdmin(): void {
    requireLogin();
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (($_SESSION['user_role'] ?? '') !== 'admin') {
        setFlash('error', 'Access denied.');
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function isLoggedIn(): bool {
    if (session_status() === PHP_SESSION_NONE) session_start();
    return !empty($_SESSION['user_id']);
}

/**
 * Calculate Age
 */
function calculateAge(string $dob): int {
    $birth = new DateTime($dob);
    $now = new DateTime();
    return $now->diff($birth)->y;
}

/**
 * Format height
 */
function formatHeight(int $cm): string {
    $feet = floor($cm / 30.48);
    $inches = round(($cm / 2.54) - ($feet * 12));
    return $feet . "'" . $inches . '" (' . $cm . ' cm)';
}

/**
 * Get relative time
 */
function timeAgo(string $datetime): string {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    if ($diff->i > 0) return $diff->i . ' min' . ($diff->i > 1 ? 's' : '') . ' ago';
    return 'Just now';
}

/**
 * Rate Limiter
 */
function checkRateLimit(string $action, int $maxAttempts = 10, int $windowSeconds = 3600): bool {
    $db = Database::getInstance();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $since = date('Y-m-d H:i:s', time() - $windowSeconds);

    $stmt = $db->prepare("SELECT COUNT(*) FROM activity_log WHERE action = ? AND ip_address = ? AND created_at > ?");
    $stmt->execute([$action, $ip, $since]);
    return $stmt->fetchColumn() < $maxAttempts;
}

function logActivity(string $action, ?int $userId = null, ?string $details = null): void {
    try {
        $db = Database::getInstance();
        $stmt = $db->prepare("INSERT INTO activity_log (user_id, action, ip_address, user_agent, details) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $userId,
            $action,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
            $details
        ]);
    } catch (Exception $e) {
        error_log("Activity log failed: " . $e->getMessage());
    }
}

/**
 * File Upload Handler
 */
function uploadPhoto(array $file, string $subDir = 'photos'): ?string {
    if ($file['error'] !== UPLOAD_ERR_OK) return null;
    if ($file['size'] > MAX_FILE_SIZE) return null;

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_EXTENSIONS)) return null;

    // Verify MIME type
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $allowedMimes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowedMimes[$mime])) return null;

    $uploadDir = UPLOAD_PATH . '/' . $subDir;
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $filepath = $uploadDir . '/' . $filename;

    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }
    return null;
}

/**
 * Get user's profile photo URL
 */
function getProfilePhoto(?string $photo, string $gender = 'male'): string {
    if ($photo && file_exists(PROFILE_PHOTOS_PATH . '/' . $photo)) {
        return BASE_URL . '/uploads/photos/' . $photo;
    }
    return $gender === 'female'
        ? BASE_URL . '/assets/images/default-female.svg'
        : BASE_URL . '/assets/images/default-male.svg';
}

/**
 * Generate pagination HTML
 */
function pagination(int $currentPage, int $totalPages, string $baseUrl): string {
    if ($totalPages <= 1) return '';

    $html = '<nav class="pagination"><ul>';

    if ($currentPage > 1) {
        $html .= '<li><a href="' . $baseUrl . '&page=' . ($currentPage - 1) . '">&laquo; Prev</a></li>';
    }

    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);

    if ($start > 1) {
        $html .= '<li><a href="' . $baseUrl . '&page=1">1</a></li>';
        if ($start > 2) $html .= '<li class="dots">...</li>';
    }

    for ($i = $start; $i <= $end; $i++) {
        $active = $i === $currentPage ? ' class="active"' : '';
        $html .= '<li' . $active . '><a href="' . $baseUrl . '&page=' . $i . '">' . $i . '</a></li>';
    }

    if ($end < $totalPages) {
        if ($end < $totalPages - 1) $html .= '<li class="dots">...</li>';
        $html .= '<li><a href="' . $baseUrl . '&page=' . $totalPages . '">' . $totalPages . '</a></li>';
    }

    if ($currentPage < $totalPages) {
        $html .= '<li><a href="' . $baseUrl . '&page=' . ($currentPage + 1) . '">Next &raquo;</a></li>';
    }

    $html .= '</ul></nav>';
    return $html;
}
