<?php
// File: includes/auth.php

if (!defined('APP_RUNNING')) { die('Direct access not permitted'); }

class Auth {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function register(array $data): array {
        // Rate limit check
        if (!checkRateLimit('register', 3, 3600)) {
            return ['success' => false, 'message' => 'Too many registration attempts. Try again later.'];
        }

        // Validate
        $errors = [];
        if (!validateEmail($data['email'] ?? '')) $errors[] = 'Valid email is required.';
        if (strlen($data['password'] ?? '') < PASSWORD_MIN_LENGTH) $errors[] = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.';
        if (($data['password'] ?? '') !== ($data['confirm_password'] ?? '')) $errors[] = 'Passwords do not match.';
        if (empty($data['first_name'] ?? '')) $errors[] = 'First name is required.';
        if (empty($data['last_name'] ?? '')) $errors[] = 'Last name is required.';
        if (!in_array($data['gender'] ?? '', ['male', 'female'])) $errors[] = 'Gender is required.';
        if (!validateDate($data['dob'] ?? '')) $errors[] = 'Valid date of birth is required.';

        // Password strength
        $pwd = $data['password'] ?? '';
        if (!preg_match('/[A-Z]/', $pwd) || !preg_match('/[a-z]/', $pwd) || !preg_match('/[0-9]/', $pwd)) {
            $errors[] = 'Password must contain uppercase, lowercase, and a number.';
        }

        if (!empty($errors)) return ['success' => false, 'message' => implode(' ', $errors)];

        // Check duplicate
        $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$data['email']]);
        if ($stmt->fetch()) return ['success' => false, 'message' => 'Email already registered.'];

        $this->db->beginTransaction();
        try {
            // Create user
            $verificationToken = bin2hex(random_bytes(32));
            $stmt = $this->db->prepare(
                "INSERT INTO users (email, password_hash, verification_token, status) VALUES (?, ?, ?, 'active')"
            );
            $stmt->execute([$data['email'], hashPassword($data['password']), $verificationToken]);
            $userId = $this->db->lastInsertId();

            // Create profile
            $stmt = $this->db->prepare(
                "INSERT INTO profiles (user_id, profile_for, first_name, last_name, gender, date_of_birth) VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([
                $userId,
                sanitize($data['profile_for'] ?? 'self'),
                sanitize($data['first_name']),
                sanitize($data['last_name']),
                $data['gender'],
                $data['dob']
            ]);

            $this->db->commit();
            logActivity('register', $userId);

            return [
                'success' => true,
                'message' => 'Registration successful! Please login.',
                'user_id' => $userId
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Registration failed: " . $e->getMessage());
            return ['success' => false, 'message' => 'Registration failed. Please try again.'];
        }
    }

    public function login(string $email, string $password, bool $remember = false): array {
        if (!checkRateLimit('login_' . md5($email), MAX_LOGIN_ATTEMPTS, LOGIN_LOCKOUT_TIME)) {
            return ['success' => false, 'message' => 'Account temporarily locked. Try again in 15 minutes.'];
        }

        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !verifyPassword($password, $user['password_hash'])) {
            logActivity('login_failed', $user['id'] ?? null, "Email: $email");
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }

        // Successful login
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['last_activity'] = time();
        $_SESSION['login_time'] = time();

        // Remember me
        if ($remember) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 604800); // 7 days
            $stmt = $this->db->prepare("UPDATE users SET remember_token = ?, token_expires = ? WHERE id = ?");
            $stmt->execute([$token, $expires, $user['id']]);
            setcookie('remember_token', $token, time() + 604800, '/', '', false, true);
        }

        // Update last login
        $stmt = $this->db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);

        // Update profile last active
        $stmt = $this->db->prepare("UPDATE profiles SET last_active = NOW() WHERE user_id = ?");
        $stmt->execute([$user['id']]);

        logActivity('login_success', $user['id']);

        return ['success' => true, 'message' => 'Login successful!', 'user' => $user];
    }

    public function logout(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        logActivity('logout', $_SESSION['user_id'] ?? null);

        // Clear remember token
        if (!empty($_SESSION['user_id'])) {
            $stmt = $this->db->prepare("UPDATE users SET remember_token = NULL WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        }

        setcookie('remember_token', '', time() - 3600, '/', '', false, true);
        $_SESSION = [];
        session_destroy();
    }

    public function tryRememberMe(): ?array {
        if (isLoggedIn() || empty($_COOKIE['remember_token'])) return null;

        $token = $_COOKIE['remember_token'];
        $stmt = $this->db->prepare(
            "SELECT * FROM users WHERE remember_token = ? AND token_expires > NOW() AND status = 'active' LIMIT 1"
        );
        $stmt->execute([$token]);
        $user = $stmt->fetch();

        if ($user) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            return $user;
        }

        setcookie('remember_token', '', time() - 3600, '/', '', false, true);
        return null;
    }
}
