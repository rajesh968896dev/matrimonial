<?php
// File: includes/footer.php
if (!defined('APP_RUNNING')) { die('Direct access not permitted'); }
?>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <h4>VivahaBandhan</h4>
                    <p class="footer-text">Where Hearts Unite Forever. Trusted by millions of families worldwide for meaningful matrimonial connections.</p>
                </div>
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <a href="<?php echo BASE_URL; ?>/search.php">Search Profiles</a>
                    <a href="<?php echo BASE_URL; ?>/register.php">Register Free</a>
                    <a href="<?php echo BASE_URL; ?>/index.php#how-it-works">How It Works</a>
                </div>
                <div class="footer-col">
                    <h4>Communities</h4>
                    <a href="#">Hindu</a>
                    <a href="#">Muslim</a>
                    <a href="#">Christian</a>
                    <a href="#">Sikh</a>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <a href="#">Contact Us</a>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">Safety Tips</a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> VivahaBandhan. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="<?php echo BASE_URL; ?>/assets/js/app.js"></script>
</body>
</html>
