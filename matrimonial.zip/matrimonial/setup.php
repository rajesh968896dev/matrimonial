<?php
// File: setup.php
// Run this ONCE in your browser: http://localhost/matrimonial/setup.php
// Then DELETE this file for security!

define('APP_RUNNING', true);

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Setup</title>
<style>body{font-family:'DM Sans',sans-serif;max-width:700px;margin:40px auto;padding:20px;background:#FDF8F4;color:#1A0A0E;line-height:1.7;}
h1{color:#8B1A2B;} .ok{color:#2D7D46;font-weight:600;} .err{color:#C62828;font-weight:600;}
.box{background:white;border:1px solid #E8DDD5;border-radius:12px;padding:20px;margin:16px 0;}
pre{background:#1A0A0E;color:#FDF8F4;padding:16px;border-radius:8px;overflow-x:auto;font-size:13px;}
code{background:#E8DDD5;padding:2px 6px;border-radius:4px;font-size:13px;}
a{color:#8B1A2B;} .btn{display:inline-block;background:#8B1A2B;color:white;padding:12px 32px;border-radius:99px;text-decoration:none;font-weight:600;margin-top:12px;}</style></head><body>";

echo "<h1>&#9825; VivahaBandhan - Setup Wizard</h1>";

// Step 1: Check PHP version
echo "<div class='box'><h3>1. PHP Version</h3>";
if (version_compare(PHP_VERSION, '8.0.0', '>=')) {
    echo "<span class='ok'>PASS</span> - PHP " . PHP_VERSION;
} else {
    echo "<span class='err'>FAIL</span> - PHP 8.0+ required. Current: " . PHP_VERSION;
}
echo "</div>";

// Step 2: Check extensions
echo "<div class='box'><h3>2. Required Extensions</h3>";
$required = ['pdo', 'pdo_mysql', 'mbstring', 'json', 'fileinfo', 'session'];
foreach ($required as $ext) {
    if (extension_loaded($ext)) {
        echo "<span class='ok'>PASS</span> - $ext<br>";
    } else {
        echo "<span class='err'>FAIL</span> - $ext (enable in php.ini)<br>";
    }
}
echo "</div>";

// Step 3: Check directories
echo "<div class='box'><h3>3. Directory Permissions</h3>";
$dirs = [
    __DIR__ . '/uploads',
    __DIR__ . '/uploads/photos',
    __DIR__ . '/uploads/photos',
];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        if (mkdir($dir, 0755, true)) {
            echo "<span class='ok'>CREATED</span> - $dir<br>";
        } else {
            echo "<span class='err'>FAIL</span> - Cannot create $dir<br>";
        }
    } else {
        echo "<span class='ok'>EXISTS</span> - $dir<br>";
    }
}
echo "</div>";

// Step 4: Database setup
echo "<div class='box'><h3>4. Database Setup</h3>";
try {
    $pdo = new PDO('mysql:host=localhost', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    echo "<span class='ok'>PASS</span> - MySQL connection<br>";

    // Run SQL
    $sql = file_get_contents(__DIR__ . '/sql/database.sql');
    if ($sql) {
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        $count = 0;
        foreach ($statements as $statement) {
            if (!empty($statement)) {
                try {
                    $pdo->exec($statement);
                    $count++;
                } catch (PDOException $e) {
                    // Skip duplicate key errors
                    if (strpos($e->getMessage(), 'already exists') === false) {
                        echo "<span class='err'>SQL Error:</span> " . htmlspecialchars($e->getMessage()) . "<br>";
                    }
                }
            }
        }
        echo "<span class='ok'>PASS</span> - Database created and $count SQL statements executed<br>";
    } else {
        echo "<span class='err'>FAIL</span> - Cannot read sql/database.sql<br>";
    }
} catch (PDOException $e) {
    echo "<span class='err'>FAIL</span> - MySQL: " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "<p>Make sure XAMPP MySQL is running and root user has no password (default).</p>";
}
echo "</div>";

// Step 5: Create .htaccess
$htaccess = "RewriteEngine On\nRewriteBase /matrimonial/\n\n# Prevent directory listing\nOptions -Indexes\n\n# Block access to config files\n<FilesMatch \"\\.(sql|php)$\">\n<If \"%{REQUEST_URI} =~ m#/config/# || %{REQUEST_URI} =~ m#/includes/#\">\n    Require all denied\n</If>\n</FilesMatch>\n\n# Security headers\n<IfModule mod_headers.c>\n    Header set X-Content-Type-Options \"nosniff\"\n    Header set X-Frame-Options \"SAMEORIGIN\"\n    Header set X-XSS-Protection \"1; mode=block\"\n    Header set Referrer-Policy \"strict-origin-when-cross-origin\"\n</IfModule>\n\n# Prevent access to setup.php\n<Files setup.php>\n    Require all denied\n</Files>\n";

if (file_put_contents(__DIR__ . '/.htaccess', $htaccess)) {
    echo "<div class='box'><h3>5. .htaccess</h3><span class='ok'>CREATED</span></div>";
} else {
    echo "<div class='box'><h3>5. .htaccess</h3><span class='err'>Cannot write .htaccess - create it manually</span></div>";
}

// Done
echo "<div class='box'>";
echo "<h3>&#10003; Setup Complete!</h3>";
echo "<p><strong>Default Admin Login:</strong></p>";
echo "<pre>Email: admin@vivahabandhan.com\nPassword: Admin@123456</pre>";
echo "<p><strong>Important:</strong> Delete this <code>setup.php</code> file now!</p>";
echo "<a href='" . (defined('BASE_URL') ? BASE_URL : '/matrimonial') . "' class='btn'>Go to VivahaBandhan &rarr;</a>";
echo "</div>";

echo "</body></html>";
exit;
