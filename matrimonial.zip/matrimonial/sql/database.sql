-- File: sql/database.sql
-- Save this and import via phpMyAdmin or run setup.php

CREATE DATABASE IF NOT EXISTS matrimonial_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE matrimonial_db;

-- Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user','admin') DEFAULT 'user',
    status ENUM('active','inactive','suspended','pending') DEFAULT 'pending',
    email_verified TINYINT(1) DEFAULT 0,
    verification_token VARCHAR(64) DEFAULT NULL,
    remember_token VARCHAR(64) DEFAULT NULL,
    token_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_role (role)
) ENGINE=InnoDB;

-- User Profiles Table
CREATE TABLE profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    profile_for ENUM('self','son','daughter','brother','sister','friend','relative') DEFAULT 'self',
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    gender ENUM('male','female') NOT NULL,
    date_of_birth DATE NOT NULL,
    height_cm INT DEFAULT NULL,
    weight_kg INT DEFAULT NULL,
    body_type ENUM('slim','average','athletic','heavy') DEFAULT NULL,
    complexion ENUM('very_fair','fair','wheatish','dark') DEFAULT NULL,
    blood_group ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') DEFAULT NULL,
    physical_status ENUM('normal','physically_challenged') DEFAULT 'normal',
    religion VARCHAR(100) DEFAULT NULL,
    caste VARCHAR(100) DEFAULT NULL,
    sub_caste VARCHAR(100) DEFAULT NULL,
    gothra VARCHAR(100) DEFAULT NULL,
    star VARCHAR(100) DEFAULT NULL,
    rashi VARCHAR(100) DEFAULT NULL,
    mother_tongue VARCHAR(100) DEFAULT NULL,
    country VARCHAR(100) DEFAULT 'India',
    state VARCHAR(100) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    citizenship VARCHAR(100) DEFAULT NULL,
    education VARCHAR(200) DEFAULT NULL,
    education_detail VARCHAR(300) DEFAULT NULL,
    occupation VARCHAR(200) DEFAULT NULL,
    occupation_detail VARCHAR(300) DEFAULT NULL,
    annual_income_range VARCHAR(100) DEFAULT NULL,
    work_location VARCHAR(200) DEFAULT NULL,
    marital_status ENUM('never_married','divorced','widowed','awaiting_divorce','annulled') DEFAULT 'never_married',
    children TINYINT DEFAULT 0,
    family_type ENUM('joint','nuclear') DEFAULT NULL,
    family_status ENUM('middle_class','upper_middle_class','rich','affluent') DEFAULT NULL,
    father_occupation VARCHAR(200) DEFAULT NULL,
    mother_occupation VARCHAR(200) DEFAULT NULL,
    brothers TINYINT DEFAULT 0,
    brothers_married TINYINT DEFAULT 0,
    sisters TINYINT DEFAULT 0,
    sisters_married TINYINT DEFAULT 0,
    about_me TEXT DEFAULT NULL,
    about_family TEXT DEFAULT NULL,
    hobbies TEXT DEFAULT NULL,
    partner_age_min INT DEFAULT NULL,
    partner_age_max INT DEFAULT NULL,
    partner_height_min INT DEFAULT NULL,
    partner_height_max INT DEFAULT NULL,
    partner_religion VARCHAR(100) DEFAULT NULL,
    partner_caste VARCHAR(100) DEFAULT NULL,
    partner_education VARCHAR(200) DEFAULT NULL,
    partner_occupation VARCHAR(200) DEFAULT NULL,
    partner_location VARCHAR(200) DEFAULT NULL,
    partner_marital_status VARCHAR(200) DEFAULT NULL,
    partner_annual_income VARCHAR(100) DEFAULT NULL,
    partner_description TEXT DEFAULT NULL,
    photo_primary VARCHAR(255) DEFAULT NULL,
    photo_gallery TEXT DEFAULT NULL,
    profile_verified TINYINT(1) DEFAULT 0,
    profile_boosted_until DATETIME DEFAULT NULL,
    profile_views INT DEFAULT 0,
    last_active DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_gender (gender),
    INDEX idx_religion (religion),
    INDEX idx_country (country),
    INDEX idx_state (state),
    INDEX idx_city (city),
    INDEX idx_education (education),
    INDEX idx_marital_status (marital_status),
    INDEX idx_dob (date_of_birth),
    INDEX idx_last_active (last_active)
) ENGINE=InnoDB;

-- Interests / Connection Requests
CREATE TABLE interests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    status ENUM('pending','accepted','declined','cancelled') DEFAULT 'pending',
    message TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_interest (sender_id, receiver_id),
    INDEX idx_receiver_status (receiver_id, status),
    INDEX idx_sender_status (sender_id, status)
) ENGINE=InnoDB;

-- Shortlists / Favorites
CREATE TABLE shortlists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    shortlisted_user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (shortlisted_user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_shortlist (user_id, shortlisted_user_id)
) ENGINE=InnoDB;

-- Messages
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_conversation (sender_id, receiver_id),
    INDEX idx_receiver_read (receiver_id, is_read)
) ENGINE=InnoDB;

-- Profile Views Log
CREATE TABLE profile_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    viewer_id INT NOT NULL,
    viewed_id INT NOT NULL,
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (viewer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (viewed_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_viewed (viewed_id, viewed_at)
) ENGINE=InnoDB;

-- Activity Log (Security)
CREATE TABLE activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL,
    details TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_action (user_id, action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Admin Settings
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO settings (setting_key, setting_value) VALUES
('site_name', 'VivahaBandhan'),
('site_tagline', 'Where Hearts Unite Forever'),
('maintenance_mode', '0'),
('max_photos', '6'),
('max_interests_per_day', '50'),
('require_email_verification', '1');

-- Insert default admin
INSERT INTO users (email, password_hash, role, status, email_verified)
VALUES ('admin@vivahabandhan.com', '$2y$12$LJ3m4yPnVSRHLgYVbWiJOesKxQy1LCzKHxN3M0a4.HPpJkHBiEfGy', 'admin', 'active', 1);
-- Default password: Admin@123456
