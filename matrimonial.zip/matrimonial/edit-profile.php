<?php
// File: edit-profile.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = $_SESSION['user_id'];

$success = '';
$error = '';

// Load current profile
$stmt = $db->prepare("SELECT * FROM profiles WHERE user_id = ?");
$stmt->execute([$userId]);
$profile = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken()) { $error = 'Invalid request.'; }
    else {
        try {
            // Handle photo upload
            $photoName = $profile['photo_primary'];
            if (!empty($_FILES['photo_primary']['name'])) {
                $uploaded = uploadPhoto($_FILES['photo_primary']);
                if ($uploaded) {
                    // Delete old photo
                    if ($photoName && file_exists(PROFILE_PHOTOS_PATH . '/' . $photoName)) {
                        unlink(PROFILE_PHOTOS_PATH . '/' . $photoName);
                    }
                    $photoName = $uploaded;
                } else {
                    $error = 'Photo upload failed. Max 5MB, JPG/PNG/WebP only.';
                }
            }

            if (empty($error)) {
                $stmt = $db->prepare("
                    UPDATE profiles SET
                        profile_for = ?, first_name = ?, last_name = ?, gender = ?, date_of_birth = ?,
                        height_cm = ?, weight_kg = ?, body_type = ?, blood_group = ?, religion = ?,
                        caste = ?, mother_tongue = ?, country = ?, state = ?, city = ?,
                        education = ?, education_detail = ?, occupation = ?, occupation_detail = ?,
                        annual_income_range = ?, work_location = ?, marital_status = ?,
                        family_type = ?, family_status = ?, father_occupation = ?, mother_occupation = ?,
                        brothers = ?, sisters = ?, about_me = ?, about_family = ?, hobbies = ?,
                        partner_age_min = ?, partner_age_max = ?, partner_height_min = ?, partner_height_max = ?,
                        partner_religion = ?, partner_education = ?, partner_description = ?,
                        photo_primary = ?
                    WHERE user_id = ?
                ");

                $stmt->execute([
                    sanitize($_POST['profile_for'] ?? 'self'),
                    sanitize($_POST['first_name'] ?? ''),
                    sanitize($_POST['last_name'] ?? ''),
                    $profile['gender'], // gender shouldn't change
                    $_POST['date_of_birth'] ?? $profile['date_of_birth'],
                    intval($_POST['height_cm'] ?? 0) ?: null,
                    intval($_POST['weight_kg'] ?? 0) ?: null,
                    $_POST['body_type'] ?? null,
                    $_POST['blood_group'] ?? null,
                    sanitize($_POST['religion'] ?? ''),
                    sanitize($_POST['caste'] ?? ''),
                    sanitize($_POST['mother_tongue'] ?? ''),
                    sanitize($_POST['country'] ?? 'India'),
                    sanitize($_POST['state'] ?? ''),
                    sanitize($_POST['city'] ?? ''),
                    sanitize($_POST['education'] ?? ''),
                    sanitize($_POST['education_detail'] ?? ''),
                    sanitize($_POST['occupation'] ?? ''),
                    sanitize($_POST['occupation_detail'] ?? ''),
                    sanitize($_POST['annual_income_range'] ?? ''),
                    sanitize($_POST['work_location'] ?? ''),
                    $_POST['marital_status'] ?? 'never_married',
                    $_POST['family_type'] ?? null,
                    $_POST['family_status'] ?? null,
                    sanitize($_POST['father_occupation'] ?? ''),
                    sanitize($_POST['mother_occupation'] ?? ''),
                    intval($_POST['brothers'] ?? 0),
                    intval($_POST['sisters'] ?? 0),
                    sanitize($_POST['about_me'] ?? ''),
                    sanitize($_POST['about_family'] ?? ''),
                    sanitize($_POST['hobbies'] ?? ''),
                    intval($_POST['partner_age_min'] ?? 0) ?: null,
                    intval($_POST['partner_age_max'] ?? 0) ?: null,
                    intval($_POST['partner_height_min'] ?? 0) ?: null,
                    intval($_POST['partner_height_max'] ?? 0) ?: null,
                    sanitize($_POST['partner_religion'] ?? ''),
                    sanitize($_POST['partner_education'] ?? ''),
                    sanitize($_POST['partner_description'] ?? ''),
                    $photoName,
                    $userId
                ]);

                // Reload profile
                $stmt = $db->prepare("SELECT * FROM profiles WHERE user_id = ?");
                $stmt->execute([$userId]);
                $profile = $stmt->fetch();

                $success = 'Profile updated successfully!';
                setFlash('success', $success);
                header('Location: ' . BASE_URL . '/profile.php');
                exit;
            }
        } catch (Exception $e) {
            error_log("Profile update error: " . $e->getMessage());
            $error = 'Failed to update profile. Please try again.';
        }
    }
}

$pageTitle = 'Edit Profile';
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;max-width:900px;">
    <h1 style="margin-bottom:8px;">Edit Your Profile</h1>
    <p style="color:var(--text-muted);margin-bottom:32px;">Update your details to attract better matches</p>

    <?php if ($error): ?>
        <div class="flash flash-error" style="position:static;margin-bottom:20px;"><span><?php echo sanitize($error); ?></span></div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data" novalidate>
        <?php echo csrfField(); ?>

        <!-- Photo Upload -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Profile Photo</h3>
                <div style="display:flex;align-items:center;gap:24px;">
                    <img id="photoPreview" src="<?php echo getProfilePhoto($profile['photo_primary'] ?? null, $profile['gender'] ?? 'male'); ?>" alt="Photo" style="width:120px;height:120px;border-radius:50%;object-fit:cover;border:3px solid var(--border);">
                    <div>
                        <input type="file" name="photo_primary" id="photoPrimary" accept="image/jpeg,image/png,image/webp" data-preview="photoPreview" class="form-control" style="padding:8px;">
                        <div class="form-hint">Max 5MB. JPG, PNG, or WebP format.</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Basic Details -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Basic Details</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Profile For</label>
                        <select name="profile_for" class="form-control">
                            <?php foreach (['self','son','daughter','brother','sister','friend','relative'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($profile['profile_for'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo ucfirst($opt); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Date of Birth</label>
                        <input type="date" name="date_of_birth" class="form-control" value="<?php echo sanitize($profile['date_of_birth'] ?? ''); ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">First Name</label>
                        <input type="text" name="first_name" class="form-control" value="<?php echo sanitize($profile['first_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="last_name" class="form-control" value="<?php echo sanitize($profile['last_name'] ?? ''); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Height (cm)</label>
                        <input type="number" name="height_cm" class="form-control" value="<?php echo $profile['height_cm'] ?? ''; ?>" min="100" max="250">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Weight (kg)</label>
                        <input type="number" name="weight_kg" class="form-control" value="<?php echo $profile['weight_kg'] ?? ''; ?>" min="30" max="200">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Body Type</label>
                        <select name="body_type" class="form-control">
                            <option value="">Select</option>
                            <?php foreach (['slim','average','athletic','heavy'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($profile['body_type'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo ucfirst($opt); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Blood Group</label>
                        <select name="blood_group" class="form-control">
                            <option value="">Select</option>
                            <?php foreach (['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($profile['blood_group'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Marital Status</label>
                        <select name="marital_status" class="form-control">
                            <?php foreach (['never_married','divorced','widowed','awaiting_divorce','annulled'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($profile['marital_status'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo ucwords(str_replace('_', ' ', $opt)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mother Tongue</label>
                        <input type="text" name="mother_tongue" class="form-control" value="<?php echo sanitize($profile['mother_tongue'] ?? ''); ?>" placeholder="e.g., Hindi, Tamil, Bengali">
                    </div>
                </div>
            </div>
        </div>

        <!-- Religious & Community -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Religion & Community</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Religion</label>
                        <input type="text" name="religion" class="form-control" value="<?php echo sanitize($profile['religion'] ?? ''); ?>" placeholder="e.g., Hindu, Muslim, Christian">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Caste</label>
                        <input type="text" name="caste" class="form-control" value="<?php echo sanitize($profile['caste'] ?? ''); ?>" placeholder="Optional">
                    </div>
                </div>
            </div>
        </div>

        <!-- Location -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Location</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Country</label>
                        <input type="text" name="country" class="form-control" value="<?php echo sanitize($profile['country'] ?? 'India'); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">State</label>
                        <input type="text" name="state" class="form-control" value="<?php echo sanitize($profile['state'] ?? ''); ?>" placeholder="e.g., Maharashtra, Karnataka">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">City</label>
                    <input type="text" name="city" class="form-control" value="<?php echo sanitize($profile['city'] ?? ''); ?>" placeholder="e.g., Mumbai, Bangalore">
                </div>
            </div>
        </div>

        <!-- Education & Career -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Education & Career</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Highest Education</label>
                        <input type="text" name="education" class="form-control" value="<?php echo sanitize($profile['education'] ?? ''); ?>" placeholder="e.g., B.Tech, MBA, MBBS">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Education Detail</label>
                        <input type="text" name="education_detail" class="form-control" value="<?php echo sanitize($profile['education_detail'] ?? ''); ?>" placeholder="College/University">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Occupation</label>
                        <input type="text" name="occupation" class="form-control" value="<?php echo sanitize($profile['occupation'] ?? ''); ?>" placeholder="e.g., Software Engineer">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Company / Organization</label>
                        <input type="text" name="occupation_detail" class="form-control" value="<?php echo sanitize($profile['occupation_detail'] ?? ''); ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Annual Income</label>
                        <select name="annual_income_range" class="form-control">
                            <option value="">Prefer not to say</option>
                            <?php foreach (['Under 2 Lakh','2-5 Lakh','5-10 Lakh','10-20 Lakh','20-35 Lakh','35-50 Lakh','50-75 Lakh','75 Lakh - 1 Crore','Above 1 Crore'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($profile['annual_income_range'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Work Location</label>
                        <input type="text" name="work_location" class="form-control" value="<?php echo sanitize($profile['work_location'] ?? ''); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Family -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Family Details</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Family Type</label>
                        <select name="family_type" class="form-control">
                            <option value="">Select</option>
                            <option value="joint" <?php echo ($profile['family_type'] ?? '') === 'joint' ? 'selected' : ''; ?>>Joint Family</option>
                            <option value="nuclear" <?php echo ($profile['family_type'] ?? '') === 'nuclear' ? 'selected' : ''; ?>>Nuclear Family</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Family Status</label>
                        <select name="family_status" class="form-control">
                            <option value="">Select</option>
                            <?php foreach (['middle_class','upper_middle_class','rich','affluent'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($profile['family_status'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo ucwords(str_replace('_', ' ', $opt)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Father's Occupation</label>
                        <input type="text" name="father_occupation" class="form-control" value="<?php echo sanitize($profile['father_occupation'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mother's Occupation</label>
                        <input type="text" name="mother_occupation" class="form-control" value="<?php echo sanitize($profile['mother_occupation'] ?? ''); ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Brothers</label>
                        <input type="number" name="brothers" class="form-control" value="<?php echo $profile['brothers'] ?? 0; ?>" min="0" max="10">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sisters</label>
                        <input type="number" name="sisters" class="form-control" value="<?php echo $profile['sisters'] ?? 0; ?>" min="0" max="10">
                    </div>
                </div>
            </div>
        </div>

        <!-- About -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">About You</h3>
                <div class="form-group">
                    <label class="form-label">About Me</label>
                    <textarea name="about_me" class="form-control" rows="4" placeholder="Tell potential matches about yourself, your personality, interests..."><?php echo sanitize($profile['about_me'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">About Family</label>
                    <textarea name="about_family" class="form-control" rows="3" placeholder="Brief about your family background..."><?php echo sanitize($profile['about_family'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Hobbies & Interests</label>
                    <input type="text" name="hobbies" class="form-control" value="<?php echo sanitize($profile['hobbies'] ?? ''); ?>" placeholder="e.g., Reading, Travelling, Music, Cooking">
                </div>
            </div>
        </div>

        <!-- Partner Preferences -->
        <div class="card" style="margin-bottom:24px;">
            <div class="card-body">
                <h3 class="profile-section-title">Partner Preferences</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Age Range (Min)</label>
                        <input type="number" name="partner_age_min" class="form-control" value="<?php echo $profile['partner_age_min'] ?? ''; ?>" min="18" max="70">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Age Range (Max)</label>
                        <input type="number" name="partner_age_max" class="form-control" value="<?php echo $profile['partner_age_max'] ?? ''; ?>" min="18" max="70">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Height Min (cm)</label>
                        <input type="number" name="partner_height_min" class="form-control" value="<?php echo $profile['partner_height_min'] ?? ''; ?>" min="100" max="250">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Height Max (cm)</label>
                        <input type="number" name="partner_height_max" class="form-control" value="<?php echo $profile['partner_height_max'] ?? ''; ?>" min="100" max="250">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Preferred Religion</label>
                        <input type="text" name="partner_religion" class="form-control" value="<?php echo sanitize($profile['partner_religion'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Preferred Education</label>
                        <input type="text" name="partner_education" class="form-control" value="<?php echo sanitize($profile['partner_education'] ?? ''); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Describe Your Ideal Partner</label>
                    <textarea name="partner_description" class="form-control" rows="3" placeholder="What qualities are you looking for?"><?php echo sanitize($profile['partner_description'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>

        <div style="display:flex;gap:16px;justify-content:flex-end;padding-bottom:40px;">
            <a href="<?php echo BASE_URL; ?>/profile.php" class="btn btn-ghost">Cancel</a>
            <button type="submit" class="btn btn-primary btn-lg">Save Profile</button>
        </div>
    </form>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
