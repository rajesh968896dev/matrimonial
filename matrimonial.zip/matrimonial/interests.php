<?php
// File: interests.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = $_SESSION['user_id'];

// Get received interests
$stmt = $db->prepare("
    SELECT i.*, p.first_name, p.last_name, p.gender, p.date_of_birth, p.city, p.state, p.education, p.occupation, p.photo_primary, p.religion
    FROM interests i JOIN profiles p ON p.user_id = i.sender_id
    WHERE i.receiver_id = ? ORDER BY i.created_at DESC
");
$stmt->execute([$userId]);
$receivedInterests = $stmt->fetchAll();

// Get sent interests
$stmt = $db->prepare("
    SELECT i.*, p.first_name, p.last_name, p.gender, p.date_of_birth, p.city, p.state, p.education, p.occupation, p.photo_primary, p.religion
    FROM interests i JOIN profiles p ON p.user_id = i.receiver_id
    WHERE i.sender_id = ? ORDER BY i.created_at DESC
");
$stmt->execute([$userId]);
$sentInterests = $stmt->fetchAll();

// Get accepted (mutual matches)
$stmt = $db->prepare("
    SELECT i.*, p.first_name, p.last_name, p.gender, p.date_of_birth, p.city, p.state, p.education, p.occupation, p.photo_primary, p.religion
    FROM interests i JOIN profiles p ON (p.user_id = i.receiver_id OR p.user_id = i.sender_id) AND p.user_id != ?
    WHERE (i.sender_id = ? OR i.receiver_id = ?) AND i.status = 'accepted' ORDER BY i.updated_at DESC
");
$stmt->execute([$userId, $userId, $userId]);
$mutualMatches = $stmt->fetchAll();

$pageTitle = 'Interests & Matches';
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;max-width:900px;">
    <h1 style="margin-bottom:24px;">Interests & Matches</h1>

    <div class="interests-tabs">
        <button class="interests-tab active" data-tab="received">Received (<?php echo count($receivedInterests); ?>)</button>
        <button class="interests-tab" data-tab="sent">Sent (<?php echo count($sentInterests); ?>)</button>
        <button class="interests-tab" data-tab="mutual">Mutual (<?php echo count($mutualMatches); ?>)</button>
    </div>

    <!-- Received Interests -->
    <div id="received" class="tab-panel">
        <?php if (empty($receivedInterests)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128231;</div>
                <h3>No interests received yet</h3>
                <p>Complete your profile to attract more interests.</p>
            </div>
        <?php else: ?>
            <?php foreach ($receivedInterests as $interest): ?>
            <div class="interest-card">
                <img src="<?php echo getProfilePhoto($interest['photo_primary'], $interest['gender']); ?>" alt="" class="interest-photo">
                <div class="interest-info">
                    <strong style="font-size:1.05rem;"><?php echo sanitize($interest['first_name'] . ' ' . $interest['last_name']); ?></strong>
                    <div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
                        <?php echo calculateAge($interest['date_of_birth']); ?> yrs, <?php echo sanitize($interest['city'] ?? ''); ?>, <?php echo sanitize($interest['education'] ?? ''); ?>
                    </div>
                    <?php if ($interest['message']): ?>
                        <div style="font-size:0.85rem;color:var(--text-secondary);margin-top:4px;font-style:italic;">"<?php echo sanitize($interest['message']); ?>"</div>
                    <?php endif; ?>
                    <div style="font-size:0.75rem;color:var(--text-light);margin-top:4px;"><?php echo timeAgo($interest['created_at']); ?></div>
                </div>
                <div class="interest-actions">
                    <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $interest['sender_id']; ?>" class="btn btn-ghost btn-sm">View</a>
                    <?php if ($interest['status'] === 'pending'): ?>
                        <button class="btn btn-primary btn-sm" data-action="accept-interest" data-user-id="<?php echo $interest['sender_id']; ?>">Accept</button>
                        <button class="btn btn-ghost btn-sm" data-action="decline-interest" data-user-id="<?php echo $interest['sender_id']; ?>">Decline</button>
                    <?php elseif ($interest['status'] === 'accepted'): ?>
                        <a href="<?php echo BASE_URL; ?>/messages.php?user=<?php echo $interest['sender_id']; ?>" class="btn btn-primary btn-sm">Message</a>
                        <span class="status-badge status-active">Accepted</span>
                    <?php else: ?>
                        <span class="status-badge status-inactive">Declined</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Sent Interests -->
    <div id="sent" class="tab-panel" style="display:none;">
        <?php if (empty($sentInterests)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128228;</div>
                <h3>No interests sent yet</h3>
                <p>Browse matches and send interests to profiles you like.</p>
                <a href="<?php echo BASE_URL; ?>/matches.php" class="btn btn-primary">View Matches</a>
            </div>
        <?php else: ?>
            <?php foreach ($sentInterests as $interest): ?>
            <div class="interest-card">
                <img src="<?php echo getProfilePhoto($interest['photo_primary'], $interest['gender']); ?>" alt="" class="interest-photo">
                <div class="interest-info">
                    <strong style="font-size:1.05rem;"><?php echo sanitize($interest['first_name'] . ' ' . $interest['last_name']); ?></strong>
                    <div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
                        <?php echo calculateAge($interest['date_of_birth']); ?> yrs, <?php echo sanitize($interest['city'] ?? ''); ?>, <?php echo sanitize($interest['education'] ?? ''); ?>
                    </div>
                    <div style="font-size:0.75rem;color:var(--text-light);margin-top:4px;"><?php echo timeAgo($interest['created_at']); ?></div>
                </div>
                <div class="interest-actions">
                    <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $interest['receiver_id']; ?>" class="btn btn-ghost btn-sm">View</a>
                    <?php if ($interest['status'] === 'pending'): ?>
                        <span class="status-badge status-pending">Pending</span>
                    <?php elseif ($interest['status'] === 'accepted'): ?>
                        <span class="status-badge status-active">Accepted</span>
                    <?php else: ?>
                        <span class="status-badge status-inactive">Declined</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Mutual Matches -->
    <div id="mutual" class="tab-panel" style="display:none;">
        <?php if (empty($mutualMatches)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128144;</div>
                <h3>No mutual matches yet</h3>
                <p>When both of you accept each other's interest, you'll appear here.</p>
            </div>
        <?php else: ?>
            <?php foreach ($mutualMatches as $match): ?>
            <div class="interest-card" style="border-color:var(--gold);">
                <img src="<?php echo getProfilePhoto($match['photo_primary'], $match['gender']); ?>" alt="" class="interest-photo">
                <div class="interest-info">
                    <strong style="font-size:1.05rem;"><?php echo sanitize($match['first_name'] . ' ' . $match['last_name']); ?></strong>
                    <span style="background:linear-gradient(135deg,var(--gold),var(--gold-light));color:var(--bg-dark);padding:2px 8px;border-radius:var(--radius-full);font-size:0.7rem;font-weight:700;margin-left:8px;">MUTUAL MATCH</span>
                    <div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
                        <?php echo calculateAge($match['date_of_birth']); ?> yrs, <?php echo sanitize($match['city'] ?? ''); ?>, <?php echo sanitize($match['education'] ?? ''); ?>
                    </div>
                </div>
                <div class="interest-actions">
                    <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $match['user_id']; ?>" class="btn btn-ghost btn-sm">View</a>
                    <a href="<?php echo BASE_URL; ?>/messages.php?user=<?php echo $match['user_id']; ?>" class="btn btn-primary btn-sm">Message</a>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
