<?php
// File: shortlists.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();

$stmt = $db->prepare("
    SELECT p.*, u.email FROM shortlists s
    JOIN profiles p ON p.user_id = s.shortlisted_user_id
    JOIN users u ON u.id = p.user_id
    WHERE s.user_id = ? ORDER BY s.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$shortlisted = $stmt->fetchAll();

$pageTitle = 'Shortlisted Profiles';
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;">
    <h1 style="margin-bottom:24px;">Shortlisted Profiles</h1>

    <?php if (empty($shortlisted)): ?>
        <div class="empty-state">
            <div class="empty-icon">&#9825;</div>
            <h3>No shortlisted profiles</h3>
            <p>Shortlist profiles you're interested in to review later.</p>
            <a href="<?php echo BASE_URL; ?>/search.php" class="btn btn-primary">Browse Profiles</a>
        </div>
    <?php else: ?>
        <div class="profiles-grid">
            <?php foreach ($shortlisted as $profile): ?>
            <div class="card profile-card">
                <div class="profile-photo-wrapper">
                    <img src="<?php echo getProfilePhoto($profile['photo_primary'], $profile['gender']); ?>" alt="<?php echo sanitize($profile['first_name']); ?>">
                </div>
                <div class="card-body">
                    <div class="profile-name"><?php echo sanitize($profile['first_name'] . ' ' . $profile['last_name']); ?></div>
                    <div class="profile-detail">
                        <?php echo calculateAge($profile['date_of_birth']); ?> yrs, <?php echo sanitize($profile['city'] ?? ''); ?>
                    </div>
                    <div class="profile-detail"><?php echo sanitize($profile['education'] ?? ''); ?></div>
                    <div class="profile-actions">
                        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profile['user_id']; ?>" class="btn btn-secondary btn-sm">View</a>
                        <button class="btn btn-primary btn-sm" data-action="interest" data-user-id="<?php echo $profile['user_id']; ?>">Send Interest</button>
                        <button class="btn btn-ghost btn-sm" data-action="unshortlist" data-user-id="<?php echo $profile['user_id']; ?>">&#10005;</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
