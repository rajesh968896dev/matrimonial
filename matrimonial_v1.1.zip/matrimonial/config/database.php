<?php
// File: config/database.php

if (!defined('APP_RUNNING')) { die('Direct access not permitted'); }

class Database {
    private static ?PDO $instance = null;

    private const HOST     = '127.0.0.1';
    private const PORT     = '3306';
    private const DB_NAME  = 'matrimonial_db';
    private const USERNAME = 'root';
    private const PASSWORD = 'admin';
    private const CHARSET  = 'utf8mb4';

    private function __construct() {}
    private function __clone() {}

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            try {
                $dsn = "mysql:host=" . self::HOST . ";port=" . self::PORT . ";dbname=" . self::DB_NAME . ";charset=" . self::CHARSET;

                self::$instance = new PDO($dsn, self::USERNAME, self::PASSWORD, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND  => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
                    PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true   // ← THIS LINE FIXES IT
                ]);

            } catch (PDOException $e) {
                echo '<div style="max-width:600px;margin:60px auto;padding:30px;background:#FFEBEE;border:2px solid #C62828;border-radius:12px;font-family:sans-serif;">';
                echo '<h2 style="color:#C62828;">&#9888; Database Connection Failed</h2>';
                echo '<p style="margin-top:10px;">' . htmlspecialchars($e->getMessage()) . '</p>';
                echo '<p style="margin-top:16px;"><a href="http://localhost/phpmyadmin" target="_blank" style="color:#8B1A2B;font-weight:600;">Open phpMyAdmin to check MySQL</a></p>';
                echo '</div>';
                exit;
            }
        }
        return self::$instance;
    }

    public static function testConnection(): array {
        try {
            $dsn = "mysql:host=" . self::HOST . ";port=" . self::PORT . ";charset=" . self::CHARSET;
            $pdo = new PDO($dsn, self::USERNAME, self::PASSWORD, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);
            return ['success' => true, 'message' => 'Connected to MySQL server.'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public static function createDatabase(): array {
        try {
            $dsn = "mysql:host=" . self::HOST . ";port=" . self::PORT . ";charset=" . self::CHARSET;
            $pdo = new PDO($dsn, self::USERNAME, self::PASSWORD, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . self::DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            return ['success' => true, 'message' => 'Database created.'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
