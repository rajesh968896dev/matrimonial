// File: assets/js/app.js
// COMPLETE FIXED VERSION

document.addEventListener('DOMContentLoaded', function() {

    // ====================================================
    // GLOBAL: CSRF Token Helper
    // ====================================================
    window.getCsrfToken = function() {
        // Try meta tag first
        var meta = document.querySelector('meta[name="csrf-token"]');
        if (meta && meta.content) return meta.content;

        // Try hidden input
        var input = document.querySelector('input[name="csrf_token"]');
        if (input && input.value) return input.value;

        // Try any form's csrf_token
        var anyInput = document.querySelector('form input[name="csrf_token"]');
        if (anyInput && anyInput.value) return anyInput.value;

        return '';
    };

    // Make BASE_URL available globally
    if (typeof window.BASE_URL === 'undefined') {
        var baseLink = document.querySelector('a[href*="/matrimonial"]');
        window.BASE_URL = '/matrimonial';
    }

    // ====================================================
    // NAVIGATION
    // ====================================================
    var navToggle = document.getElementById('navToggle');
    var navMenu = document.getElementById('navMenu');
    var mainNav = document.getElementById('mainNav');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('open');
            this.classList.toggle('active');
        });

        document.addEventListener('click', function(e) {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('open');
                navToggle.classList.remove('active');
            }
        });
    }

    if (mainNav) {
        window.addEventListener('scroll', function() {
            mainNav.classList.toggle('scrolled', window.scrollY > 10);
        });
    }

    // ====================================================
    // DROPDOWN MENUS
    // ====================================================
    document.querySelectorAll('.nav-dropdown').forEach(function(dropdown) {
        var trigger = dropdown.querySelector('.nav-dropdown-trigger');
        if (trigger) {
            trigger.addEventListener('click', function(e) {
                e.stopPropagation();
                document.querySelectorAll('.nav-dropdown.open').forEach(function(d) {
                    if (d !== dropdown) d.classList.remove('open');
                });
                dropdown.classList.toggle('open');
            });
        }
    });

    document.addEventListener('click', function() {
        document.querySelectorAll('.nav-dropdown.open').forEach(function(d) {
            d.classList.remove('open');
        });
    });

    // ====================================================
    // AUTO-DISMISS FLASH MESSAGES
    // ====================================================
    document.querySelectorAll('.flash').forEach(function(flash) {
        setTimeout(function() {
            flash.style.opacity = '0';
            flash.style.transform = 'translateX(100%)';
            setTimeout(function() { flash.remove(); }, 300);
        }, 5000);
    });

    // ====================================================
    // INTEREST TABS
    // ====================================================
    document.querySelectorAll('.interests-tab').forEach(function(tab) {
        tab.addEventListener('click', function() {
            var target = this.dataset.tab;

            document.querySelectorAll('.interests-tab').forEach(function(t) {
                t.classList.remove('active');
            });
            this.classList.add('active');

            document.querySelectorAll('.tab-panel').forEach(function(panel) {
                panel.style.display = panel.id === target ? 'block' : 'none';
            });
        });
    });

    // ====================================================
    // LIKE / INTEREST / SHORTLIST ACTIONS (AJAX)
    // ====================================================
    document.body.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-action]');
        if (!btn) return;

        var action = btn.dataset.action;
        var userId = btn.dataset.userId;

        if (!action || !userId) return;

        // Prevent double-clicks
        if (btn.disabled) return;
        btn.disabled = true;

        var originalText = btn.innerHTML;
        btn.innerHTML = '<span class="spinner" style="width:16px;height:16px;border-width:2px;display:inline-block;"></span>';

        var csrf = window.getCsrfToken();

        if (!csrf) {
            showToast('error', 'Security token missing. Please refresh the page.');
            btn.innerHTML = originalText;
            btn.disabled = false;
            return;
        }

        var formData = new FormData();
        formData.append('action', action);
        formData.append('user_id', userId);
        formData.append('csrf_token', csrf);

        var baseUrl = window.BASE_URL || '/matrimonial';

        fetch(baseUrl + '/api/interest-action.php', {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            if (!response.ok) throw new Error('Network error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            if (data.success) {
                showToast('success', data.message || 'Action completed!');

                if (data.remove_card) {
                    var card = btn.closest('.interest-card') || btn.closest('.profile-card');
                    if (card) {
                        card.style.transition = 'all 0.3s ease';
                        card.style.opacity = '0';
                        card.style.transform = 'scale(0.95)';
                        setTimeout(function() { card.remove(); }, 300);
                    }
                } else {
                    btn.innerHTML = data.button_text || '&#10003; Done';
                    btn.classList.remove('btn-primary');
                    btn.classList.add('btn-ghost');
                    btn.disabled = true;
                }
            } else {
                showToast('error', data.message || 'Action failed.');
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        })
        .catch(function(err) {
            console.error('Action error:', err);
            showToast('error', 'Network error. Please try again.');
            btn.innerHTML = originalText;
            btn.disabled = false;
        });
    });

    // ====================================================
    // IMAGE PREVIEW ON UPLOAD
    // ====================================================
    document.querySelectorAll('input[type="file"][data-preview]').forEach(function(input) {
        input.addEventListener('change', function() {
            var file = this.files[0];
            if (!file) return;

            if (file.size > 5 * 1024 * 1024) {
                showToast('error', 'File size must be under 5MB.');
                this.value = '';
                return;
            }

            var previewId = this.dataset.preview;
            var preview = document.getElementById(previewId);
            if (preview) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    });

    // ====================================================
    // FORM VALIDATION
    // ====================================================
    document.querySelectorAll('form[data-validate]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            var valid = true;

            this.querySelectorAll('[required]').forEach(function(field) {
                if (!field.value.trim()) {
                    field.style.borderColor = 'var(--error)';
                    valid = false;
                } else {
                    field.style.borderColor = '';
                }
            });

            var pwd = this.querySelector('[name="password"]');
            var confirm = this.querySelector('[name="confirm_password"]');
            if (pwd && confirm && pwd.value !== confirm.value) {
                confirm.style.borderColor = 'var(--error)';
                showToast('error', 'Passwords do not match.');
                valid = false;
            }

            if (!valid) {
                e.preventDefault();
                showToast('error', 'Please fill in all required fields.');
            }
        });
    });

    // ====================================================
    // CHAT SEND (only on messages page)
    // ====================================================
    var chatForm = document.getElementById('chatForm');
    if (chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var input = this.querySelector('input[name="message"]');
            var message = input ? input.value.trim() : '';
            if (!message) return;

            var csrf = window.getCsrfToken();
            var formData = new FormData(this);
            formData.append('csrf_token', csrf);

            var baseUrl = window.BASE_URL || '/matrimonial';

            fetch(baseUrl + '/api/send-message.php', {
                method: 'POST',
                body: formData
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.success) {
                    appendMessage(message, 'sent', data.time);
                    input.value = '';
                } else {
                    showToast('error', data.message || 'Failed to send.');
                }
            })
            .catch(function() {
                showToast('error', 'Network error.');
            });
        });
    }

    function appendMessage(text, type, time) {
        var chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        var bubble = document.createElement('div');
        bubble.className = 'message-bubble message-' + type;
        bubble.innerHTML = '<div>' + escapeHtml(text) + '</div><div class="message-time">' + (time || 'Just now') + '</div>';
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});

// ====================================================
// TOAST / NOTIFICATION
// ====================================================
function showToast(type, message) {
    var container = document.querySelector('.flash-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'flash-container';
        container.style.cssText = 'position:fixed;top:84px;right:24px;z-index:10000;max-width:420px;';
        document.body.appendChild(container);
    }

    var flash = document.createElement('div');
    flash.className = 'flash flash-' + type;
    flash.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 20px;border-radius:10px;font-size:0.9rem;font-weight:500;box-shadow:0 12px 40px rgba(0,0,0,0.12);animation:slideInRight 0.3s ease;margin-bottom:8px;';

    if (type === 'success') {
        flash.style.background = '#E8F5E9';
        flash.style.color = '#2D7D46';
        flash.style.borderLeft = '4px solid #2D7D46';
    } else if (type === 'error') {
        flash.style.background = '#FFEBEE';
        flash.style.color = '#C62828';
        flash.style.borderLeft = '4px solid #C62828';
    } else {
        flash.style.background = '#E3F2FD';
        flash.style.color = '#1565C0';
        flash.style.borderLeft = '4px solid #1565C0';
    }

    flash.innerHTML = '<span>' + escapeHtml(message) + '</span><button onclick="this.parentElement.remove()" style="background:none;border:none;font-size:1.2rem;cursor:pointer;opacity:0.5;color:inherit;line-height:1;">&times;</button>';
    container.appendChild(flash);

    setTimeout(function() {
        if (flash.parentNode) {
            flash.style.opacity = '0';
            flash.style.transform = 'translateX(100%)';
            setTimeout(function() { if (flash.parentNode) flash.remove(); }, 300);
        }
    }, 4000);
}

function escapeHtml(text) {
    if (!text) return '';
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
