<?php
// File: search.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

// Allow guests to search but limited
$db = Database::getInstance();

$page = max(1, intval($_GET['page'] ?? 1));
$perPage = PROFILES_PER_PAGE;
$offset = ($page - 1) * $perPage;

// Build search query
$where = ["u.status = 'active'", "u.role = 'user'"];
$params = [];

if (!empty($_GET['gender'])) {
    $where[] = "p.gender = ?";
    $params[] = $_GET['gender'];
} elseif (isLoggedIn() && $currentUser) {
    // Default: show opposite gender
    $where[] = "p.gender = ?";
    $params[] = ($currentUser['gender'] === 'male') ? 'female' : 'male';
}

if (!empty($_GET['age_from'])) {
    $where[] = "p.date_of_birth <= ?";
    $params[] = date('Y-m-d', strtotime('-' . intval($_GET['age_from']) . ' years'));
}
if (!empty($_GET['age_to'])) {
    $where[] = "p.date_of_birth >= ?";
    $params[] = date('Y-m-d', strtotime('-' . intval($_GET['age_to']) . ' years'));
}
if (!empty($_GET['religion'])) {
    $where[] = "p.religion LIKE ?";
    $params[] = '%' . $_GET['religion'] . '%';
}
if (!empty($_GET['caste'])) {
    $where[] = "p.caste LIKE ?";
    $params[] = '%' . $_GET['caste'] . '%';
}
if (!empty($_GET['country'])) {
    $where[] = "p.country LIKE ?";
    $params[] = '%' . $_GET['country'] . '%';
}
if (!empty($_GET['state'])) {
    $where[] = "p.state LIKE ?";
    $params[] = '%' . $_GET['state'] . '%';
}
if (!empty($_GET['city'])) {
    $where[] = "p.city LIKE ?";
    $params[] = '%' . $_GET['city'] . '%';
}
if (!empty($_GET['education'])) {
    $where[] = "p.education LIKE ?";
    $params[] = '%' . $_GET['education'] . '%';
}
if (!empty($_GET['marital_status'])) {
    $where[] = "p.marital_status = ?";
    $params[] = $_GET['marital_status'];
}
if (!empty($_GET['occupation'])) {
    $where[] = "p.occupation LIKE ?";
    $params[] = '%' . $_GET['occupation'] . '%';
}

// Exclude self
if (isLoggedIn()) {
    $where[] = "p.user_id != ?";
    $params[] = $_SESSION['user_id'];
}

$whereClause = implode(' AND ', $where);

// Count total
$countSql = "SELECT COUNT(*) FROM profiles p JOIN users u ON u.id = p.user_id WHERE $whereClause";
$stmt = $db->prepare($countSql);
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $perPage);

// Fetch profiles
$sql = "SELECT p.*, u.email FROM profiles p JOIN users u ON u.id = p.user_id WHERE $whereClause ORDER BY p.last_active DESC LIMIT $perPage OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll();

// Build base URL for pagination
$queryParams = $_GET;
unset($queryParams['page']);
$baseUrl = BASE_URL . '/search.php?' . http_build_query($queryParams) . '&';

$pageTitle = 'Search Profiles';
include __DIR__ . '/includes/header.php';
?>

<div class="container">
    <div class="search-page">
        <!-- Filters Sidebar -->
        <aside class="search-filters">
            <div class="filter-card">
                <h3>Filter Profiles</h3>
                <form method="GET" action="<?php echo BASE_URL; ?>/search.php" id="searchForm">
                    <div class="form-group">
                        <label class="form-label">Looking For</label>
                        <select name="gender" class="form-control">
                            <option value="">All</option>
                            <option value="male" <?php echo ($_GET['gender'] ?? '') === 'male' ? 'selected' : ''; ?>>Groom</option>
                            <option value="female" <?php echo ($_GET['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Bride</option>
                        </select>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Age From</label>
                            <input type="number" name="age_from" class="form-control" value="<?php echo sanitize($_GET['age_from'] ?? ''); ?>" min="18" max="70" placeholder="18">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Age To</label>
                            <input type="number" name="age_to" class="form-control" value="<?php echo sanitize($_GET['age_to'] ?? ''); ?>" min="18" max="70" placeholder="70">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Religion</label>
                        <input type="text" name="religion" class="form-control" value="<?php echo sanitize($_GET['religion'] ?? ''); ?>" placeholder="e.g., Hindu">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Caste</label>
                        <input type="text" name="caste" class="form-control" value="<?php echo sanitize($_GET['caste'] ?? ''); ?>" placeholder="Optional">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Country</label>
                        <input type="text" name="country" class="form-control" value="<?php echo sanitize($_GET['country'] ?? ''); ?>" placeholder="e.g., India">
                    </div>

                    <div class="form-group">
                        <label class="form-label">State</label>
                        <input type="text" name="state" class="form-control" value="<?php echo sanitize($_GET['state'] ?? ''); ?>" placeholder="e.g., Maharashtra">
                    </div>

                    <div class="form-group">
                        <label class="form-label">City</label>
                        <input type="text" name="city" class="form-control" value="<?php echo sanitize($_GET['city'] ?? ''); ?>" placeholder="e.g., Mumbai">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Education</label>
                        <input type="text" name="education" class="form-control" value="<?php echo sanitize($_GET['education'] ?? ''); ?>" placeholder="e.g., B.Tech">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Marital Status</label>
                        <select name="marital_status" class="form-control">
                            <option value="">Any</option>
                            <?php foreach (['never_married','divorced','widowed'] as $opt): ?>
                                <option value="<?php echo $opt; ?>" <?php echo ($_GET['marital_status'] ?? '') === $opt ? 'selected' : ''; ?>><?php echo ucwords(str_replace('_', ' ', $opt)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Occupation</label>
                        <input type="text" name="occupation" class="form-control" value="<?php echo sanitize($_GET['occupation'] ?? ''); ?>" placeholder="e.g., Engineer">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px;">Search</button>
                    <a href="<?php echo BASE_URL; ?>/search.php" class="btn btn-ghost btn-block" style="margin-top:8px;">Clear Filters</a>
                </form>
            </div>
        </aside>

        <!-- Results -->
        <div class="search-results">
            <div class="search-results-header">
                <div class="results-count">
                    <strong><?php echo number_format($total); ?></strong> profiles found
                    <?php if ($total > 0): ?>
                        &middot; Page <?php echo $page; ?> of <?php echo $totalPages; ?>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (empty($results)): ?>
                <div class="empty-state">
                    <div class="empty-icon">&#128270;</div>
                    <h3>No profiles found</h3>
                    <p>Try adjusting your search filters for better results.</p>
                </div>
            <?php else: ?>
                <div class="profiles-grid">
                    <?php foreach ($results as $profile): ?>
                    <div class="card profile-card">
                        <div class="profile-photo-wrapper">
                            <img src="<?php echo getProfilePhoto($profile['photo_primary'], $profile['gender']); ?>" alt="<?php echo sanitize($profile['first_name']); ?>" loading="lazy">
                            <?php if ($profile['profile_verified']): ?>
                                <span class="premium-badge">Verified</span>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <div class="profile-name"><?php echo sanitize($profile['first_name'] . ' ' . $profile['last_name']); ?></div>
                            <div class="profile-detail">
                                <?php echo calculateAge($profile['date_of_birth']); ?> yrs
                                <span class="dot"></span>
                                <?php echo $profile['height_cm'] ? formatHeight($profile['height_cm']) : ''; ?>
                            </div>
                            <div class="profile-detail">
                                <?php echo sanitize($profile['city'] ?? ''); ?><?php echo $profile['city'] && $profile['state'] ? ', ' : ''; ?><?php echo sanitize($profile['state'] ?? ''); ?>
                            </div>
                            <div class="profile-detail">
                                <?php echo sanitize($profile['education'] ?? ''); ?>
                                <span class="dot"></span>
                                <?php echo sanitize($profile['occupation'] ?? ''); ?>
                            </div>
                            <div class="profile-detail"><?php echo sanitize($profile['religion'] ?? ''); ?></div>
                     <div class="profile-actions">
    <?php if (isLoggedIn()): ?>
        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profile['user_id']; ?>" class="btn btn-secondary btn-sm">View</a>
        <button class="btn btn-primary btn-sm" data-action="interest" data-user-id="<?php echo $profile['user_id']; ?>">Send Interest</button>
    <?php else: ?>
        <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-primary btn-sm btn-block">Login to View</a>
    <?php endif; ?>
</div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php echo pagination($page, $totalPages, $baseUrl); ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
