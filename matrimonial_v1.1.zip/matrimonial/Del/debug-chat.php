<?php
// File: debug-chat.php
// Open: http://localhost/matrimonial/debug-chat.php
// Shows exactly what is broken in the chat system

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

session_start();

echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Chat Debug</title>
<style>
body{font-family:"DM Sans",Arial,sans-serif;background:#FDF8F4;color:#1A0A0E;padding:20px;max-width:800px;margin:0 auto}
h1{color:#8B1A2B} h2{color:#4A3540;margin-top:24px;font-size:1.1rem}
.card{background:white;border:1px solid #E8DDD5;border-radius:12px;padding:20px;margin:12px 0}
.ok{color:#2D7D46;font-weight:600} .err{color:#C62828;font-weight:600} .warn{color:#D4A843;font-weight:600}
.row{padding:6px 0;border-bottom:1px solid #F0E8E0;font-size:0.9rem}
.row:last-child{border-bottom:none}
table{width:100%;border-collapse:collapse;font-size:0.85rem}
th,td{padding:8px 10px;text-align:left;border-bottom:1px solid #F0E8E0}
th{background:#F7F0EA;font-size:0.75rem;text-transform:uppercase;color:#8A7580}
code{background:#F0E8E0;padding:2px 6px;border-radius:4px;font-size:0.82rem}
pre{background:#1A0A0E;color:#FDF8F4;padding:16px;border-radius:8px;overflow-x:auto;font-size:0.82rem}
.btn{display:inline-block;background:#8B1A2B;color:white;padding:10px 24px;border-radius:99px;text-decoration:none;font-weight:600;margin-top:8px}
.fix-section{background:#FFF8E1;border:1px solid #D4A843;border-radius:12px;padding:20px;margin:12px 0}
</style></head><body>';

echo '<h1>&#128172; Chat System Diagnostic</h1>';

$db = Database::getInstance();

// Check 1: Login status
echo '<h2>1. Authentication</h2><div class="card">';
if (isLoggedIn()) {
    $userId = $_SESSION['user_id'];
    echo '<div class="row"><span class="ok">&#10003;</span> Logged in as user ID: ' . $userId . ' (' . htmlspecialchars($_SESSION['user_email'] ?? '') . ')</div>';
} else {
    echo '<div class="row"><span class="err">&#10007;</span> NOT logged in</div>';
    echo '<p><a href="' . BASE_URL . '/login.php" class="btn">Login First</a></p>';
    echo '</div></body></html>';
    exit;
}
echo '</div>';

// Check 2: Database tables
echo '<h2>2. Database Tables</h2><div class="card">';
$tables = ['users', 'profiles', 'messages', 'typing_status'];
foreach ($tables as $table) {
    try {
        $count = $db->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
        echo '<div class="row"><span class="ok">&#10003;</span> <code>' . $table . '</code> — ' . $count . ' rows</div>';
    } catch (PDOException $e) {
        echo '<div class="row"><span class="err">&#10007;</span> <code>' . $table . '</code> — ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}
echo '</div>';

// Check 3: Messages table structure
echo '<h2>3. Messages Table Columns</h2><div class="card">';
try {
    $cols = $db->query("DESCRIBE messages")->fetchAll();
    echo '<table><tr><th>Column</th><th>Type</th><th>Null</th><th>Default</th></tr>';
    foreach ($cols as $col) {
        echo '<tr><td><code>' . $col['Field'] . '</code></td><td>' . $col['Type'] . '</td><td>' . $col['Null'] . '</td><td>' . ($col['Default'] ?? 'NULL') . '</td></tr>';
    }
    echo '</table>';
} catch (Exception $e) {
    echo '<div class="row"><span class="err">' . htmlspecialchars($e->getMessage()) . '</span></div>';
}
echo '</div>';

// Check 4: Current user's messages
echo '<h2>4. Your Messages</h2><div class="card">';
try {
    $stmt = $db->prepare("SELECT m.*,
        sp.first_name as sender_name,
        rp.first_name as receiver_name
        FROM messages m
        LEFT JOIN profiles sp ON sp.user_id = m.sender_id
        LEFT JOIN profiles rp ON rp.user_id = m.receiver_id
        WHERE m.sender_id = ? OR m.receiver_id = ?
        ORDER BY m.created_at DESC LIMIT 10");
    $stmt->execute([$userId, $userId]);
    $msgs = $stmt->fetchAll();

    if (empty($msgs)) {
        echo '<div class="row"><span class="warn">&#9888;</span> No messages found for your user ID</div>';
    } else {
        echo '<table><tr><th>ID</th><th>From</th><th>To</th><th>Message</th><th>Read</th><th>Time</th></tr>';
        foreach ($msgs as $m) {
            $isMine = $m['sender_id'] == $userId;
            echo '<tr>';
            echo '<td>' . $m['id'] . '</td>';
            echo '<td>' . htmlspecialchars($m['sender_name'] ?? '?') . ($isMine ? ' (you)' : '') . '</td>';
            echo '<td>' . htmlspecialchars($m['receiver_name'] ?? '?') . (!$isMine ? ' (you)' : '') . '</td>';
            echo '<td>' . htmlspecialchars(mb_substr($m['message'], 0, 30)) . '</td>';
            echo '<td>' . ($m['is_read'] ? '&#10003;' : '&#10007;') . '</td>';
            echo '<td>' . $m['created_at'] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
} catch (PDOException $e) {
    echo '<div class="row"><span class="err">Query error: ' . htmlspecialchars($e->getMessage()) . '</span></div>';
}
echo '</div>';

// Check 5: Conversations query
echo '<h2>5. Conversations Query Test</h2><div class="card">';
try {
    $stmt = $db->prepare("
        SELECT
            sub.other_user_id,
            sub.max_id,
            p.first_name,
            p.last_name,
            p.is_online
        FROM (
            SELECT
                CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END as other_user_id,
                MAX(m.id) as max_id
            FROM messages m
            WHERE m.sender_id = ? OR m.receiver_id = ?
            GROUP BY other_user_id
        ) sub
        JOIN profiles p ON p.user_id = sub.other_user_id
        ORDER BY sub.max_id DESC
    ");
    $stmt->execute([$userId, $userId, $userId]);
    $convs = $stmt->fetchAll();

    if (empty($convs)) {
        echo '<div class="row"><span class="warn">&#9888;</span> No conversations found</div>';
    } else {
        echo '<div class="row"><span class="ok">&#10003;</span> Found ' . count($convs) . ' conversation(s)</div>';
        echo '<table><tr><th>User ID</th><th>Name</th><th>Online</th><th>Last Msg ID</th></tr>';
        foreach ($convs as $c) {
            echo '<tr>';
            echo '<td>' . $c['other_user_id'] . '</td>';
            echo '<td>' . htmlspecialchars($c['first_name'] . ' ' . $c['last_name']) . '</td>';
            echo '<td>' . ($c['is_online'] ? '&#10003;' : '&#10007;') . '</td>';
            echo '<td>' . $c['max_id'] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
} catch (PDOException $e) {
    echo '<div class="row"><span class="err">Query error: ' . htmlspecialchars($e->getMessage()) . '</span></div>';
}
echo '</div>';

// Check 6: Test get-messages API locally
echo '<h2>6. API Simulation: get-messages.php</h2><div class="card">';
if (!empty($convs)) {
    $testWith = $convs[0]['other_user_id'];
    try {
        $stmt = $db->prepare("
            SELECT m.*,
                   sp.first_name as sender_name, sp.photo_primary as sender_photo, sp.gender as sender_gender
            FROM messages m
            LEFT JOIN profiles sp ON sp.user_id = m.sender_id
            WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
            ORDER BY m.id DESC
            LIMIT 50
        ");
        $stmt->execute([$userId, $testWith, $testWith, $userId]);
        $testMsgs = $stmt->fetchAll();
        $testMsgs = array_reverse($testMsgs);

        echo '<div class="row"><span class="ok">&#10003;</span> Loaded ' . count($testMsgs) . ' messages with user ' . $testWith . '</div>';
    } catch (PDOException $e) {
        echo '<div class="row"><span class="err">Query error: ' . htmlspecialchars($e->getMessage()) . '</span></div>';
    }
} else {
    echo '<div class="row"><span class="warn">&#9888;</span> No conversations to test with</div>';
}
echo '</div>';

// Check 7: Unread count
echo '<h2>7. Unread Count</h2><div class="card">';
$stmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0");
$stmt->execute([$userId]);
$unread = $stmt->fetchColumn();
echo '<div class="row"><span class="ok">&#10003;</span> Unread messages: <strong>' . $unread . '</strong></div>';
echo '</div>';

// Check 8: Profiles table online columns
echo '<h2>8. Profiles Table Online Columns</h2><div class="card">';
try {
    $cols = $db->query("DESCRIBE profiles")->fetchAll();
    $colNames = array_column($cols, 'Field');
    $hasOnline = in_array('is_online', $colNames);
    $hasLastSeen = in_array('last_seen', $colNames);
    echo '<div class="row">' . ($hasOnline ? '<span class="ok">&#10003;</span>' : '<span class="err">&#10007;</span>') . ' <code>is_online</code> column</div>';
    echo '<div class="row">' . ($hasLastSeen ? '<span class="ok">&#10003;</span>' : '<span class="err">&#10007;</span>') . ' <code>last_seen</code> column</div>';

    if (!$hasOnline) {
        $db->exec("ALTER TABLE profiles ADD COLUMN is_online TINYINT(1) NOT NULL DEFAULT 0");
        echo '<div class="row"><span class="warn">FIXED</span> Added <code>is_online</code> column</div>';
    }
    if (!$hasLastSeen) {
        $db->exec("ALTER TABLE profiles ADD COLUMN last_seen DATETIME DEFAULT NULL");
        echo '<div class="row"><span class="warn">FIXED</span> Added <code>last_seen</code> column</div>';
    }
} catch (Exception $e) {
    echo '<div class="row"><span class="err">' . htmlspecialchars($e->getMessage()) . '</span></div>';
}
echo '</div>';

// Check 9: Typing status table
echo '<h2>9. Typing Status Table</h2><div class="card">';
try {
    $db->exec("CREATE TABLE IF NOT EXISTS typing_status (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        chat_with INT NOT NULL,
        is_typing TINYINT(1) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_typing (user_id, chat_with)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    echo '<div class="row"><span class="ok">&#10003;</span> <code>typing_status</code> table ready</div>';
} catch (Exception $e) {
    echo '<div class="row"><span class="err">' . htmlspecialchars($e->getMessage()) . '</span></div>';
}
echo '</div>';

echo '<h2 style="margin-top:32px;">&#10003; Diagnostic Complete</h2>';
echo '<p><a href="' . BASE_URL . '/messages.php" class="btn">Open Messages</a></p>';
echo '<p style="margin-top:12px;font-size:0.85rem;color:#C62828;"><strong>Delete <code>debug-chat.php</code> after testing!</strong></p>';
echo '</body></html>';
