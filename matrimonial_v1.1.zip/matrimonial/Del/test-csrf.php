<?php
// File: test-csrf.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

session_start();
$token = generateCsrfToken();

echo "<h2>CSRF Token Test</h2>";
echo "<p>Session Token: <code>" . htmlspecialchars($token) . "</code></p>";
echo "<p>Token Length: " . strlen($token) . "</p>";
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>Session Status: " . (session_status() === PHP_SESSION_ACTIVE ? 'Active' : 'Not Active') . "</p>";

echo "<hr>";
echo "<h3>Test AJAX Interest Action</h3>";
echo "<p id='result'></p>";
echo "<button onclick='testAction()' style='padding:10px 24px;background:#8B1A2B;color:white;border:none;border-radius:99px;cursor:pointer;font-weight:600;'>Test Send Interest (ID 2)</button>";

echo "<script>
async function testAction() {
    var fd = new FormData();
    fd.append('action', 'interest');
    fd.append('user_id', '2');
    fd.append('csrf_token', '" . $token . "');

    try {
        var resp = await fetch('" . BASE_URL . "/api/interest-action.php', {method:'POST', body:fd});
        var data = await resp.json();
        document.getElementById('result').innerHTML = '<strong>Response:</strong><br><pre>' + JSON.stringify(data, null, 2) + '</pre>';
    } catch(e) {
        document.getElementById('result').innerHTML = '<span style=\"color:red;\">Error: ' + e.message + '</span>';
    }
}
</script>";
