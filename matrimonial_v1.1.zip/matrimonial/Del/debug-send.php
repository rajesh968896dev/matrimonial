<?php
// File: debug-send.php
// Open: http://localhost/matrimonial/debug-send.php

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Send Message Debug</title>
<style>
body{font-family:'DM Sans',Arial,sans-serif;background:#FDF8F4;color:#1A0A0E;padding:20px;max-width:700px;margin:0 auto}
h1{color:#8B1A2B}
.card{background:white;border:1px solid #E8DDD5;border-radius:12px;padding:20px;margin:12px 0}
.ok{color:#2D7D46} .err{color:#C62828} .warn{color:#D4A843}
.row{padding:6px 0;border-bottom:1px solid #F0E8E0;font-size:0.9rem}
.btn{display:inline-block;background:#8B1A2B;color:white;padding:10px 24px;border-radius:99px;text-decoration:none;font-weight:600;margin:4px;cursor:pointer;border:none;font-size:0.9rem}
.btn-ghost{background:transparent;color:#8B1A2B;border:2px solid #8B1A2B}
.test-box{background:#F7F0EA;border-radius:8px;padding:16px;margin:12px 0}
.test-box textarea{width:100%;padding:10px;border:1px solid #E8DDD5;border-radius:8px;font-size:0.95rem;min-height:60px;resize:vertical;font-family:inherit}
.test-box select{padding:8px;border:1px solid #E8DDD5;border-radius:8px;font-size:0.9rem;width:100%;margin-bottom:8px}
#result{margin-top:12px;padding:12px;border-radius:8px;font-size:0.85rem;display:none}
#result.show{display:block}
#result.pass{background:#E8F5E9;color:#2D7D46}
#result.fail{background:#FFEBEE;color:#C62828}
pre{background:#1A0A0E;color:#FDF8F4;padding:12px;border-radius:8px;overflow-x:auto;font-size:0.82rem;margin:8px 0}
</style>
</head>
<body>

<h1>&#128172; Send Message Debug</h1>
<p>User ID: <strong><?php echo $userId; ?></strong> (<?php echo htmlspecialchars($_SESSION['user_email']); ?>)</p>

<div class="card">
<h3>1. Find a valid conversation partner</h3>
<?php
// Find someone this user has messages with
$partners = safeFetch($db, "
    SELECT DISTINCT CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END as pid
    FROM messages m WHERE m.sender_id = ? OR m.receiver_id = ?
", [$userId, $userId, $userId]);

if (empty($partners)) {
    // No messages yet, find any other active user
    $partners = safeFetch($db, "SELECT user_id as pid FROM profiles WHERE user_id != ? LIMIT 5", [$userId]);
}

if (empty($partners)) {
    echo '<div class="row"><span class="err">&#10007;</span> No other users found. Register another account to test.</div>';
} else {
    echo '<div class="row"><span class="ok">&#10003;</span> Found ' . count($partners) . ' potential partner(s)</div>';
    foreach ($partners as $p) {
        $profile = safeFetchOne($db, "SELECT first_name, last_name FROM profiles WHERE user_id = ?", [$p['pid']]);
        if ($profile) {
            echo '<div class="row">&bull; User #' . $p['pid'] . ' - ' . htmlspecialchars($profile['first_name'] . ' ' . $profile['last_name']) . '</div>';
        }
    }
}
?>
</div>

<div class="card">
<h3>2. Test send-message.php API directly</h3>
<div class="test-box">
    <label><strong>Select recipient:</strong></label>
    <select id="testReceiver">
        <option value="">-- Choose --</option>
        <?php foreach ($partners as $p): ?>
            <?php $profile = safeFetchOne($db, "SELECT first_name FROM profiles WHERE user_id = ?", [$p['pid']]); ?>
            <option value="<?php echo $p['pid']; ?>">
                #<?php echo $p['pid']; ?> - <?php echo htmlspecialchars($profile['first_name'] ?? 'Unknown'); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <label><strong>Message:</strong></label>
    <textarea id="testMsg" placeholder="Type a test message...">Hello, this is a test message!</textarea>
    <br><br>
    <button class="btn" onclick="testSend()">Send Test Message</button>
    <button class="btn btn-ghost" onclick="testFetch()">Fetch Messages</button>
</div>
<div id="result"></div>
</div>

<div class="card">
<h3>3. Messages table check</h3>
<div class="row">Total messages: <strong><?php echo safeFetchColumn($db, "SELECT COUNT(*) FROM messages"); ?></strong></div>
<div class="row">Your sent: <strong><?php echo safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE sender_id = ?", [$userId]); ?></strong></div>
<div class="row">Your received: <strong><?php echo safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE receiver_id = ?", [$userId]); ?></strong></div>
<div class="row">Unread for you: <strong><?php echo safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0", [$userId]); ?></strong></div>
</div>

<script>
var BASE = '<?php echo BASE_URL; ?>';
var CSRF = '<?php echo generateCsrfToken(); ?>';
var result = document.getElementById('result');

function showResult(success, text) {
    result.className = 'show ' + (success ? 'pass' : 'fail');
    result.innerHTML = '<pre>' + text + '</pre>';
}

async function testSend() {
    var receiver = document.getElementById('testReceiver').value;
    var msg = document.getElementById('testMsg').value.trim();

    if (!receiver) { showResult(false, 'ERROR: Select a receiver first'); return; }
    if (!msg) { showResult(false, 'ERROR: Type a message first'); return; }

    result.className = 'show';
    result.innerHTML = 'Sending...';
    result.style.background = '#FFF8E1';
    result.style.color = '#6D5D00';

    try {
        var fd = new FormData();
        fd.append('receiver_id', receiver);
        fd.append('message', msg);

        var resp = await fetch(BASE + '/api/send-message.php', {
            method: 'POST',
            body: fd
        });

        var text = await resp.text();

        try {
            var json = JSON.parse(text);
            if (json.success) {
                showResult(true, 'SUCCESS!\n\n' + JSON.stringify(json, null, 2));
            } else {
                showResult(false, 'API RETURNED ERROR:\n\n' + JSON.stringify(json, null, 2));
            }
        } catch(e) {
            showResult(false, 'INVALID JSON RESPONSE:\n\nStatus: ' + resp.status + '\nResponse:\n' + text);
        }
    } catch(e) {
        showResult(false, 'FETCH ERROR:\n\n' + e.message);
    }
}

async function testFetch() {
    var receiver = document.getElementById('testReceiver').value;
    if (!receiver) { showResult(false, 'ERROR: Select a user first'); return; }

    result.className = 'show';
    result.innerHTML = 'Loading...';
    result.style.background = '#FFF8E1';
    result.style.color = '#6D5D00';

    try {
        var resp = await fetch(BASE + '/api/get-messages.php?chat_with=' + receiver);
        var text = await resp.text();

        try {
            var json = JSON.parse(text);
            showResult(json.success, JSON.stringify(json, null, 2).substring(0, 2000));
        } catch(e) {
            showResult(false, 'INVALID JSON:\n\n' + text.substring(0, 1000));
        }
    } catch(e) {
        showResult(false, 'FETCH ERROR:\n\n' + e.message);
    }
}
</script>

</body>
</html>
