<?php
// File: fix-chat.php
// Run once: http://localhost/matrimonial/fix-chat.php

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$db = Database::getInstance();
$logs = [];

function logMsg($msg, $ok = true) {
    global $logs;
    $logs[] = ['msg' => $msg, 'ok' => $ok];
}

// Add is_online and last_seen columns to profiles
try {
    $cols = [];
    $stmt = $db->query("DESCRIBE profiles");
    while ($row = $stmt->fetch()) { $cols[] = $row['Field']; }

    if (!in_array('is_online', $cols)) {
        $db->exec("ALTER TABLE profiles ADD COLUMN is_online TINYINT(1) NOT NULL DEFAULT 0");
        logMsg("Added profiles.is_online");
    } else {
        logMsg("profiles.is_online exists");
    }

    if (!in_array('last_seen', $cols)) {
        $db->exec("ALTER TABLE profiles ADD COLUMN last_seen DATETIME DEFAULT NULL");
        logMsg("Added profiles.last_seen");
    } else {
        logMsg("profiles.last_seen exists");
    }
} catch (Exception $e) {
    logMsg("Error: " . $e->getMessage(), false);
}

// Add message_type column to messages
try {
    $cols = [];
    $stmt = $db->query("DESCRIBE messages");
    while ($row = $stmt->fetch()) { $cols[] = $row['Field']; }

    if (!in_array('message_type', $cols)) {
        $db->exec("ALTER TABLE messages ADD COLUMN message_type VARCHAR(20) NOT NULL DEFAULT 'text'");
        logMsg("Added messages.message_type");
    } else {
        logMsg("messages.message_type exists");
    }

    // Add index for faster polling
    try {
        $db->exec("ALTER TABLE messages ADD INDEX idx_created (created_at)");
        logMsg("Added messages.index on created_at");
    } catch (Exception $e) {
        logMsg("messages index on created_at already exists or added");
    }
} catch (Exception $e) {
    logMsg("Error: " . $e->getMessage(), false);
}

// Create typing_status table
try {
    $db->exec("CREATE TABLE IF NOT EXISTS typing_status (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        chat_with INT NOT NULL,
        is_typing TINYINT(1) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_typing (user_id, chat_with)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    logMsg("typing_status table ready");
} catch (Exception $e) {
    logMsg("Error: " . $e->getMessage(), false);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Chat DB Fix</title>
<style>
body{font-family:'DM Sans',sans-serif;background:#FDF8F4;padding:40px 20px;max-width:600px;margin:0 auto}
.ok{color:#2D7D46} .err{color:#C62828}
.card{background:white;border:1px solid #E8DDD5;border-radius:12px;padding:24px;margin-bottom:16px}
.log{padding:6px 0;border-bottom:1px solid #F0E8E0;font-size:0.9rem}
.btn{display:inline-block;background:#8B1A2B;color:white;padding:12px 28px;border-radius:99px;text-decoration:none;font-weight:600;margin-top:12px}
</style>
</head>
<body>
<h1>&#9825; Chat Database Setup</h1>
<div class="card">
<?php foreach ($logs as $l): ?>
    <div class="log <?php echo $l['ok'] ? 'ok' : 'err'; ?>">
        <?php echo $l['ok'] ? '&#10003;' : '&#10007;'; ?>
        <?php echo htmlspecialchars($l['msg']); ?>
    </div>
<?php endforeach; ?>
</div>
<p><a href="http://localhost/matrimonial/messages.php" class="btn">Open Chat &#8594;</a></p>
<p style="margin-top:12px;font-size:0.85rem;color:#C62828;"><strong>Delete this file after running!</strong></p>
</body>
</html>
