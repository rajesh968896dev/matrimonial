<?php
// File: messages.php — COMPLETE REPLACEMENT

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];
$chatWith = (int) ($_GET['user'] ?? 0);

// Mark user online
try {
    $db->prepare("UPDATE profiles SET is_online = 1, last_seen = NOW() WHERE user_id = ?")->execute([$userId]);
} catch (Exception $e) {}

// Get partner info if chat is open
$chatPartner = null;
if ($chatWith > 0) {
    $chatPartner = safeFetchOne($db, "SELECT p.*, u.email FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.user_id = ?", [$chatWith]);
}


$csrfToken = generateCsrfToken();
$baseUrl = BASE_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="csrf-token" content="<?php echo htmlspecialchars($csrfToken); ?>">
    <title>Messages | VivahaBandhan</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:#F5F0EB;--surface:#FFFFFF;--accent:#8B1A2B;--accent-light:#A8324A;
            --accent-glow:rgba(139,26,43,0.1);--gold:#D4A843;
            --text:#1A0A0E;--text-sec:#4A3540;--text-muted:#8A7580;--text-light:#B0A0A8;
            --border:#E8DDD5;--border-light:#F0E8E0;--success:#2D7D46;--error:#C62828;
            --sent-bg:#8B1A2B;--sent-txt:#FFF;--rec-bg:#FFF;--rec-txt:#1A0A0E;
            --r-sm:8px;--r-md:12px;--r-lg:18px;--r-xl:22px;--r-full:9999px;
            --font:'DM Sans',-apple-system,sans-serif;
        }
        *,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
        html,body{height:100%;overflow:hidden}
        body{font-family:var(--font);background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased}
        button{font-family:inherit;cursor:pointer;border:none;background:none}
        a{text-decoration:none;color:inherit}
        img{display:block;max-width:100%}

        .chat-app{display:flex;height:100vh}

        /* SIDEBAR */
        .sidebar{width:380px;min-width:380px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;height:100vh;z-index:10}
        .sb-header{padding:20px 24px;border-bottom:1px solid var(--border-light);flex-shrink:0}
        .sb-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
        .sb-title{font-size:1.4rem;font-weight:700;display:flex;align-items:center;gap:10px}
        .sb-title .ico{color:var(--accent)}
        .sb-back{color:var(--text-muted);font-size:0.85rem;font-weight:500}
        .sb-back:hover{color:var(--accent)}
        .sb-search{position:relative}
        .sb-search input{width:100%;padding:10px 16px 10px 40px;background:var(--bg);border:1.5px solid transparent;border-radius:var(--r-full);font-size:0.88rem;font-family:var(--font);color:var(--text);outline:none}
        .sb-search input:focus{border-color:var(--accent);background:var(--surface);box-shadow:0 0 0 3px var(--accent-glow)}
        .sb-search input::placeholder{color:var(--text-light)}
        .sb-search .s-ico{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--text-light);pointer-events:none}

        .conv-scroll{flex:1;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--border) transparent}
        .conv-scroll::-webkit-scrollbar{width:5px}
        .conv-scroll::-webkit-scrollbar-thumb{background:var(--border);border-radius:10px}

        .ci{display:flex;align-items:center;gap:14px;padding:14px 24px;cursor:pointer;border-bottom:1px solid var(--border-light);transition:background 0.15s}
        .ci:hover{background:var(--bg)}
        .ci.active{background:var(--accent-glow);border-left:3px solid var(--accent);padding-left:21px}
        .ci-av{position:relative;flex-shrink:0}
        .ci-av img{width:50px;height:50px;border-radius:50%;object-fit:cover;background:var(--bg)}
        .ci-av .dot-online{position:absolute;bottom:1px;right:1px;width:13px;height:13px;background:var(--success);border:2.5px solid var(--surface);border-radius:50%}
        .ci-info{flex:1;min-width:0}
        .ci-name{font-weight:600;font-size:0.95rem;display:flex;justify-content:space-between;align-items:center}
        .ci-time{font-size:0.72rem;color:var(--text-light);font-weight:400}
        .ci-preview{font-size:0.83rem;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;justify-content:space-between;align-items:center;gap:8px}
        .ci-preview-txt{overflow:hidden;text-overflow:ellipsis}
        .ci-badge{min-width:20px;height:20px;background:var(--accent);color:white;font-size:0.68rem;font-weight:700;border-radius:var(--r-full);display:flex;align-items:center;justify-content:center;padding:0 5px;flex-shrink:0}

        .conv-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);text-align:center;padding:40px}
        .conv-empty .e-ico{font-size:3rem;margin-bottom:16px;opacity:0.3}
        .conv-empty h3{font-size:1.1rem;color:var(--text-sec);margin-bottom:8px}
        .conv-empty p{font-size:0.88rem;margin-bottom:20px;line-height:1.5}
        .conv-empty .btn-cta{display:inline-block;background:var(--accent);color:white;padding:10px 24px;border-radius:var(--r-full);font-weight:600;font-size:0.88rem}

        /* CHAT AREA */
        .chat-area{flex:1;display:flex;flex-direction:column;background:var(--bg)}

        .ch-header{background:var(--surface);border-bottom:1px solid var(--border);padding:14px 24px;display:flex;align-items:center;gap:14px;flex-shrink:0}
        .ch-header .back-btn{display:none;width:36px;height:36px;border-radius:50%;align-items:center;justify-content:center;background:var(--bg);color:var(--text-sec);font-size:1.1rem;flex-shrink:0}
        .ch-header img{width:42px;height:42px;border-radius:50%;object-fit:cover;background:var(--bg);flex-shrink:0}
        .ch-info{flex:1}
        .ch-name{font-weight:600;font-size:1rem}
        .ch-status{font-size:0.78rem;color:var(--text-muted);margin-top:1px}
        .ch-status.on{color:var(--success);font-weight:500}
        .ch-acts a,.ch-acts button{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--text-muted);background:var(--bg);font-size:0.9rem}
        .ch-acts a:hover,.ch-acts button:hover{background:var(--accent-glow);color:var(--accent)}

        .msgs{flex:1;overflow-y:auto;padding:20px 24px;display:flex;flex-direction:column;gap:4px;scroll-behavior:smooth}
        .msgs::-webkit-scrollbar{width:5px}
        .msgs::-webkit-scrollbar-thumb{background:var(--border);border-radius:10px}

        .date-sep{display:flex;align-items:center;justify-content:center;margin:16px 0}
        .date-sep span{background:var(--surface);color:var(--text-muted);font-size:0.75rem;font-weight:600;padding:4px 16px;border-radius:var(--r-full);border:1px solid var(--border-light)}

        .m-row{display:flex;align-items:flex-end;gap:8px;max-width:75%;animation:fadeIn 0.2s ease}
        @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        .m-row.sent{align-self:flex-end;flex-direction:row-reverse}
        .m-row.recv{align-self:flex-start}
        .m-bubble{padding:10px 16px;font-size:0.92rem;line-height:1.55;word-wrap:break-word}
        .m-row.sent .m-bubble{background:var(--sent-bg);color:var(--sent-txt);border-radius:var(--r-xl) var(--r-xl) 6px var(--r-xl)}
        .m-row.recv .m-bubble{background:var(--rec-bg);color:var(--rec-txt);border:1px solid var(--border-light);border-radius:var(--r-xl) var(--r-xl) var(--r-xl) 6px}
        .m-time{font-size:0.68rem;margin-top:4px;display:flex;align-items:center;gap:4px}
        .m-row.sent .m-time{color:rgba(255,255,255,0.6);justify-content:flex-end}
        .m-row.recv .m-time{color:var(--text-light)}
        .m-check{font-size:0.75rem}
        .m-check.read{color:#4FC3F7}

        .typing{display:none;align-self:flex-start;padding:8px 16px;background:var(--surface);border:1px solid var(--border-light);border-radius:var(--r-xl) var(--r-xl) var(--r-xl) 6px;margin-top:4px}
        .typing.show{display:flex;align-items:center;gap:4px}
        .t-dot{width:7px;height:7px;background:var(--text-light);border-radius:50%;animation:bounce 1.4s infinite}
        .t-dot:nth-child(2){animation-delay:0.2s}
        .t-dot:nth-child(3){animation-delay:0.4s}
        @keyframes bounce{0%,60%,100%{transform:translateY(0);opacity:0.4}30%{transform:translateY(-6px);opacity:1}}

        .ch-input{background:var(--surface);border-top:1px solid var(--border);padding:14px 24px;display:flex;align-items:flex-end;gap:12px;flex-shrink:0}
        .ch-input.hidden{display:none}
        .ch-input textarea{flex:1;padding:12px 18px;background:var(--bg);border:1.5px solid transparent;border-radius:var(--r-full);font-size:0.92rem;font-family:var(--font);color:var(--text);outline:none;resize:none;min-height:44px;max-height:120px;line-height:1.4}
        .ch-input textarea:focus{border-color:var(--accent);background:var(--surface);box-shadow:0 0 0 3px var(--accent-glow)}
        .ch-input textarea::placeholder{color:var(--text-light)}
        .send-btn{width:44px;height:44px;border-radius:50%;background:var(--accent);color:white;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;transition:all 0.2s}
        .send-btn:hover{background:var(--accent-light);transform:scale(1.05)}
        .send-btn:disabled{background:var(--border);cursor:not-allowed;transform:none}

        .chat-empty{flex:1;display:flex;align-items:center;justify-content:center;text-align:center;color:var(--text-muted);padding:40px}
        .chat-empty .e-ico{font-size:4rem;opacity:0.2;margin-bottom:20px}
        .chat-empty h3{font-size:1.3rem;color:var(--text-sec);margin-bottom:8px}
        .chat-empty p{font-size:0.95rem;line-height:1.6;max-width:320px}

        /* TOAST */
        .toast-box{position:fixed;top:20px;right:20px;z-index:99999;max-width:360px}
        .toast{padding:12px 20px;border-radius:var(--r-md);font-size:0.88rem;margin-bottom:8px;box-shadow:0 4px 20px rgba(0,0,0,0.12);display:flex;justify-content:space-between;align-items:center;gap:10px;animation:slideR 0.3s ease}
        .toast.s{background:#E8F5E9;color:#2D7D46;border-left:4px solid #2D7D46}
        .toast.e{background:#FFEBEE;color:#C62828;border-left:4px solid #C62828}
        @keyframes slideR{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
        .toast button{background:none;border:none;font-size:1.1rem;cursor:pointer;opacity:0.5;color:inherit}

        @media(max-width:768px){
            .sidebar{width:100%;min-width:100%;position:absolute;inset:0;z-index:20;transition:transform 0.3s ease}
            .sidebar.hide-m{transform:translateX(-100%)}
            .ch-header .back-btn{display:flex}
            .m-row{max-width:85%}
            .sb-back{display:none}
        }
    </style>
</head>
<body>

<div class="chat-app">

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sb-header">
            <div class="sb-top">
                <div class="sb-title"><span class="ico">&#9825;</span> Messages</div>
                <a href="<?php echo $baseUrl; ?>/" class="sb-back">&#8592; Home</a>
            </div>
            <div class="sb-search">
                <span class="s-ico">&#128269;</span>
                <input type="text" id="searchInput" placeholder="Search conversations..." autocomplete="off">
            </div>
        </div>
        <div class="conv-scroll" id="convList">
            <div class="conv-empty" id="convLoading">
                <div class="e-ico">&#128172;</div>
                <h3>Loading...</h3>
            </div>
        </div>
    </aside>

    <!-- CHAT AREA -->
    <div class="chat-area">

        <?php if ($chatPartner): ?>
        <div class="ch-header" id="chatHeader">
            <button class="back-btn" id="backBtn">&#8592;</button>
            <img id="chatAvatar" src="<?php echo getProfilePhoto($chatPartner['photo_primary'], $chatPartner['gender']); ?>" alt="">
            <div class="ch-info">
                <div class="ch-name" id="chatName"><?php echo sanitize($chatPartner['first_name'] . ' ' . $chatPartner['last_name']); ?></div>
                <div class="ch-status" id="chatStatus">
                    <?php echo ($chatPartner['is_online'] ?? 0) ? 'Online' : 'Offline'; ?>
                </div>
            </div>
            <div class="ch-acts">
                <a href="<?php echo $baseUrl; ?>/profile.php?id=<?php echo $chatWith; ?>" title="Profile">&#128100;</a>
            </div>
        </div>

        <div class="msgs" id="msgs">
            <div style="text-align:center;padding:40px;color:var(--text-light)" id="loadingMsg">Loading messages...</div>
        </div>

        <div class="typing" id="typingBox">
            <div class="t-dot"></div><div class="t-dot"></div><div class="t-dot"></div>
        </div>

        <div class="ch-input" id="chatInput">
            <textarea id="msgText" rows="1" placeholder="Type your message..."></textarea>
            <button class="send-btn" id="sendBtn">&#10148;</button>
        </div>

        <?php else: ?>
        <div class="chat-empty">
            <div>
                <div class="e-ico">&#128172;</div>
                <h3>Welcome to Messages</h3>
                <p>Select a conversation from the left to start chatting.</p>
                <a href="<?php echo $baseUrl; ?>/search.php" style="display:inline-block;background:var(--accent);color:white;padding:12px 28px;border-radius:99px;font-weight:600;margin-top:16px;font-size:0.9rem;">Browse Profiles</a>
            </div>
        </div>
        <div class="ch-input hidden" id="chatInput"></div>
        <?php endif; ?>

    </div>
</div>

<script>
(function(){
    'use strict';

    var BASE = '<?php echo $baseUrl; ?>';
    var CSRF = '<?php echo $csrfToken; ?>';
    var ME = <?php echo $userId; ?>;
    var chatWith = <?php echo $chatWith ?: 'null'; ?>;
    var lastId = 0;
    var poller = null;
    var convPoller = null;
    var typeTimer = null;
    var amTyping = false;
    var allConvs = [];
    var sendInProgress = false;

    // DOM refs
    var sidebar = document.getElementById('sidebar');
    var convList = document.getElementById('convList');
    var msgs = document.getElementById('msgs');
    var msgText = document.getElementById('msgText');
    var sendBtn = document.getElementById('sendBtn');
    var backBtn = document.getElementById('backBtn');
    var typingBox = document.getElementById('typingBox');
    var chatHeader = document.getElementById('chatHeader');
    var chatName = document.getElementById('chatName');
    var chatStatus = document.getElementById('chatStatus');
    var chatAvatar = document.getElementById('chatAvatar');
    var searchInput = document.getElementById('searchInput');

    // ============ HELPERS ============
    function esc(t) {
        if (!t) return '';
        var d = document.createElement('div');
        d.textContent = t;
        return d.innerHTML;
    }

    function photo(p, g) {
        if (p && p.length > 0) return BASE + '/uploads/photos/' + p;
        return g === 'female' ? BASE + '/assets/images/default-female.svg' : BASE + '/assets/images/default-male.svg';
    }

    function fmtTime(s) {
        if (!s) return '';
        try {
            var d = new Date(s.replace(' ', 'T'));
            var now = new Date();
            var diff = (now - d) / 1000;
            if (diff < 60) return 'now';
            if (diff < 3600) return Math.floor(diff / 60) + 'm';
            if (diff < 86400) return d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
            if (diff < 604800) return ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.getDay()];
            return d.toLocaleDateString([], {month:'short', day:'numeric'});
        } catch(e) { return ''; }
    }

    function fmtAgo(s) {
        if (!s) return 'recently';
        try {
            var d = new Date(s.replace(' ', 'T'));
            var diff = Math.floor((new Date() - d) / 1000);
            if (diff < 60) return 'just now';
            if (diff < 3600) return Math.floor(diff / 60) + ' min ago';
            if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
            return Math.floor(diff / 86400) + 'd ago';
        } catch(e) { return 'recently'; }
    }

    function fmtMsgTime(s) {
        if (!s) return '';
        try { return new Date(s.replace(' ', 'T')).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); }
        catch(e) { return ''; }
    }

    function fmtDateSep(s) {
        if (!s) return '';
        try {
            var d = new Date(s.replace(' ', 'T'));
            var now = new Date();
            var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            var msgDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
            var diff = Math.floor((today - msgDay) / 86400000);
            if (diff === 0) return 'Today';
            if (diff === 1) return 'Yesterday';
            if (diff < 7) return d.toLocaleDateString([], {weekday:'long'});
            return d.toLocaleDateString([], {month:'long', day:'numeric', year:'numeric'});
        } catch(e) { return ''; }
    }

    function toast(msg, type) {
        var c = document.querySelector('.toast-box');
        if (!c) { c = document.createElement('div'); c.className = 'toast-box'; document.body.appendChild(c); }
        var el = document.createElement('div');
        el.className = 'toast ' + (type === 'error' ? 'e' : 's');
        el.innerHTML = '<span>' + esc(msg) + '</span><button onclick="this.parentElement.remove()">&times;</button>';
        c.appendChild(el);
        setTimeout(function() { if (el.parentNode) el.remove(); }, 5000);
    }

    function scrollToBottom() {
        if (msgs) requestAnimationFrame(function() { msgs.scrollTop = msgs.scrollHeight; });
    }

    function autoResize(el) {
        el.style.height = 'auto';
        el.style.height = Math.min(el.scrollHeight, 120) + 'px';
    }

    // ============ CONVERSATIONS ============
    function loadConvs() {
        fetch(BASE + '/api/get-conversations.php')
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (!d.success) { console.error('Conv failed:', d.message); return; }
            allConvs = d.conversations || [];
            var total = d.total_unread || 0;
            document.title = total > 0 ? '(' + total + ') Messages | VivahaBandhan' : 'Messages | VivahaBandhan';
            renderConvs(allConvs);
        })
        .catch(function(e) { console.error('Conv error:', e); });
    }

    function renderConvs(convs) {
        if (!convs.length) {
            convList.innerHTML = '<div class="conv-empty"><div class="e-ico">&#128172;</div><h3>No conversations yet</h3><p>Send an interest to start chatting!</p><a href="' + BASE + '/search.php" class="btn-cta">Browse Profiles</a></div>';
            return;
        }
        var h = '';
        convs.forEach(function(c) {
            var act = chatWith == c.other_user_id ? ' active' : '';
            var on = c.is_online == 1;
            var ph = photo(c.photo_primary, c.gender);
            var nm = esc(c.first_name + ' ' + c.last_name);
            var pv = esc((c.last_message || '').substring(0, 40));
            var tm = c.last_message_time ? fmtTime(c.last_message_time) : '';
            var ub = parseInt(c.unread_count) || 0;

            h += '<div class="ci' + act + '" data-uid="' + c.other_user_id + '" onclick="window._openChat(' + c.other_user_id + ', this)">';
            h += '<div class="ci-av"><img src="' + ph + '" alt="">' + (on ? '<div class="dot-online"></div>' : '') + '</div>';
            h += '<div class="ci-info"><div class="ci-name"><span>' + nm + '</span><span class="ci-time">' + tm + '</span></div>';
            h += '<div class="ci-preview"><span class="ci-preview-txt">' + (pv || 'Start chatting...') + '</span>';
            if (ub > 0) h += '<span class="ci-badge">' + ub + '</span>';
            h += '</div></div></div>';
        });
        convList.innerHTML = h;
    }

    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var q = this.value.toLowerCase().trim();
            if (!q) { renderConvs(allConvs); return; }
            renderConvs(allConvs.filter(function(c) {
                return (c.first_name + ' ' + c.last_name).toLowerCase().indexOf(q) !== -1;
            }));
        });
    }

    // ============ OPEN CHAT ============
    window._openChat = function(uid, el) {
        chatWith = uid;
        lastId = 0;

        document.querySelectorAll('.ci').forEach(function(i) { i.classList.remove('active'); });
        if (el) el.classList.add('active');

        if (el) {
            var img = el.querySelector('img');
            var nmEl = el.querySelector('.ci-name span');
            var isOn = el.querySelector('.dot-online') !== null;
            if (chatAvatar && img) chatAvatar.src = img.src;
            if (chatName && nmEl) chatName.textContent = nmEl.textContent;
            if (chatStatus) {
                chatStatus.textContent = isOn ? 'Online' : 'Offline';
                chatStatus.className = 'ch-status' + (isOn ? ' on' : '');
            }
        }

        // Show chat UI
        if (chatHeader) chatHeader.style.display = 'flex';
        var chatInput = document.getElementById('chatInput');
        if (chatInput) chatInput.classList.remove('hidden');

        // Clear old messages
        if (msgs) msgs.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-light)">Loading...</div>';

        // Update URL
        history.replaceState(null, '', BASE + '/messages.php?user=' + uid);

        // Load messages and start polling
        fetchMsgs(true);
        startPoll();

        // Focus input
        if (msgText) {
            msgText.value = '';
            setTimeout(function() { msgText.focus(); }, 200);
        }

        // Mobile
        if (window.innerWidth <= 768 && sidebar) sidebar.classList.add('hide-m');
    };

    // ============ FETCH MESSAGES ============
    function fetchMsgs(init) {
        if (!chatWith) return;
        var url = BASE + '/api/get-messages.php?chat_with=' + chatWith;
        if (!init && lastId > 0) url += '&after_id=' + lastId;

        fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (!d.success) { console.error('Msg fetch failed:', d.message); return; }

            var ms = d.messages || [];

            // Update partner status
            if (chatStatus) {
                if (d.partner_online) {
                    chatStatus.textContent = 'Online';
                    chatStatus.className = 'ch-status on';
                } else if (d.partner_seen) {
                    chatStatus.textContent = 'Last seen ' + fmtAgo(d.partner_seen);
                    chatStatus.className = 'ch-status';
                }
            }

            // Typing
            if (typingBox) typingBox.classList.toggle('show', d.is_typing === true);

            if (init) renderAll(ms);
            else if (ms.length) appendNew(ms);

            if (d.total_unread !== undefined) {
                document.title = d.total_unread > 0 ? '(' + d.total_unread + ') Messages | VivahaBandhan' : 'Messages | VivahaBandhan';
            }
        })
        .catch(function(e) { console.error('Msg fetch error:', e); });
    }

    function renderAll(ms) {
        if (!msgs) return;
        if (!ms.length) {
            msgs.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-light)"><div style="font-size:2rem;margin-bottom:12px;opacity:0.3">&#128172;</div>No messages yet. Say hello!</div>';
            return;
        }
        var h = '', ld = '';
        ms.forEach(function(m) {
            var md = fmtDateSep(m.created_at);
            if (md !== ld) { h += '<div class="date-sep"><span>' + md + '</span></div>'; ld = md; }
            h += buildMsg(m);
        });
        msgs.innerHTML = h;
        lastId = ms.length ? parseInt(ms[ms.length - 1].id) : 0;
        scrollToBottom();
    }

    function appendNew(ms) {
        if (!msgs || !ms.length) return;
        ms.forEach(function(m) {
            if (parseInt(m.id) <= lastId) return;
            var md = fmtDateSep(m.created_at);
            var lastSep = msgs.querySelector('.date-sep:last-of-type');
            if (!lastSep || lastSep.textContent.trim() !== md) {
                msgs.insertAdjacentHTML('beforeend', '<div class="date-sep"><span>' + md + '</span></div>');
            }
            msgs.insertAdjacentHTML('beforeend', buildMsg(m));
            lastId = parseInt(m.id);
        });
        scrollToBottom();
    }

    function buildMsg(m) {
        var isSent = parseInt(m.sender_id) === ME;
        var dir = isSent ? 'sent' : 'recv';
        var time = fmtMsgTime(m.created_at);
        var chk = isSent ? '<span class="m-check' + (m.is_read == 1 ? ' read' : '') + '">&#10003;&#10003;</span>' : '';
        return '<div class="m-row ' + dir + '"><div><div class="m-bubble">' + esc(m.message) + '</div><div class="m-time">' + time + ' ' + chk + '</div></div></div>';
    }

    function fmtMsgTime(s) {
        if (!s) return '';
        try { return new Date(s.replace(' ', 'T')).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); } catch(e) { return ''; }
    }

    function fmtDateSep(s) {
        if (!s) return '';
        try {
            var d = new Date(s.replace(' ', 'T'));
            var now = new Date();
            var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            var msgDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
            var diff = Math.floor((today - msgDay) / 86400000);
            if (diff === 0) return 'Today';
            if (diff === 1) return 'Yesterday';
            if (diff < 7) return d.toLocaleDateString([], {weekday:'long'});
            return d.toLocaleDateString([], {month:'long', day:'numeric', year:'numeric'});
        } catch(e) { return ''; }
    }

    // ============ SEND MESSAGE ============
    function sendMsg() {
        // Prevent double-send
        if (sendInProgress) return;
        if (!msgText) return;
        if (!chatWith) {
            toast('No chat selected. Please open a conversation first.', 'error');
            return;
        }

        var txt = msgText.value.trim();
        if (!txt) return;

        sendInProgress = true;
        msgText.value = '';
        autoResize(msgText);
        if (sendBtn) sendBtn.disabled = true;

        // Add optimistic message to UI
        var tid = 't_' + Date.now();
        if (msgs) {
            var ph = msgs.querySelector('[style*="text-align:center"]');
            if (ph) ph.remove();
            msgs.insertAdjacentHTML('beforeend',
                '<div class="m-row sent" id="' + tid + '">' +
                '<div>' +
                '<div class="m-bubble">' + esc(txt) + '</div>' +
                '<div class="m-time">' + fmtMsgTime(new Date().toISOString()) + ' <span class="m-check">&#10003;</span></div>' +
                '</div></div>'
            );
            scrollToBottom();
        }

        // Build form data
        var fd = new FormData();
        fd.append('receiver_id', String(chatWith));
        fd.append('message', txt);

        // Send to server
        fetch(BASE + '/api/send-message.php', {
            method: 'POST',
            body: fd
        })
        .then(function(r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function(d) {
            if (d.success) {
                // Confirm the optimistic message
                var el = document.getElementById(tid);
                if (el) el.removeAttribute('id');
                lastId = Math.max(lastId, parseInt(d.message_id || 0));
                sendTyping(0);
            } else {
                toast(d.message || 'Failed to send message.', 'error');
                // Mark the optimistic message as failed
                var el = document.getElementById(tid);
                if (el) {
                    el.querySelector('.m-bubble').style.opacity = '0.5';
                    el.querySelector('.m-bubble').style.border = '2px dashed #C62828';
                }
            }
        })
        .catch(function(e) {
            console.error('Send error:', e);
            toast('Network error. Could not send message.', 'error');
            var el = document.getElementById(tid);
            if (el) {
                el.querySelector('.m-bubble').style.opacity = '0.5';
                el.querySelector('.m-bubble').style.border = '2px dashed #C62828';
            }
        })
        .finally(function() {
            sendInProgress = false;
            if (sendBtn) sendBtn.disabled = false;
            if (msgText) msgText.focus();
        });
    }

    // Bind send button
    if (sendBtn) {
        sendBtn.addEventListener('click', function(e) {
            e.preventDefault();
            sendMsg();
        });
    }

    // Bind textarea
    if (msgText) {
        // Enter to send, Shift+Enter for new line
        msgText.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMsg();
            }
        });

        // Auto-resize and typing indicator
        msgText.addEventListener('input', function() {
            autoResize(this);
            if (!amTyping) { amTyping = true; sendTyping(1); }
            clearTimeout(typeTimer);
            typeTimer = setTimeout(function() { amTyping = false; sendTyping(0); }, 2000);
        });
    }

    // ============ TYPING ============
    function sendTyping(v) {
        if (!chatWith) return;
        var fd = new FormData();
        fd.append('chat_with', chatWith);
        fd.append('is_typing', v);
        fetch(BASE + '/api/typing.php', { method: 'POST', body: fd }).catch(function(){});
    }

    // ============ POLLING ============
    function startPoll() {
        stopPoll();
        poller = setInterval(function() {
            if (chatWith) fetchMsgs(false);
        }, 2000);
    }
    function stopPoll() {
        if (poller) { clearInterval(poller); poller = null; }
    }

    // ============ HEARTBEAT ============
    function heartbeat() {
        fetch(BASE + '/api/heartbeat.php')
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                var badge = document.getElementById('navMsgBadge');
                if (badge) {
                    if (d.unread > 0) { badge.textContent = d.unread; badge.style.display = ''; }
                    else badge.style.display = 'none';
                }
            }
        }).catch(function(){});
    }
    setInterval(heartbeat, 15000);
    heartbeat();

    // ============ CONVERSATIONS POLL ============
    convPoller = setInterval(loadConvs, 10000);

    // ============ BACK BUTTON ============
    if (backBtn) {
        backBtn.addEventListener('click', function() {
            chatWith = null;
            stopPoll();
            if (sidebar) sidebar.classList.remove('hide-m');
            if (chatHeader) chatHeader.style.display = 'none';
            if (msgs) msgs.innerHTML = '';
            var ci = document.getElementById('chatInput');
            if (ci) ci.classList.add('hidden');
            history.replaceState(null, '', BASE + '/messages.php');
        });
    }

    // ============ INIT ============
    loadConvs();
    if (chatWith) startPoll();

    window.addEventListener('beforeunload', function() {
        if (navigator.sendBeacon) navigator.sendBeacon(BASE + '/api/heartbeat.php');
    });

    // Debug: log init state
    console.log('[Chat] Initialized. chatWith:', chatWith, 'ME:', ME, 'BASE:', BASE);

})();
</script>

</body>
</html>
