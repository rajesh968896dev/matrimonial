<?php
// File: index.php — HOME PAGE
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$auth = new Auth();
$auth->tryRememberMe();

$db = Database::getInstance();
$featuredProfiles = [];
try {
    $stmt = $db->prepare(
        "SELECT p.*, u.email FROM profiles p JOIN users u ON u.id = p.user_id
         WHERE u.status = 'active' AND u.role = 'user'
         ORDER BY p.last_active DESC LIMIT 8"
    );
    $stmt->execute();
    $featuredProfiles = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Featured profiles error: " . $e->getMessage());
}

$totalMembers = 0;
try {
    $totalMembers = $db->query("SELECT COUNT(*) FROM users WHERE status = 'active' AND role = 'user'")->fetchColumn();
} catch (Exception $e) {}

include __DIR__ . '/includes/header.php';
?>

<!-- HERO SECTION -->
<section class="hero">
    <div class="hero-content">
        <div class="hero-text">
            <h1>Find Your Perfect <span class="gold-text">Life Partner</span></h1>
            <p>Join millions of happy families who found their soulmate through VivahaBandhan. Trusted, verified, and meaningful connections that last a lifetime.</p>
            <div class="hero-actions">
                <?php if (!isLoggedIn()): ?>
                    <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-gold btn-lg">Start Your Journey</a>
                    <a href="<?php echo BASE_URL; ?>/search.php" class="btn btn-secondary btn-lg" style="color:white;border-color:rgba(255,255,255,0.3);">Browse Profiles</a>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>/matches.php" class="btn btn-gold btn-lg">View Matches</a>
                    <a href="<?php echo BASE_URL; ?>/search.php" class="btn btn-secondary btn-lg" style="color:white;border-color:rgba(255,255,255,0.3);">Search Profiles</a>
                <?php endif; ?>
            </div>
            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="stat-number"><?php echo number_format($totalMembers); ?>+</div>
                    <div class="stat-label">Active Members</div>
                </div>
                <div class="hero-stat">
                    <div class="stat-number">50K+</div>
                    <div class="stat-label">Success Stories</div>
                </div>
                <div class="hero-stat">
                    <div class="stat-number">100+</div>
                    <div class="stat-label">Communities</div>
                </div>
            </div>
        </div>
        <div class="hero-visual">
            <div class="hero-card-stack">
                <div class="floating-card">
                    <div class="fc-avatar"></div>
                    <div>
                        <div class="fc-name">Priya S.</div>
                        <div class="fc-detail">25 yrs, Mumbai</div>
                        <div class="fc-match">92% Match</div>
                    </div>
                </div>
                <div class="floating-card">
                    <div class="fc-avatar"></div>
                    <div>
                        <div class="fc-name">Arjun K.</div>
                        <div class="fc-detail">28 yrs, Delhi</div>
                        <div class="fc-match">88% Match</div>
                    </div>
                </div>
                <div class="floating-card">
                    <div class="fc-avatar"></div>
                    <div>
                        <div class="fc-name">Sneha R.</div>
                        <div class="fc-detail">24 yrs, Bangalore</div>
                        <div class="fc-match">85% Match</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- HOW IT WORKS -->
<section class="section" id="how-it-works">
    <div class="container">
        <div class="section-header">
            <div class="ornament">
                <div class="line"></div>
                <div class="diamond"></div>
                <div class="line"></div>
            </div>
            <h2>Your Journey to Forever</h2>
            <p>Four simple steps to find your perfect match</p>
        </div>
        <div class="steps-grid">
            <div class="step-card">
                <div class="step-number">1</div>
                <h3>Create Profile</h3>
                <p>Register and build your detailed profile with photos and partner preferences.</p>
            </div>
            <div class="step-card">
                <div class="step-number">2</div>
                <h3>Discover Matches</h3>
                <p>Browse verified profiles and get personalized match recommendations daily.</p>
            </div>
            <div class="step-card">
                <div class="step-number">3</div>
                <h3>Express Interest</h3>
                <p>Send interests to profiles you like and shortlist your favorites.</p>
            </div>
            <div class="step-card">
                <div class="step-number">4</div>
                <h3>Connect & Meet</h3>
                <p>Chat with mutual matches and take the next step towards a beautiful future.</p>
            </div>
        </div>
    </div>
</section>

<!-- FEATURED PROFILES -->
<?php if (!empty($featuredProfiles)): ?>
<section class="section bg-tertiary">
    <div class="container">
        <div class="section-header">
            <div class="ornament">
                <div class="line"></div>
                <div class="diamond"></div>
                <div class="line"></div>
            </div>
            <h2>Recently Active Members</h2>
            <p>Discover verified profiles who are actively looking for their partner</p>
        </div>
        <div class="profiles-grid">
            <?php foreach ($featuredProfiles as $profile): ?>
            <div class="card profile-card">
                <div class="profile-photo-wrapper">
                    <img src="<?php echo getProfilePhoto($profile['photo_primary'], $profile['gender']); ?>"
                         alt="<?php echo sanitize($profile['first_name']); ?>" loading="lazy">
                    <?php if ($profile['profile_verified']): ?>
                        <span class="premium-badge">Verified</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="profile-name"><?php echo sanitize($profile['first_name'] . ' ' . $profile['last_name']); ?></div>
                    <div class="profile-detail">
                        <?php echo calculateAge($profile['date_of_birth']); ?> yrs
                        <span class="dot"></span>
                        <?php echo sanitize($profile['city'] ?? $profile['state'] ?? $profile['country']); ?>
                    </div>
                    <div class="profile-detail">
                        <?php echo sanitize($profile['education'] ?? 'N/A'); ?>
                        <span class="dot"></span>
                        <?php echo sanitize($profile['occupation'] ?? 'N/A'); ?>
                    </div>
                    <div class="profile-detail"><?php echo sanitize($profile['religion'] ?? ''); ?></div>
                    <div class="profile-actions">
    <?php if (isLoggedIn()): ?>
        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profile['user_id']; ?>" class="btn btn-secondary btn-sm">View</a>
        <button class="btn btn-primary btn-sm" data-action="interest" data-user-id="<?php echo $profile['user_id']; ?>">Send Interest</button>
    <?php else: ?>
        <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-primary btn-sm btn-block">Login to View</a>
    <?php endif; ?>
</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if (!isLoggedIn()): ?>
            <div style="text-align:center;margin-top:32px;">
                <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-primary btn-lg">Register Free to View More</a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<!-- TRUST SECTION -->
<section class="section bg-dark">
    <div class="container">
        <div class="section-header">
            <h2>Why Families Trust Us</h2>
        </div>
        <div class="steps-grid">
            <div class="step-card">
                <div class="step-number" style="border-color:var(--gold);color:var(--gold);background:rgba(212,168,67,0.1);">&#10003;</div>
                <h3 style="color:var(--text-on-dark)">100% Verified</h3>
                <p style="color:rgba(253,248,244,0.6);">Every profile is manually verified with phone and ID proof for your safety.</p>
            </div>
            <div class="step-card">
                <div class="step-number" style="border-color:var(--gold);color:var(--gold);background:rgba(212,168,67,0.1);">&#128274;</div>
                <h3 style="color:var(--text-on-dark)">Privacy First</h3>
                <p style="color:rgba(253,248,244,0.6);">Your contact details are never shared without your explicit permission.</p>
            </div>
            <div class="step-card">
                <div class="step-number" style="border-color:var(--gold);color:var(--gold);background:rgba(212,168,67,0.1);">&#9825;</div>
                <h3 style="color:var(--text-on-dark)">Smart Matching</h3>
                <p style="color:rgba(253,248,244,0.6);">AI-powered compatibility matching based on your preferences and behavior.</p>
            </div>
            <div class="step-card">
                <div class="step-number" style="border-color:var(--gold);color:var(--gold);background:rgba(212,168,67,0.1);">&#9742;</div>
                <h3 style="color:var(--text-on-dark)">Dedicated Support</h3>
                <p style="color:rgba(253,248,244,0.6);">Relationship managers available 24/7 to assist you at every step.</p>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
