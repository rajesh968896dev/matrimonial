<?php
// File: includes/header.php
if (!defined('APP_RUNNING')) { die('Direct access not permitted'); }
if (session_status() === PHP_SESSION_NONE) session_start();

$pageTitle = $pageTitle ?? 'VivahaBandhan';
$currentUser = null;
if (isLoggedIn()) {
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT p.*, u.email, u.role FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $currentUser = $stmt->fetch();

    // Update last active periodically
    if (isset($_SESSION['last_active_update']) && time() - $_SESSION['last_active_update'] > 300) {
        $stmt = $db->prepare("UPDATE profiles SET last_active = NOW() WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $_SESSION['last_active_update'] = time();
    } elseif (!isset($_SESSION['last_active_update'])) {
        $stmt = $db->prepare("UPDATE profiles SET last_active = NOW() WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $_SESSION['last_active_update'] = time();
    }
}

// Count unread messages and pending interests
$unreadMessages = 0;
$pendingInterests = 0;
if (isLoggedIn()) {
    $db = Database::getInstance();
// AFTER (fixed):
$unreadMessages = safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0", [$_SESSION['user_id']]);
$pendingInterests = safeFetchColumn($db, "SELECT COUNT(*) FROM interests WHERE receiver_id = ? AND status = 'pending'", [$_SESSION['user_id']]);

}

$flashes = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="VivahaBandhan - Premium Matrimonial Matchmaking Platform">
    <meta name="theme-color" content="#8B1A2B">
	<meta name="csrf-token" content="<?php echo htmlspecialchars(generateCsrfToken()); ?>">
    <title><?php echo sanitize($pageTitle); ?> | VivahaBandhan</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <nav class="main-nav" id="mainNav">
        <div class="nav-container">
            <a href="<?php echo BASE_URL; ?>/index.php" class="nav-brand">
                <span class="brand-icon">&#9825;</span>
                <span class="brand-text">Vivaha<span class="brand-accent">Bandhan</span></span>
            </a>

            <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>

            <div class="nav-menu" id="navMenu">
                <?php if (isLoggedIn()): ?>
                    <a href="<?php echo BASE_URL; ?>/matches.php" class="nav-link">Matches</a>
                    <a href="<?php echo BASE_URL; ?>/search.php" class="nav-link">Search</a>
                    <a href="<?php echo BASE_URL; ?>/interests.php" class="nav-link">
                        Interests
                        <?php if ($pendingInterests > 0): ?>
                            <span class="badge"><?php echo $pendingInterests; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="<?php echo BASE_URL; ?>/messages.php" class="nav-link" id="navMessagesLink">
    Messages
    <span class="badge" id="navMsgBadge" style="<?php echo $unreadMessages > 0 ? '' : 'display:none'; ?>"><?php echo $unreadMessages; ?></span>
                    </a>
                    <div class="nav-dropdown">
                        <button class="nav-link nav-dropdown-trigger">
                            <?php echo sanitize($currentUser['first_name'] ?? 'Account'); ?>
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor"><path d="M6 8L1 3h10z"/></svg>
                        </button>
                        <div class="nav-dropdown-menu">
                            <a href="<?php echo BASE_URL; ?>/profile.php">My Profile</a>
                            <a href="<?php echo BASE_URL; ?>/edit-profile.php">Edit Profile</a>
                            <a href="<?php echo BASE_URL; ?>/shortlists.php">Shortlisted</a>
                            <a href="<?php echo BASE_URL; ?>/settings.php">Settings</a>
                            <?php if (($_SESSION['user_role'] ?? '') === 'admin'): ?>
                                <hr>
                                <a href="<?php echo BASE_URL; ?>/admin/">Admin Panel</a>
                            <?php endif; ?>
                            <hr>
                            <a href="<?php echo BASE_URL; ?>/logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>/search.php" class="nav-link">Search</a>
                    <a href="<?php echo BASE_URL; ?>/login.php" class="nav-link">Login</a>
                    <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-primary btn-sm nav-cta">Register Free</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <?php if (!empty($flashes)): ?>
    <div class="flash-container">
        <?php foreach ($flashes as $flash): ?>
            <div class="flash flash-<?php echo sanitize($flash['type']); ?>">
                <span><?php echo sanitize($flash['message']); ?></span>
                <button class="flash-close" onclick="this.parentElement.remove()">&times;</button>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <main class="main-content">
