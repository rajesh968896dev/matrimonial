<?php
// File: interests.php — FIXED VERSION

define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];

// Get received interests
$receivedInterests = safeFetch($db, "
    SELECT i.id as interest_id, i.status, i.message, i.created_at,
           p.user_id, p.first_name, p.last_name, p.gender, p.date_of_birth,
           p.city, p.state, p.education, p.occupation, p.photo_primary, p.religion
    FROM interests i
    JOIN profiles p ON p.user_id = i.sender_id
    WHERE i.receiver_id = ?
    ORDER BY i.created_at DESC
", [$userId]);

// Get sent interests
$sentInterests = safeFetch($db, "
    SELECT i.id as interest_id, i.status, i.message, i.created_at,
           p.user_id, p.first_name, p.last_name, p.gender, p.date_of_birth,
           p.city, p.state, p.education, p.occupation, p.photo_primary, p.religion
    FROM interests i
    JOIN profiles p ON p.user_id = i.receiver_id
    WHERE i.sender_id = ?
    ORDER BY i.created_at DESC
", [$userId]);

// Get mutual matches (accepted interests)
$mutualMatches = safeFetch($db, "
    SELECT i.id as interest_id, i.status, i.updated_at,
           p.user_id, p.first_name, p.last_name, p.gender, p.date_of_birth,
           p.city, p.state, p.education, p.occupation, p.photo_primary, p.religion
    FROM interests i
    JOIN profiles p ON p.user_id = CASE
        WHEN i.sender_id = ? THEN i.receiver_id
        ELSE i.sender_id
    END
    WHERE (i.sender_id = ? OR i.receiver_id = ?)
      AND i.status = 'accepted'
    ORDER BY i.updated_at DESC
", [$userId, $userId, $userId]);

$pageTitle = 'Interests & Matches';
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;max-width:900px;">
    <h1 style="margin-bottom:24px;">Interests &amp; Matches</h1>

    <div class="interests-tabs">
        <button class="interests-tab active" data-tab="received">
            Received (<?php echo count($receivedInterests); ?>)
        </button>
        <button class="interests-tab" data-tab="sent">
            Sent (<?php echo count($sentInterests); ?>)
        </button>
        <button class="interests-tab" data-tab="mutual">
            Mutual (<?php echo count($mutualMatches); ?>)
        </button>
    </div>

    <!-- ===== RECEIVED INTERESTS ===== -->
    <div id="received" class="tab-panel">
        <?php if (empty($receivedInterests)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128231;</div>
                <h3>No interests received yet</h3>
                <p>Complete your profile to attract more interests.</p>
                <a href="<?php echo BASE_URL; ?>/edit-profile.php" class="btn btn-primary">Complete Profile</a>
            </div>
        <?php else: ?>
            <?php foreach ($receivedInterests as $interest): ?>
                <?php $profileUserId = (int) $interest['user_id']; ?>
                <div class="interest-card">
                    <img src="<?php echo getProfilePhoto($interest['photo_primary'] ?? '', $interest['gender'] ?? 'male'); ?>"
                         alt="" class="interest-photo">
                    <div class="interest-info">
                        <strong style="font-size:1.05rem;">
                            <?php echo sanitize($interest['first_name'] . ' ' . $interest['last_name']); ?>
                        </strong>
                        <div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
                            <?php echo calculateAge($interest['date_of_birth']); ?> yrs,
                            <?php echo sanitize($interest['city'] ?? ''); ?>,
                            <?php echo sanitize($interest['education'] ?? ''); ?>
                        </div>
                        <?php if (!empty($interest['message'])): ?>
                            <div style="font-size:0.85rem;color:var(--text-secondary);margin-top:4px;font-style:italic;">
                                &ldquo;<?php echo sanitize($interest['message']); ?>&rdquo;
                            </div>
                        <?php endif; ?>
                        <div style="font-size:0.75rem;color:var(--text-light);margin-top:4px;">
                            <?php echo timeAgo($interest['created_at']); ?>
                        </div>
                    </div>
                    <div class="interest-actions">
                        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profileUserId; ?>"
                           class="btn btn-ghost btn-sm">View</a>
                        <?php if ($interest['status'] === 'pending'): ?>
                            <button class="btn btn-primary btn-sm"
                                    data-action="accept-interest"
                                    data-user-id="<?php echo $profileUserId; ?>">Accept</button>
                            <button class="btn btn-ghost btn-sm"
                                    data-action="decline-interest"
                                    data-user-id="<?php echo $profileUserId; ?>">Decline</button>
                        <?php elseif ($interest['status'] === 'accepted'): ?>
                            <a href="<?php echo BASE_URL; ?>/messages.php?user=<?php echo $profileUserId; ?>"
                               class="btn btn-primary btn-sm">Message</a>
                            <span class="status-badge status-active">Accepted</span>
                        <?php else: ?>
                            <span class="status-badge status-inactive">Declined</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- ===== SENT INTERESTS ===== -->
    <div id="sent" class="tab-panel" style="display:none;">
        <?php if (empty($sentInterests)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128228;</div>
                <h3>No interests sent yet</h3>
                <p>Browse matches and send interests to profiles you like.</p>
                <a href="<?php echo BASE_URL; ?>/matches.php" class="btn btn-primary">View Matches</a>
            </div>
        <?php else: ?>
            <?php foreach ($sentInterests as $interest): ?>
                <?php $profileUserId = (int) $interest['user_id']; ?>
                <div class="interest-card">
                    <img src="<?php echo getProfilePhoto($interest['photo_primary'] ?? '', $interest['gender'] ?? 'male'); ?>"
                         alt="" class="interest-photo">
                    <div class="interest-info">
                        <strong style="font-size:1.05rem;">
                            <?php echo sanitize($interest['first_name'] . ' ' . $interest['last_name']); ?>
                        </strong>
                        <div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
                            <?php echo calculateAge($interest['date_of_birth']); ?> yrs,
                            <?php echo sanitize($interest['city'] ?? ''); ?>,
                            <?php echo sanitize($interest['education'] ?? ''); ?>
                        </div>
                        <div style="font-size:0.75rem;color:var(--text-light);margin-top:4px;">
                            <?php echo timeAgo($interest['created_at']); ?>
                        </div>
                    </div>
                    <div class="interest-actions">
                        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profileUserId; ?>"
                           class="btn btn-ghost btn-sm">View</a>
                        <?php if ($interest['status'] === 'pending'): ?>
                            <span class="status-badge status-pending">Pending</span>
                        <?php elseif ($interest['status'] === 'accepted'): ?>
                            <span class="status-badge status-active">Accepted</span>
                        <?php else: ?>
                            <span class="status-badge status-inactive">Declined</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- ===== MUTUAL MATCHES ===== -->
    <div id="mutual" class="tab-panel" style="display:none;">
        <?php if (empty($mutualMatches)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128144;</div>
                <h3>No mutual matches yet</h3>
                <p>When both of you accept each other's interest, you'll appear here.</p>
            </div>
        <?php else: ?>
            <?php foreach ($mutualMatches as $match): ?>
                <?php $profileUserId = (int) $match['user_id']; ?>
                <div class="interest-card" style="border-color:var(--gold);">
                    <img src="<?php echo getProfilePhoto($match['photo_primary'] ?? '', $match['gender'] ?? 'male'); ?>"
                         alt="" class="interest-photo">
                    <div class="interest-info">
                        <strong style="font-size:1.05rem;">
                            <?php echo sanitize($match['first_name'] . ' ' . $match['last_name']); ?>
                        </strong>
                        <span style="background:linear-gradient(135deg,var(--gold),var(--gold-light));color:var(--bg-dark);padding:2px 8px;border-radius:var(--radius-full);font-size:0.7rem;font-weight:700;margin-left:8px;">
                            MUTUAL MATCH
                        </span>
                        <div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">
                            <?php echo calculateAge($match['date_of_birth']); ?> yrs,
                            <?php echo sanitize($match['city'] ?? ''); ?>,
                            <?php echo sanitize($match['education'] ?? ''); ?>
                        </div>
                    </div>
                    <div class="interest-actions">
                        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profileUserId; ?>"
                           class="btn btn-ghost btn-sm">View</a>
                        <a href="<?php echo BASE_URL; ?>/messages.php?user=<?php echo $profileUserId; ?>"
                           class="btn btn-primary btn-sm">Message</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>