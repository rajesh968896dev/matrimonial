<?php
// File: api/interest-action.php
// COMPLETE FIXED VERSION

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// ============================================================
// AUTH CHECK
// ============================================================
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login first.']);
    exit;
}

// ============================================================
// CSRF CHECK
// ============================================================
$csrfToken = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$sessionToken = $_SESSION['csrf_token'] ?? '';

if (empty($csrfToken) || empty($sessionToken)) {
    echo json_encode([
        'success' => false,
        'message' => 'Security token missing. Please refresh the page and try again.'
    ]);
    exit;
}

if (!hash_equals($sessionToken, $csrfToken)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid security token. Please refresh the page and try again.'
    ]);
    exit;
}

// ============================================================
// GET PARAMETERS
// ============================================================
$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$action = trim($_POST['action'] ?? '');
$targetUserId = intval($_POST['user_id'] ?? 0);

// Validate
if (!$targetUserId || $targetUserId === $userId) {
    echo json_encode(['success' => false, 'message' => 'Invalid user.']);
    exit;
}

if (empty($action)) {
    echo json_encode(['success' => false, 'message' => 'No action specified.']);
    exit;
}

// Verify target user exists
$stmt = $db->prepare("SELECT id, first_name FROM profiles WHERE user_id = ?");
$stmt->execute([$targetUserId]);
$targetProfile = $stmt->fetch();

if (!$targetProfile) {
    echo json_encode(['success' => false, 'message' => 'Profile not found.']);
    exit;
}

// ============================================================
// PROCESS ACTION
// ============================================================
try {
    switch ($action) {

        // ---- SEND INTEREST ----
        case 'interest':
        case 'send-interest':
            // Check if already sent
            $stmt = $db->prepare("SELECT id, status FROM interests WHERE sender_id = ? AND receiver_id = ?");
            $stmt->execute([$userId, $targetUserId]);
            $existing = $stmt->fetch();

            if ($existing) {
                if ($existing['status'] === 'pending') {
                    echo json_encode(['success' => false, 'message' => 'You have already sent an interest to this profile.']);
                } elseif ($existing['status'] === 'accepted') {
                    echo json_encode(['success' => false, 'message' => 'Interest already accepted! You can send them a message.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Interest was previously sent and declined.']);
                }
                exit;
            }

            // Check daily limit (50 per day)
            $stmt = $db->prepare("SELECT COUNT(*) FROM interests WHERE sender_id = ? AND DATE(created_at) = CURDATE()");
            $stmt->execute([$userId]);
            if ($stmt->fetchColumn() >= 50) {
                echo json_encode(['success' => false, 'message' => 'Daily interest limit reached (50/day). Try again tomorrow.']);
                exit;
            }

            // Insert interest
            $message = sanitize($_POST['message'] ?? '');
            $stmt = $db->prepare("INSERT INTO interests (sender_id, receiver_id, message, status) VALUES (?, ?, ?, 'pending')");
            $stmt->execute([$userId, $targetUserId, $message]);

            logActivity('send_interest', $userId, "To: $targetUserId ({$targetProfile['first_name']})");

            echo json_encode([
                'success'      => true,
                'message'      => 'Interest sent to ' . $targetProfile['first_name'] . '!',
                'button_text'  => '&#10003; Interest Sent'
            ]);
            break;

        // ---- ACCEPT INTEREST ----
        case 'accept-interest':
            $stmt = $db->prepare("UPDATE interests SET status = 'accepted' WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'");
            $stmt->execute([$targetUserId, $userId]);

            if ($stmt->rowCount() > 0) {
                logActivity('accept_interest', $userId, "From: $targetUserId");
                echo json_encode([
                    'success'     => true,
                    'message'     => 'Interest accepted! You can now message each other.',
                    'remove_card' => false,
                    'button_text' => '&#10003; Accepted'
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Interest not found or already processed.']);
            }
            break;

        // ---- DECLINE INTEREST ----
        case 'decline-interest':
            $stmt = $db->prepare("UPDATE interests SET status = 'declined' WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'");
            $stmt->execute([$targetUserId, $userId]);

            echo json_encode([
                'success'     => true,
                'message'     => 'Interest declined.',
                'remove_card' => true
            ]);
            break;

        // ---- SHORTLIST ----
        case 'shortlist':
            $stmt = $db->prepare("SELECT id FROM shortlists WHERE user_id = ? AND shortlisted_user_id = ?");
            $stmt->execute([$userId, $targetUserId]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => true, 'message' => 'Already in your shortlist.']);
                break;
            }

            $stmt = $db->prepare("INSERT INTO shortlists (user_id, shortlisted_user_id) VALUES (?, ?)");
            $stmt->execute([$userId, $targetUserId]);

            echo json_encode([
                'success'     => true,
                'message'     => $targetProfile['first_name'] . ' added to shortlist!',
                'button_text' => '&#9829;'
            ]);
            break;

        // ---- UNSHORTLIST ----
        case 'unshortlist':
            $stmt = $db->prepare("DELETE FROM shortlists WHERE user_id = ? AND shortlisted_user_id = ?");
            $stmt->execute([$userId, $targetUserId]);

            echo json_encode([
                'success'     => true,
                'message'     => 'Removed from shortlist.',
                'remove_card' => true
            ]);
            break;

        // ---- LIKE (same as shortlist) ----
        case 'like':
            $stmt = $db->prepare("SELECT id FROM shortlists WHERE user_id = ? AND shortlisted_user_id = ?");
            $stmt->execute([$userId, $targetUserId]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => true, 'message' => 'Already liked!']);
                break;
            }

            $stmt = $db->prepare("INSERT INTO shortlists (user_id, shortlisted_user_id) VALUES (?, ?)");
            $stmt->execute([$userId, $targetUserId]);

            echo json_encode([
                'success'     => true,
                'message'     => 'You liked ' . $targetProfile['first_name'] . "'s profile!",
                'button_text' => '&#9829; Liked'
            ]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Unknown action: ' . $action]);
    }

} catch (PDOException $e) {
    error_log("Interest action error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'A database error occurred. Please try again.']);
} catch (Exception $e) {
    error_log("Interest action error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}
