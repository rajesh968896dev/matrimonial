<?php
// File: api/get-conversations.php

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];

try {
    // Get all unique conversation partner IDs
    $partnerIds = safeFetch($db, "
        SELECT DISTINCT
            CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END as other_user_id
        FROM messages m
        WHERE m.sender_id = ? OR m.receiver_id = ?
    ", [$userId, $userId, $userId]);

    $conversations = [];

    foreach ($partnerIds as $row) {
        $partnerId = (int) $row['other_user_id'];

        // Get partner profile
        $partner = safeFetchOne($db, "SELECT user_id, first_name, last_name, photo_primary, gender, city, is_online, last_seen FROM profiles WHERE user_id = ?", [$partnerId]);
        if (!$partner) continue;

        // Get last message
        $lastMsg = safeFetchOne($db, "
            SELECT id, message, sender_id, created_at
            FROM messages
            WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
            ORDER BY id DESC LIMIT 1
        ", [$userId, $partnerId, $partnerId, $userId]);

        // Get unread count
        $unread = (int) safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE sender_id = ? AND receiver_id = ? AND is_read = 0", [$partnerId, $userId]);

        $conversations[] = [
            'other_user_id'    => $partnerId,
            'first_name'       => $partner['first_name'],
            'last_name'        => $partner['last_name'],
            'photo_primary'    => $partner['photo_primary'] ?? '',
            'gender'           => $partner['gender'] ?? 'male',
            'city'             => $partner['city'] ?? '',
            'is_online'        => (int) ($partner['is_online'] ?? 0),
            'last_seen'        => $partner['last_seen'] ?? '',
            'last_message'     => $lastMsg ? $lastMsg['message'] : '',
            'last_message_time' => $lastMsg ? $lastMsg['created_at'] : '',
            'unread_count'     => $unread
        ];
    }

    // Sort by most recent message
    usort($conversations, function($a, $b) {
        return strcmp($b['last_message_time'], $a['last_message_time']);
    });

    // Total unread for badge
    $totalUnread = (int) safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0", [$userId]);

    echo json_encode([
        'success'       => true,
        'conversations' => $conversations,
        'total_unread'  => $totalUnread
    ]);

} catch (PDOException $e) {
    error_log("get-conversations: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error loading conversations.']);
}
