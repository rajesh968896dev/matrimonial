<?php
// File: api/send-message.php — FINAL FIXED VERSION

// Start output buffering to prevent any stray output
ob_start();

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// Clear any output that happened before this point
ob_end_clean();

header('Content-Type: application/json; charset=utf-8');

// ---- Auth Check ----
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$db = Database::getInstance();
$senderId = (int) $_SESSION['user_id'];

// ---- Get Input ----
$receiverId = 0;
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receiverId = (int) ($_POST['receiver_id'] ?? 0);
    $message = trim($_POST['message'] ?? '');
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Allow GET for debugging
    $receiverId = (int) ($_GET['receiver_id'] ?? 0);
    $message = trim($_GET['message'] ?? '');
}

// ---- Validate ----
$errors = [];

if ($receiverId <= 0) {
    $errors[] = 'Missing receiver_id';
}

if (empty($message)) {
    $errors[] = 'Message is empty';
}

if ($receiverId === $senderId) {
    $errors[] = 'Cannot send to yourself';
}

if (mb_strlen($message) > 5000) {
    $errors[] = 'Message too long (max 5000 characters)';
}

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode('. ', $errors), 'debug' => [
        'sender' => $senderId,
        'receiver' => $receiverId,
        'msg_len' => mb_strlen($message),
        'method' => $_SERVER['REQUEST_METHOD'],
        'post_data' => $_POST
    ]]);
    exit;
}

// ---- Rate Limit ----
$count = (int) safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE sender_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)", [$senderId]);
if ($count > 50) {
    echo json_encode(['success' => false, 'message' => 'Rate limit exceeded. Please wait.']);
    exit;
}

// ---- Verify Receiver ----
$receiver = safeFetchOne($db, "SELECT user_id, first_name FROM profiles WHERE user_id = ?", [$receiverId]);
if (!$receiver) {
    echo json_encode(['success' => false, 'message' => 'Receiver not found (ID: ' . $receiverId . ')']);
    exit;
}

// ---- Insert Message ----
try {
    $stmt = $db->prepare("INSERT INTO messages (sender_id, receiver_id, message, message_type, is_read, created_at) VALUES (?, ?, ?, 'text', 0, NOW())");
    $stmt->execute([$senderId, $receiverId, sanitize($message)]);
    $stmt->closeCursor();

    $newId = $db->lastInsertId();

    echo json_encode([
        'success'    => true,
        'message_id' => (int) $newId,
        'time'       => date('g:i A'),
        'created_at' => date('Y-m-d H:i:s'),
        'sender'     => $senderId,
        'receiver'   => $receiverId
    ]);

} catch (PDOException $e) {
    error_log("SEND MESSAGE PDO ERROR: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred.',
        'debug'   => $e->getMessage()
    ]);
}
