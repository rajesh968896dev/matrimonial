<?php
// File: api/get-messages.php

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];
$chatWith = (int) ($_GET['chat_with'] ?? 0);
$afterId = (int) ($_GET['after_id'] ?? 0);
$limit = min((int) ($_GET['limit'] ?? 50), 100);

if (!$chatWith) {
    echo json_encode(['success' => false, 'message' => 'Missing chat_with']);
    exit;
}

try {
    // Get messages
    if ($afterId > 0) {
        $messages = safeFetch($db, "
            SELECT id, sender_id, receiver_id, message, is_read, created_at, message_type
            FROM messages
            WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) AND id > ?
            ORDER BY created_at ASC
            LIMIT ?
        ", [$userId, $chatWith, $chatWith, $userId, $afterId, $limit]);
    } else {
        $stmt = $db->prepare("
            SELECT id, sender_id, receiver_id, message, is_read, created_at, message_type
            FROM messages
            WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
            ORDER BY id DESC
            LIMIT ?
        ");
        $stmt->execute([$userId, $chatWith, $chatWith, $userId, $limit]);
        $messages = array_reverse($stmt->fetchAll());
        $stmt->closeCursor();
    }

    // Mark messages as read
    $markStmt = $db->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0");
    $markStmt->execute([$chatWith, $userId]);
    $markStmt->closeCursor();

    // Partner status
    $partnerOnline = false;
    $partnerLastSeen = '';
    $partner = safeFetchOne($db, "SELECT is_online, last_seen FROM profiles WHERE user_id = ?", [$chatWith]);
    if ($partner) {
        $partnerOnline = (int) ($partner['is_online'] ?? 0) === 1;
        $partnerLastSeen = $partner['last_seen'] ?? '';
    }

    // Typing status
    $isTyping = false;
    try {
        $typing = safeFetchOne($db, "SELECT is_typing, updated_at FROM typing_status WHERE user_id = ? AND chat_with = ?", [$chatWith, $userId]);
        if ($typing && (int) $typing['is_typing'] === 1 && strtotime($typing['updated_at']) > time() - 5) {
            $isTyping = true;
        }
    } catch (Exception $e) {}

    // Total unread
    $totalUnread = (int) safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0", [$userId]);

    echo json_encode([
        'success'        => true,
        'messages'       => $messages,
        'partner_online' => $partnerOnline,
        'partner_seen'   => $partnerLastSeen,
        'is_typing'      => $isTyping,
        'total_unread'   => $totalUnread,
        'count'          => count($messages)
    ]);

} catch (PDOException $e) {
    error_log("get-messages: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error loading messages.']);
}
