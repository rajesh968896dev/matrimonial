<?php
// File: api/heartbeat.php

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false]);
    exit;
}

$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];

try {
    $stmt = $db->prepare("UPDATE profiles SET is_online = 1, last_seen = NOW() WHERE user_id = ?");
    $stmt->execute([$userId]);
    $stmt->closeCursor();

    $stmt = $db->prepare("UPDATE profiles SET is_online = 0 WHERE is_online = 1 AND last_seen < DATE_SUB(NOW(), INTERVAL 2 MINUTE)");
    $stmt->execute();
    $stmt->closeCursor();

    $unread = (int) safeFetchColumn($db, "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0", [$userId]);

    echo json_encode(['success' => true, 'unread' => $unread]);

} catch (Exception $e) {
    echo json_encode(['success' => false]);
}
