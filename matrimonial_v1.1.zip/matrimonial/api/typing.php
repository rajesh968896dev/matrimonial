<?php
// File: api/typing.php

define('APP_RUNNING', true);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false]);
    exit;
}

$db = Database::getInstance();
$userId = (int) $_SESSION['user_id'];
$chatWith = (int) ($_POST['chat_with'] ?? $_GET['chat_with'] ?? 0);
$isTyping = (int) ($_POST['is_typing'] ?? 0);

if (!$chatWith) {
    echo json_encode(['success' => false]);
    exit;
}

try {
    $stmt = $db->prepare("
        INSERT INTO typing_status (user_id, chat_with, is_typing, updated_at)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE is_typing = VALUES(is_typing), updated_at = NOW()
    ");
    $stmt->execute([$userId, $chatWith, $isTyping]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    // Table might not exist, create it
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS typing_status (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            chat_with INT NOT NULL,
            is_typing TINYINT(1) NOT NULL DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_typing (user_id, chat_with)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $stmt = $db->prepare("
            INSERT INTO typing_status (user_id, chat_with, is_typing, updated_at)
            VALUES (?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE is_typing = VALUES(is_typing), updated_at = NOW()
        ");
        $stmt->execute([$userId, $chatWith, $isTyping]);
        echo json_encode(['success' => true]);
    } catch (Exception $e2) {
        echo json_encode(['success' => false]);
    }
}
