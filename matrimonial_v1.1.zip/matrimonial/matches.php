<?php
// File: matches.php
define('APP_RUNNING', true);
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$db = Database::getInstance();
$userId = $_SESSION['user_id'];

// Load current user profile
$stmt = $db->prepare("SELECT * FROM profiles WHERE user_id = ?");
$stmt->execute([$userId]);
$myProfile = $stmt->fetch();

// Build match query based on preferences
$where = ["u.status = 'active'", "u.role = 'user'", "p.user_id != ?"];
$params = [$userId];

// Match opposite gender
if ($myProfile) {
    $where[] = "p.gender = ?";
    $params[] = ($myProfile['gender'] === 'male') ? 'female' : 'male';

    // Age preference
    if ($myProfile['partner_age_min']) {
        $where[] = "p.date_of_birth <= ?";
        $params[] = date('Y-m-d', strtotime('-' . $myProfile['partner_age_min'] . ' years'));
    }
    if ($myProfile['partner_age_max']) {
        $where[] = "p.date_of_birth >= ?";
        $params[] = date('Y-m-d', strtotime('-' . $myProfile['partner_age_max'] . ' years'));
    }

    // Religion preference
    if ($myProfile['partner_religion']) {
        $where[] = "p.religion LIKE ?";
        $params[] = '%' . $myProfile['partner_religion'] . '%';
    }
}

$whereClause = implode(' AND ', $where);
$perPage = PROFILES_PER_PAGE;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$countSql = "SELECT COUNT(*) FROM profiles p JOIN users u ON u.id = p.user_id WHERE $whereClause";
$stmt = $db->prepare($countSql);
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $perPage);

$sql = "SELECT p.*, u.email FROM profiles p JOIN users u ON u.id = p.user_id WHERE $whereClause ORDER BY p.last_active DESC LIMIT $perPage OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$matches = $stmt->fetchAll();

$pageTitle = 'Your Matches';
include __DIR__ . '/includes/header.php';
?>

<div class="container" style="padding:32px 24px;">
    <div class="section-header" style="text-align:left;margin-bottom:32px;">
        <div class="ornament" style="justify-content:flex-start;">
            <div class="line"></div>
            <div class="diamond"></div>
            <div class="line"></div>
        </div>
        <h1>Your Matches</h1>
        <p style="margin:0;"><?php echo number_format($total); ?> profiles match your preferences</p>
    </div>

    <?php if (empty($matches)): ?>
        <div class="empty-state">
            <div class="empty-icon">&#9825;</div>
            <h3>No matches yet</h3>
            <p>Complete your profile and set partner preferences to get personalized matches.</p>
            <a href="<?php echo BASE_URL; ?>/edit-profile.php" class="btn btn-primary">Complete Profile</a>
        </div>
    <?php else: ?>
        <div class="profiles-grid">
            <?php foreach ($matches as $profile): ?>
            <div class="card profile-card">
                <div class="profile-photo-wrapper">
                    <img src="<?php echo getProfilePhoto($profile['photo_primary'], $profile['gender']); ?>" alt="<?php echo sanitize($profile['first_name']); ?>" loading="lazy">
                    <?php if ($profile['profile_verified']): ?>
                        <span class="premium-badge">Verified</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="profile-name"><?php echo sanitize($profile['first_name'] . ' ' . $profile['last_name']); ?></div>
                    <div class="profile-detail">
                        <?php echo calculateAge($profile['date_of_birth']); ?> yrs
                        <span class="dot"></span>
                        <?php echo sanitize($profile['city'] ?? $profile['state'] ?? ''); ?>
                    </div>
                    <div class="profile-detail">
                        <?php echo sanitize($profile['education'] ?? 'N/A'); ?>
                        <span class="dot"></span>
                        <?php echo sanitize($profile['occupation'] ?? ''); ?>
                    </div>
                    <div class="profile-detail"><?php echo sanitize($profile['religion'] ?? ''); ?></div>
<div class="profile-actions">
    <?php if (isLoggedIn()): ?>
        <a href="<?php echo BASE_URL; ?>/profile.php?id=<?php echo $profile['user_id']; ?>" class="btn btn-secondary btn-sm">View</a>
        <button class="btn btn-primary btn-sm" data-action="interest" data-user-id="<?php echo $profile['user_id']; ?>">Send Interest</button>
    <?php else: ?>
        <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-primary btn-sm btn-block">Login to View</a>
    <?php endif; ?>
</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php echo pagination($page, $totalPages, BASE_URL . '/matches.php?'); ?>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
